Hoy toca la **interfaz de la partida en red** (2 y 3 jugadores): lo que queda de la issue #19 con sprites. Las piezas las he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre. Trabaja en la rama `adam/red-interfaz`: si el PR #20 (`adam/red-mejoras`) ya está fusionado, sácala de `main`; si no, de `adam/red-mejoras`, que es donde están la flecha y el aviso de espera. Valida en headless y no hagas push ni abras el PR hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar, los sucesos de red nuevos y cómo dibujas cada pantalla. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame. Por ejemplo, `contexto.md` dice que en red no se pausa, y la votación lo cambia.

El zip está en la rama `zips-lotes` del repo, que solo guarda los zips y no se fusiona con `main`. Bájalo y descomprímelo en la raíz del repo, encima de lo que hay, sin cambiar de rama:

```
git fetch origin zips-lotes
git show origin/zips-lotes:lote_red_interfaz.zip > /tmp/lote_red_interfaz.zip
unzip -o /tmp/lote_red_interfaz.zip -d .
```

Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `vista_red.png`: las piezas, en gris y teñidas, y las seis pantallas grabadas en Godot 4.7.2.
- `captura_red.png`, `red_espera.gif` y `red_ruleta.gif`: en la partida.

Medidas, trozos, fotogramas y orden de los iconos: `LEEME.txt`.

## Las piezas

En `projecte/medios/interfaz/`. Van en grises y se tiñen (`personaje.color`, `EstiloInterfaz.NEON`, etc.).

| Fichero | Tamaño | Para qué |
|---|---|---|
| `red_mejora_ranura.png` | 3 x 20x20, a x2 | ranura de una mejora en la ficha del compañero: normal, evolución e insignia del número |
| `red_en_uso.png` | 72x72, a 0,5 | encima de la ranura de la barra cuando ese personaje lo lleva otro |
| `red_flecha.png` | 16x16, a x2 | la flecha del borde hacia el compañero que no se ve (se gira) |
| `red_placa.png` | 48x14, 3 trozos (8, 32 y 8) | la placa del nombre encima de cada jugador y junto a la flecha |
| `red_espera.png` | 8 x 16x16, 0,1 s en bucle | el reloj de arena del aviso de espera |
| `red_voto.png` | 3 x 12x12 | el voto de cada uno: pendiente, sí y no |
| `red_iconos.png` | 8 x 12x12 | en uso, jugador, anfitrión, conexión, espera, sí, no y pausa |

Además se **reutilizan** piezas que ya hay, sin pieza nueva:
- **Ficha del compañero:** `panel.png` con `EstiloInterfaz.caja` (como la del enemigo) y `equipo_retrato_marco.png`.
- **Votación y espera:** `aviso_banda.png` (la de `avisos_hud.gd`) y `botones.png`.
- **Mini ruleta:** `panel.png` y la ruleta de siempre a x1.

## Cómo lo quiero

La lógica de cada pantalla está en la **issue #19**. El código de red está en `projecte/escenas/red/`: `indicador_companeros_red.gd` (la flecha y los nombres), `aviso_espera_red.gd` (la espera), `sucesos_red.gd` (los sucesos de red: aquí van la votación y la ruleta del compañero) y `estado_red.gd`.

- **Ficha del compañero** (punto 7 de la issue). Click en un compañero y sale su ficha, que **tiene que funcionar igual que la del enemigo** (`escenas/interfaz/ficha_enemigo.gd`): arriba a la derecha, se pone al día sola y se cierra con click derecho. Lleva su retrato con el marco, su nombre del color de su personaje, el personaje y sus mejoras con las veces que ha cogido cada una. Las mejoras de cada jugador tienen que llegar por red (el suceso «mejora» de la issue). Si un click cae a la vez sobre un enemigo y un compañero, decide tú cuál gana y dímelo en el plan. Guía: `referencia/ficha_companero.gd`.
- **Personaje en uso** (punto 2). En la barra de abajo (`escenas/interfaz/barra_equipo.gd`), el personaje que lleva otro jugador sale con `red_en_uso.png` encima y su nombre. No se puede pasar a él: Q y E se lo saltan. Guía: `referencia/barra_equipo.diff`. La barra ya pasaba de las 200 líneas; si crece mucho, dime cómo la partirías.
- **Nombres y flecha** (ya hechos en el PR #20, solo cambia el dibujo):
  - el nombre va encima de cada jugador sobre `red_placa.png`, con la fuente pixel a 11
  - la flecha es `red_flecha.png` a x2 en vez del triángulo
  - guía: `referencia/indicador_companeros_red.diff`
- **Espera** (ya hecha): «Esperando a que los demás jugadores elijan...» dentro de `aviso_banda.png` con el reloj de arena animado. Guía: `referencia/aviso_espera_red.diff`.
- **Votación para parar** (punto 5):
  - Esc en red pide parar. Los demás ven «Alan quiere parar la partida» con SÍ y NO, y el voto de cada uno con `red_voto.png` (la corona de `red_iconos.png` en el anfitrión).
  - Si votan todos que sí, el anfitrión pausa y avisa a los clientes. Se sigue cuando quien la pidió pulsa CONTINUAR.
  - Es un suceso de ida y vuelta nuevo en `sucesos_red.gd`.
  - Guía: `referencia/votacion_red.gd` (solo la enseña y avisa con `votado`).
- **Ruleta del compañero** (punto 6). Cuando otro abre un cofre, todos ven su ruleta en pequeño, a la izquierda y del color de su personaje: «COFRE DE ALAN», gira hasta su premio y se va sola. Solo se mira: no pausa ni contesta nada (el suceso «ruleta» a todos). Guía: `referencia/ruleta_companero.gd`.
- **`red_iconos.png`**: úsalos donde encajen. Por ejemplo, en la sala (`sala_red.gd`): jugador, anfitrión y conexión al lado de cada uno, en uso en los personajes cogidos y espera en quien aún no ha elegido.
- Los ficheros de `referencia/` son lo que probé en la grabación. Úsalos de guía y hazlo como sea más fácil de explicar. Si `_banda()` se repite en varios scripts, súbela a `EstiloInterfaz`.
- **Ficheros de paso** (`project.godot`, `juego.tscn`, `raiz_juego.tscn`, `bus_eventos.gd`): si hace falta tocar alguno, va en un PR pequeño y aparte, como dice el CLAUDE.md. Los scripts nuevos, con `preload` y sin `class_name`.

## Al terminar

- **Validación del CLAUDE.md** (`/validar`): import y `--quit-after`, y carga también `escenas/juego.tscn` (una partida del simulador vale).
- **Capturas con ventana** de cada pantalla:
  - la ficha de un compañero con varias mejoras
  - la barra con un personaje en uso
  - la flecha y los nombres sobre la partida
  - el aviso de espera
  - la votación
  - la mini ruleta
- **Cómo probarlo:** si se puede, con dos copias del juego en red en el mismo ordenador. Si no, con instrumentación temporal: mi prueba está en `referencia/prueba_red.gd` y sus dos ayudantes `prueba_red_*.gd` (una partida de un jugador con compañeros, votos y cofre de mentira). Borra la instrumentación al acabar.
- No cambia el balance: no hace falta el simulador.
- **Documentación:**
  - `creditos.md`: las piezas de la interfaz de red las hizo Claude, con IA, como las demás.
  - `contexto.md`: lo de la pausa en red, si cambia con la votación.
  - `documentacion_tecnica.md` y el manual, si hablan de la partida en red.
  - La entrada de la sesión en `documentacio/bitacora/` y `requisitos_y_estado.md`.
  - En la issue #19, un comentario con lo que queda hecho.
  - No toques lo de Alan.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - las vistas previas (`vista_red.png`, `captura_red.png`, `red_espera.gif`, `red_ruleta.gif`)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat(red)`, uno por pantalla o por suceso nuevo
  - `docs`
- **Al decirte "ya he acabado":** `/cerrar` (push de la rama y su PR). No publiques ninguna versión.
