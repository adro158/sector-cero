"""Assets de la interfaz de la partida en red de SECTOR CERO (2 y 3 jugadores),
en grises para teñirlos. Misma paleta que el lote 9, el F3 y el panel del
equipo: contorno 20, oscuro 95, medio 170, claro 235, blanco 255 y fondo 22.

Uso:  python3 generar_red.py <carpeta de salida>
Deja los PNG en <salida>/projecte/medios/interfaz/.
"""
import os
import sys

import numpy as np
from PIL import Image

CONTORNO, OSCURO, MEDIO, CLARO, BLANCO = 20, 95, 170, 235, 255
FONDO = 22


def lienzo(w, h):
    return np.zeros((h, w, 4), np.uint8)


def gris(a, x, y, v, alfa=255):
    x, y = int(round(x)), int(round(y))
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        a[y, x] = (v, v, v, alfa)


def rect(a, x0, y0, x1, y1, v, alfa=255):
    a[y0:y1 + 1, x0:x1 + 1] = (v, v, v, alfa)


def anillo(a, x0, y0, x1, y1, v, alfa=255):
    rect(a, x0, y0, x1, y0, v, alfa)
    rect(a, x0, y1, x1, y1, v, alfa)
    rect(a, x0, y0, x0, y1, v, alfa)
    rect(a, x1, y0, x1, y1, v, alfa)


def cortar_esquinas(a, n=2):
    """Esquinas cortadas a 45 grados: se borran y el canto queda de contorno."""
    h, w = a.shape[:2]
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(n):
            for j in range(n - i):
                a[cy + sy * j, cx + sx * i] = 0
        for i in range(n + 1):
            gris(a, cx + sx * i, cy + sy * (n - i), CONTORNO)


V = {'o': CONTORNO, 'd': OSCURO, 'm': MEDIO, 'l': CLARO, 'w': BLANCO, 'g': (40, 210)}


def desde_texto(filas, valores=V):
    h, w = len(filas), len(filas[0])
    a = lienzo(w, h)
    for y, fila in enumerate(filas):
        assert len(fila) == w, fila
        for x, ch in enumerate(fila):
            if ch != '.':
                v = valores[ch]
                v, alfa = v if isinstance(v, tuple) else (v, 255)
                a[y, x] = (v, v, v, alfa)
    return a


def relieve(mascara):
    """De una máscara (filas con 'x') a un icono con contorno y relieve: el
    borde de la forma, de contorno; dentro, claro, con blanco arriba y medio
    abajo y a la derecha (la luz viene de arriba a la izquierda, como en los
    demás iconos)."""
    h, w = len(mascara), len(mascara[0])
    dentro = np.array([[c == 'x' for c in fila] for fila in mascara])
    a = lienzo(w, h)

    def esta(x, y):
        return 0 <= x < w and 0 <= y < h and dentro[y, x]

    for y in range(h):
        for x in range(w):
            if not dentro[y, x]:
                continue
            vecinos = (esta(x, y - 1), esta(x, y + 1), esta(x - 1, y), esta(x + 1, y))
            if not all(vecinos):
                gris(a, x, y, CONTORNO)
            elif not esta(x, y + 2) or not esta(x + 2, y):
                gris(a, x, y, MEDIO)
            elif not esta(x, y - 2):
                gris(a, x, y, BLANCO)
            else:
                gris(a, x, y, CLARO)
    return a


def guardar(a, ruta):
    Image.fromarray(a, 'RGBA').save(ruta)


# ------------------------------------------------------------------ ranura de una mejora
def ranura(evolucion):
    """20x20. El icono de la mejora (16x16) va en (2, 2), encima."""
    a = lienzo(20, 20)
    rect(a, 1, 1, 18, 18, FONDO, 238)
    anillo(a, 0, 0, 19, 19, CONTORNO)
    if evolucion:
        # borde grueso y claro, como mejora_marco_evolucion
        anillo(a, 1, 1, 18, 18, CLARO)
        rect(a, 1, 18, 18, 18, MEDIO)
        rect(a, 18, 1, 18, 18, MEDIO)
        cortar_esquinas(a, 2)
        # corchetes blancos por fuera
        for (cx, cy, sx, sy) in ((0, 0, 1, 1), (19, 0, -1, 1), (0, 19, 1, -1), (19, 19, -1, -1)):
            for k in range(2, 5):
                gris(a, cx + sx * k, cy, BLANCO)
                gris(a, cx, cy + sy * k, BLANCO)
            gris(a, cx + sx, cy + sy, BLANCO)
    else:
        # bisel: claro arriba y a la izquierda, oscuro abajo y a la derecha
        rect(a, 1, 1, 18, 1, CLARO)
        rect(a, 1, 1, 1, 18, CLARO)
        rect(a, 1, 18, 18, 18, OSCURO)
        rect(a, 18, 1, 18, 18, OSCURO)
        cortar_esquinas(a, 2)
        # muescas blancas arriba a la izquierda y abajo a la derecha
        for x, y in ((3, 1), (4, 1), (1, 3), (1, 4), (16, 18), (15, 18), (18, 16), (18, 15)):
            gris(a, x, y, BLANCO)
    return a


def insignia():
    """20x20 con solo la insignia del número, de 9x9 en (11, 11): va encima del
    icono. El hueco, de 7x7 en (12, 12), es justo un número de la fuente pixel
    (5x7 a 11 px; a x2, la letra a 22)."""
    a = lienzo(20, 20)
    rect(a, 11, 11, 19, 19, CONTORNO)
    rect(a, 12, 12, 18, 18, FONDO)
    # el canto de arriba y el de la izquierda, claros
    rect(a, 12, 11, 18, 11, MEDIO)
    rect(a, 11, 12, 11, 18, MEDIO)
    a[11, 11] = 0
    return a


def ranuras():
    """Tira de 60x20: 0 normal, 1 evolución y 2 la insignia del número."""
    return np.concatenate([ranura(False), ranura(True), insignia()], axis=1)


# ------------------------------------------------------------------ personaje en uso
def en_uso():
    """72x72, encima de equipo_ranura.png (y del retrato, que va en 4, 4 y mide
    64x64). Rayas diagonales que oscurecen sin tapar, esquinas de cinta de
    obra y corchetes. Todo en trazos de 2 px: la barra lo dibuja a 0,5."""
    lado = 72
    a = lienzo(lado, lado)
    for y in range(4, 68):
        for x in range(4, 68):
            d = (x + y) % 12
            # las rayas: oscuras y con un filo claro (que se tiñe)
            if d < 4:
                gris(a, x, y, CONTORNO, 150)
            elif d < 6:
                gris(a, x, y, MEDIO, 90)
    # las cuatro esquinas, triángulos de cinta opacos
    for (cx, cy, sx, sy) in ((4, 4, 1, 1), (67, 4, -1, 1), (4, 67, 1, -1), (67, 67, -1, -1)):
        for i in range(16):
            for j in range(16 - i):
                x, y = cx + sx * i, cy + sy * j
                d = (x + y) % 12
                gris(a, x, y, CLARO if d < 6 else CONTORNO)
        # el canto del triángulo, de contorno
        for i in range(17):
            for g in (0, 1):
                gris(a, cx + sx * (i + g), cy + sy * (16 - i), CONTORNO)
    # corchetes blancos (2 px) en el borde del retrato
    for (cx, cy, sx, sy) in ((4, 4, 1, 1), (67, 4, -1, 1), (4, 67, 1, -1), (67, 67, -1, -1)):
        for k in range(0, 22):
            for g in (0, 1):
                gris(a, cx + sx * k, cy + sy * g, BLANCO)
                gris(a, cx + sx * g, cy + sy * k, BLANCO)
    return a


# ------------------------------------------------------------------ flecha del borde
def flecha():
    """16x16, apunta a la derecha y es simétrica respecto al centro (8, 8):
    el juego la gira hacia el compañero."""
    tramos = {1: (1, 2), 2: (1, 4), 3: (2, 6), 4: (2, 8), 5: (3, 10), 6: (4, 12), 7: (5, 14)}
    filas = []
    for y in range(16):
        espejo = 15 - y
        tramo = tramos.get(y) or tramos.get(espejo)
        fila = ''.join('x' if tramo and tramo[0] <= x <= tramo[1] else '.' for x in range(16))
        filas.append(fila)
    a = relieve(filas)
    # la mitad de abajo, en sombra: se lee la punta aunque el fondo sea claro
    for y in range(8, 16):
        for x in range(16):
            if a[y, x, 3] and a[y, x, 0] in (CLARO, BLANCO):
                gris(a, x, y, MEDIO)
    return a


# ------------------------------------------------------------------ placa del nombre
def placa():
    """48x14, 3 trozos en horizontal: izquierda 8, centro 32 (se estira) y
    derecha 8. El texto va en el hueco de 10 px de alto (de y = 2 a y = 11)."""
    w, h = 48, 14
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, FONDO, 225)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 1, h - 2, w - 2, h - 2, OSCURO)
    rect(a, 1, 1, 1, h - 2, CLARO)
    rect(a, w - 2, 1, w - 2, h - 2, OSCURO)
    cortar_esquinas(a, 2)
    # a la izquierda, la marca del color del jugador
    rect(a, 3, 4, 4, 9, BLANCO)
    rect(a, 5, 4, 5, 9, OSCURO)
    # a la derecha, dos rayas inclinadas
    for k, x0 in enumerate((41, 44)):
        for y in range(4, 10):
            gris(a, x0 - (y - 4) // 3, y, MEDIO if k == 0 else OSCURO)
    return a


# ------------------------------------------------------------------ reloj de arena
VIDRIO = (40, 210)   # el cristal vacío: oscuro y un poco transparente
# Filas del cristal del reloj de 16x16: (primera, última) columna de dentro.
CRISTAL = {4: (4, 11), 5: (5, 10), 6: (6, 9), 7: (7, 8),
           8: (7, 8), 9: (6, 9), 10: (5, 10), 11: (4, 11)}


def tapas(a, filas):
    """Las tapas del reloj (de x = 2 a 13): contorno, luz y contorno."""
    for y, v in zip(filas, (CONTORNO, BLANCO, MEDIO, CONTORNO)):
        rect(a, 2, y, 13, y, v)
    cortar_esquinas_fila(a, filas[0], filas[-1])


def cortar_esquinas_fila(a, y0, y1):
    for y in (y0, y1):
        a[y, 2] = 0
        a[y, 13] = 0


def llenar(arena, filas, cantidad):
    """Pone `cantidad` celdas de arena en esas filas, por orden y centradas."""
    for y in filas:
        x0, x1 = CRISTAL[y]
        n = min(cantidad, x1 - x0 + 1)
        if n <= 0:
            break
        desde = x0 + (x1 - x0 + 1 - n) // 2
        for x in range(desde, desde + n):
            arena.add((x, y))
        cantidad -= n


def reloj(k):
    """El reloj de 16x16 con la arena del paso k (0, todo arriba; 5, todo
    abajo). Cada mitad tiene 20 celdas: pasan 4 en cada paso."""
    a = lienzo(16, 16)
    tapas(a, (0, 1, 2, 3))
    tapas(a, (12, 13, 14, 15))
    arena = set()
    llenar(arena, (7, 6, 5, 4), 20 - 4 * k)
    llenar(arena, (11, 10, 9, 8), 4 * k)
    if 0 < k < 5:
        # el chorro, por el cuello hasta el montón de abajo
        y = 8
        while (7, y) not in arena and y <= 11:
            arena.update({(7, y), (8, y)})
            y += 1
    for y, (x0, x1) in CRISTAL.items():
        gris(a, x0 - 1, y, CONTORNO)
        gris(a, x1 + 1, y, CONTORNO)
        for x in range(x0, x1 + 1):
            if (x, y) in arena:
                gris(a, x, y, CLARO if (x, y - 1) in arena or y - 1 not in CRISTAL else BLANCO)
            else:
                gris(a, x, y, *VIDRIO)
    return a


def reloj_de_canto(arena_arriba):
    """A media vuelta, aplastado: 10 filas (de 3 a 12) y la arena en un lado."""
    a = lienzo(16, 16)
    tapas(a, (3, 4, 4, 5))
    tapas(a, (10, 11, 11, 12))
    for y, (x0, x1) in ((6, (5, 10)), (7, (7, 8)), (8, (7, 8)), (9, (5, 10))):
        gris(a, x0 - 1, y, CONTORNO)
        gris(a, x1 + 1, y, CONTORNO)
        lleno = y == (6 if arena_arriba else 9)
        for x in range(x0, x1 + 1):
            if lleno:
                gris(a, x, y, CLARO)
            else:
                gris(a, x, y, *VIDRIO)
    return a


def espera():
    """8 x 16x16, en bucle a 0,1 s: la arena cae (0 a 5) y el reloj da media
    vuelta (6 y 7, aplastado: se ve de canto); después del 7 vuelve a estar
    como en el 0, con la arena arriba."""
    fotos = [reloj(k) for k in range(6)] + [reloj_de_canto(False), reloj_de_canto(True)]
    return np.concatenate(fotos, axis=1)


RELOJ_PEQUENO = [
    ".oooooooooo.",
    "owwwwwwwwwmo",
    ".oooooooooo.",
    "..oggggggo..",
    "...ollllo...",
    "....owwo....",
    "....ollo....",
    "...ogllgo...",
    "..ogwllwgo..",
    ".oooooooooo.",
    "ommmmmmmmmdo",
    ".oooooooooo.",
]


# ------------------------------------------------------------------ voto
CASILLA = {
    'pendiente': [
        "........",
        "........",
        "........",
        "mm.mm.mm",
        "mm.mm.mm",
        "........",
        "........",
        "........",
    ],
    'si': [
        "........",
        "......ww",
        ".....wwl",
        "ww..wwl.",
        "lwwwwl..",
        ".lwwl...",
        "..ll....",
        "........",
    ],
    'no': [
        "ww....ww",
        "lww..wwl",
        ".lwwwwl.",
        "..lwwl..",
        "..wwww..",
        ".wwllww.",
        "wwl..lww",
        "wl....lw",
    ],
}


def voto(cual):
    """12x12: una casilla con su marca en el hueco de 8x8 de (2, 2)."""
    a = lienzo(12, 12)
    rect(a, 1, 1, 10, 10, FONDO, 240)
    anillo(a, 0, 0, 11, 11, CONTORNO)
    rect(a, 1, 1, 10, 1, MEDIO)
    rect(a, 1, 1, 1, 10, MEDIO)
    rect(a, 1, 10, 10, 10, OSCURO)
    rect(a, 10, 1, 10, 10, OSCURO)
    cortar_esquinas(a, 1)
    marca = desde_texto(CASILLA[cual])
    hay = marca[:, :, 3] > 0
    a[2:10, 2:10][hay] = marca[hay]
    return a


def votos():
    """Tira de 36x12: 0 pendiente, 1 sí y 2 no."""
    return np.concatenate([voto(c) for c in ('pendiente', 'si', 'no')], axis=1)


# ------------------------------------------------------------------ iconos
CANDADO = [
    "............",
    "....oooo....",
    "...ommmmo...",
    "..omo..omo..",
    "..omo..omo..",
    ".oooooooooo.",
    ".owwwwwwwmo.",
    ".owlloollmo.",
    ".owlloollmo.",
    ".olllllllmo.",
    ".oooooooooo.",
    "............",
]
# La capucha y el ✓, copiados de equipo_iconos.png (generar_equipo.py).
CAPUCHA = [
    "....oooo....",
    "...ollllo...",
    "..ollllllo..",
    ".olloooolmo.",
    ".olowoowomo.",
    ".oloooooomo.",
    "olllooooolmo",
    "ollllooollmo",
    "olllllllllmo",
    "olllllllllmo",
    "ommmmmmmmmdo",
    "oooooooooooo",
]
VISTO = [
    "............",
    "..........oo",
    ".........owo",
    "........owlo",
    ".oo....owlo.",
    "owwo..owlo..",
    "olwlooowlo..",
    ".olwlowlo...",
    "..olwwlo....",
    "...ollo.....",
    "....oo......",
    "............",
]
CORONA = [
    "............",
    "............",
    ".x...xx...x.",
    ".xx.xxxx.xx.",
    ".xxxxxxxxxx.",
    ".xxxxxxxxxx.",
    ".xxxxxxxxxx.",
    ".xxxxxxxxxx.",
    ".xxxxxxxxxx.",
    ".xxxxxxxxxx.",
    "............",
    "............",
]
SENAL = [
    "............",
    ".........xxx",
    ".........xxx",
    ".........xxx",
    ".....xxx.xxx",
    ".....xxx.xxx",
    ".....xxx.xxx",
    ".xxx.xxx.xxx",
    ".xxx.xxx.xxx",
    ".xxx.xxx.xxx",
    ".xxx.xxx.xxx",
    "............",
]
PAUSA = [
    "............",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    ".xxxx..xxxx.",
    "............",
]


def equis():
    """Una X de trazo grueso (4 px de ancho en cada fila)."""
    filas = []
    for y in range(12):
        fila = ''
        for x in range(12):
            a = 1 <= y <= 10 and y - 2 <= x <= y + 1
            b = 1 <= y <= 10 and 10 - y <= x <= 13 - y
            fila += 'x' if a or b else '.'
        filas.append(fila)
    return relieve(filas)


def corona():
    a = relieve(CORONA)
    # las joyas de las puntas y la banda de abajo
    for x in (1, 5, 6, 10):
        gris(a, x, 1, CLARO)
    rect(a, 2, 8, 9, 8, OSCURO)
    return a


def iconos():
    """8 de 12x12 en una tira: 0 en uso (candado), 1 jugador, 2 anfitrión,
    3 conexión, 4 espera, 5 sí, 6 no y 7 pausa."""
    lista = [desde_texto(CANDADO), desde_texto(CAPUCHA), corona(), relieve(SENAL),
             desde_texto(RELOJ_PEQUENO), desde_texto(VISTO), equis(), relieve(PAUSA)]
    return np.concatenate(lista, axis=1)


def generar(salida):
    carpeta = os.path.join(salida, 'projecte/medios/interfaz')
    os.makedirs(carpeta, exist_ok=True)
    for nombre, a in (('red_mejora_ranura', ranuras()), ('red_en_uso', en_uso()),
                      ('red_flecha', flecha()), ('red_placa', placa()),
                      ('red_espera', espera()), ('red_voto', votos()),
                      ('red_iconos', iconos())):
        guardar(a, os.path.join(carpeta, nombre + '.png'))


if __name__ == '__main__':
    generar(sys.argv[1])
