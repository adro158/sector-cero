extends PanelContainer

## Ficha de un compañero en la partida en red, como la del enemigo: al pinchar
## en él sale arriba a la derecha con su retrato, su nombre, el personaje que
## lleva y sus mejoras, cada una con las veces que la ha cogido. Se cierra con
## click derecho.
##
## Las piezas son del lote de la interfaz de red: el panel es el de siempre
## (EstiloInterfaz.caja) y las mejoras van en ranuras de 20x20 a x2, del mismo
## tamaño que la columna de mejoras del HUD.
##
## Sin class_name: el HUD la carga con preload.

const MARCO := preload("res://medios/interfaz/equipo_retrato_marco.png")
## 0 normal, 1 evolución y 2 la insignia del número (va encima del icono).
const RANURA := preload("res://medios/interfaz/red_mejora_ranura.png")
const RETRATOS := {
	"Espadachín": preload("res://medios/interfaz/retrato_mini_espadachin.png"),
	"Mago": preload("res://medios/interfaz/retrato_mini_mago.png"),
	"Segador": preload("res://medios/interfaz/retrato_mini_segador.png"),
}
const ESCALA := 2.0
const LADO := 20.0 * ESCALA
const SEPARACION := 4.0
const POR_FILA := 6

var _nombre: Label
var _personaje: Label
var _retrato: Control
var _rejilla: Control
var _color := Color.WHITE
var _textura_retrato: Texture2D
## Cada mejora: {mejora: DatosMejora, nivel: int, evolucion: bool}.
var _mejoras: Array = []


func _ready() -> void:
	set_anchors_preset(Control.PRESET_TOP_RIGHT)
	grow_horizontal = Control.GROW_DIRECTION_BEGIN
	offset_left = -16.0
	offset_right = -16.0
	offset_top = 16.0
	custom_minimum_size = Vector2(300, 0)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", 10)
	add_child(columna)
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 12)
	columna.add_child(fila)
	_retrato = Control.new()
	_retrato.custom_minimum_size = Vector2(40, 40)
	_retrato.draw.connect(_dibujar_retrato)
	fila.add_child(_retrato)
	var textos := VBoxContainer.new()
	fila.add_child(textos)
	_nombre = EstiloInterfaz.etiqueta("", 16)
	_personaje = EstiloInterfaz.etiqueta("", 12, EstiloInterfaz.TEXTO_SUAVE)
	textos.add_child(_nombre)
	textos.add_child(_personaje)

	_rejilla = Control.new()
	_rejilla.draw.connect(_dibujar_mejoras)
	columna.add_child(_rejilla)
	columna.add_child(EstiloInterfaz.etiqueta("Click derecho: cerrar", 11, EstiloInterfaz.TEXTO_SUAVE))
	visible = false


func mostrar(nombre: String, personaje: DatosPersonaje, mejoras: Array) -> void:
	_color = personaje.color
	_textura_retrato = RETRATOS.get(personaje.nombre)
	add_theme_stylebox_override("panel", EstiloInterfaz.caja(_color, 12))
	_nombre.text = nombre
	_nombre.add_theme_color_override("font_color", _color)
	_personaje.text = "%s · %d mejoras" % [personaje.nombre, mejoras.size()]
	_mejoras = mejoras
	var filas := maxi(1, ceili(mejoras.size() / float(POR_FILA)))
	_rejilla.custom_minimum_size = Vector2(POR_FILA * (LADO + SEPARACION) - SEPARACION, filas * (LADO + SEPARACION) - SEPARACION)
	_retrato.queue_redraw()
	_rejilla.queue_redraw()
	visible = true


func _unhandled_input(evento: InputEvent) -> void:
	if visible and evento is InputEventMouseButton and evento.pressed and evento.button_index == MOUSE_BUTTON_RIGHT:
		visible = false


func _dibujar_retrato() -> void:
	_retrato.draw_texture(MARCO, Vector2.ZERO, _color)
	if _textura_retrato != null:
		_retrato.draw_texture(_textura_retrato, Vector2(4.0, 4.0))


## Las ranuras, de izquierda a derecha y de arriba abajo; el número, solo si
## la ha cogido más de una vez.
func _dibujar_mejoras() -> void:
	var fuente := EstiloInterfaz.fuente_pixel()
	for i in _mejoras.size():
		var datos: Dictionary = _mejoras[i]
		var esquina := Vector2(i % POR_FILA, floori(i / float(POR_FILA))) * (LADO + SEPARACION)
		var fotograma := 1 if datos.evolucion else 0
		_rejilla.draw_texture_rect_region(RANURA, Rect2(esquina, Vector2(LADO, LADO)), Rect2(fotograma * 20.0, 0.0, 20.0, 20.0), _color)
		_rejilla.draw_texture_rect(datos.mejora.icono, Rect2(esquina + Vector2(2.0, 2.0) * ESCALA, Vector2(16.0, 16.0) * ESCALA), false)
		if datos.nivel > 1:
			_rejilla.draw_texture_rect_region(RANURA, Rect2(esquina, Vector2(LADO, LADO)), Rect2(40.0, 0.0, 20.0, 20.0), _color)
			# El hueco de la insignia mide 7x7 en (12, 12): un número de la
			# fuente pixel a 22 lo llena justo; con dos cifras, a 11.
			var tamano := 22 if datos.nivel < 10 else 11
			var base := esquina + Vector2(12.0, 19.0) * ESCALA
			_rejilla.draw_string(fuente, base, str(datos.nivel), HORIZONTAL_ALIGNMENT_CENTER, 7.0 * ESCALA, tamano, Color.WHITE)
