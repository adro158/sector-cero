extends "res://escenas/red/aviso_espera_red.gd"

## Prueba: el aviso de verdad, siempre con el mismo texto.


func _init() -> void:
	super(null)


func _process(delta: float) -> void:
	_tiempo += delta
	_reloj.region.position.x = int(_tiempo / SEGUNDOS_FOTOGRAMA) % 8 * 16.0
	_aviso.text = "Esperando a que los demás jugadores elijan..."
