extends "res://escenas/red/indicador_companeros_red.gd"

## Prueba: la flecha y las placas de verdad, con compañeros de mentira.

var jugador: Node2D
var colores: Array = []


func _init() -> void:
	super(null)


func _draw() -> void:
	var pantalla := get_viewport_rect().size
	var del_mundo := get_viewport().get_canvas_transform()
	var a_mundo := del_mundo.affine_inverse()
	var fuente := EstiloInterfaz.fuente_pixel()
	_texto(fuente, "Adam", jugador.global_position - Vector2(0.0, ALTURA_NOMBRE), colores[0])
	_flecha(fuente, "Alan", del_mundo * (jugador.global_position + Vector2(1500.0, 150.0)), pantalla, colores[1], a_mundo)
	_flecha(fuente, "Pepe", del_mundo * (jugador.global_position + Vector2(-1200.0, 500.0)), pantalla, colores[2], a_mundo)
