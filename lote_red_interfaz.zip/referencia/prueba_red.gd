extends SceneTree

## Prueba de las piezas de la interfaz de red en una partida de un jugador (no
## hay red: los compañeros, sus nombres, los votos y el cofre son de mentira).
## Graba en orden (a 30 fps):
##   0-89     la barra con el Mago en uso por «Alan», el nombre encima del
##            jugador, las flechas a dos compañeros fuera de la pantalla y la
##            ficha de Alan con sus mejoras
##   90-149   la votación para parar la partida
##   150-329  la mini ruleta del cofre de Alan girando y su premio
##   330-389  el aviso de espera (con el juego en pausa)

var _fotograma := 0
var _juego: Node
var _barra: Node
var _capa: Node
var _ficha: Node
var _votacion: Node
var _ruleta: Node
var _espera: Node
var _mago: Resource
var _votacion_script: GDScript


func _initialize() -> void:
	var guardado: Node = root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	_juego = load("res://escenas/juego.tscn").instantiate()
	root.add_child(_juego)


func _process(_delta: float) -> bool:
	_fotograma += 1
	if _fotograma == 2:
		_preparar()
	if _barra != null and not _barra._estado.is_empty():
		# Alan lleva el Mago (lo pondría equipo.gd con llevado_por).
		for datos in _barra._estado:
			if datos.personaje == _mago:
				datos["llevado_por"] = "Alan"
	if _fotograma == 20:
		_ficha.mostrar("Alan", _mago, _mejoras())
	if _fotograma == 90:
		_ficha.visible = false
		_votacion.abrir("Alan", true)
		_votacion.poner_votos([
			{nombre = "Alan", voto = _votacion_script.Voto.SI, anfitrion = false},
			{nombre = "Adam", voto = _votacion_script.Voto.PENDIENTE, anfitrion = true},
			{nombre = "Pepe", voto = _votacion_script.Voto.NO, anfitrion = false},
		])
	if _fotograma == 150:
		_votacion.visible = false
		var opciones := _opciones()
		_ruleta.mostrar("Alan", _mago.color, opciones, opciones[5])
	if _fotograma == 330:
		_ruleta.visible = false
		paused = true
		_espera.visible = true
	return _fotograma >= 390


func _preparar() -> void:
	_mago = load("res://recursos/personajes/datos/mago.tres")
	var colores := [load("res://recursos/personajes/datos/espadachin.tres").color, _mago.color, load("res://recursos/personajes/datos/segador.tres").color]
	var raiz := _juego.get_node("RaizJuego")
	# Sin horda nueva: que se vean las piezas.
	raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
	var hud := _juego.get_node("Interfaz/HUD")
	for hijo in hud.get_children():
		if hijo.get_script() != null and hijo.get_script().resource_path.ends_with("barra_equipo.gd"):
			_barra = hijo
	var indicador: Node2D = load("res://prueba_red_indicador.gd").new()
	indicador.jugador = raiz.get_node("Jugador")
	indicador.colores = colores
	raiz.add_child(indicador)
	_capa = CanvasLayer.new()
	_capa.layer = 10
	_juego.add_child(_capa)
	var lienzo := Control.new()
	lienzo.theme = load("res://escenas/interfaz/estilo_interfaz.gd").tema()
	lienzo.set_anchors_preset(Control.PRESET_FULL_RECT)
	lienzo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_capa.add_child(lienzo)
	_ficha = load("res://escenas/interfaz/ficha_companero.gd").new()
	lienzo.add_child(_ficha)
	_ruleta = load("res://escenas/red/ruleta_companero.gd").new()
	lienzo.add_child(_ruleta)
	_votacion_script = load("res://escenas/red/votacion_red.gd")
	_votacion = _votacion_script.new()
	_juego.add_child(_votacion)
	_espera = load("res://prueba_red_espera.gd").new()
	_juego.add_child(_espera)


func _mejoras() -> Array:
	var lista := []
	for nombre_nivel in [["evolucion_ping", 1], ["dano", 4], ["cadencia", 3], ["vida", 2], ["alcance", 1], ["velocidad", 2], ["cache_ampliada", 1], ["actualizar_firmas", 12]]:
		var mejora: Resource = load("res://recursos/mejoras/datos/%s.tres" % nombre_nivel[0])
		lista.append({mejora = mejora, nivel = nombre_nivel[1], evolucion = nombre_nivel[0].begins_with("evolucion")})
	return lista


func _opciones() -> Array:
	var lista := []
	for nombre in ["dano", "cadencia", "alcance", "velocidad", "vida", "cache_ampliada", "actualizar_firmas", "cambio_en_caliente"]:
		lista.append(load("res://recursos/mejoras/datos/%s.tres" % nombre))
	return lista
