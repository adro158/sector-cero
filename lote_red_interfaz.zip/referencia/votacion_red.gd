extends CanvasLayer

## En la partida en red: la votación para parar la partida. Al pulsar Esc,
## los demás ven «Alan quiere parar la partida» con SÍ y NO y, debajo, el
## voto de cada uno (pendiente, sí o no). Esta pieza solo lo enseña: la
## lógica (sucesos_red.gd) le pasa los votos y escucha `votado`.
##
## Sin class_name: lo crea partida_red.gd con preload.

signal votado(si: bool)

enum Voto { PENDIENTE, SI, NO }

## La banda de los avisos del HUD, con los márgenes de avisos_hud.gd.
const BANDA := preload("res://medios/interfaz/aviso_banda.png")
## 3 de 12x12, en el orden de Voto.
const VOTOS := preload("res://medios/interfaz/red_voto.png")
## 8 de 12x12: 0 en uso, 1 jugador, 2 anfitrión, 3 conexión, 4 espera, 5 sí,
## 6 no y 7 pausa.
const ICONOS := preload("res://medios/interfaz/red_iconos.png")
const ICONO_ANFITRION := 2
const ICONO_PAUSA := 7
const COLORES_VOTO := [EstiloInterfaz.TEXTO_SUAVE, EstiloInterfaz.VICTORIA, EstiloInterfaz.DERROTA]
const COLOR_ANFITRION := Color(1.0, 0.8, 0.2)

var _titulo: Label
var _lista: HBoxContainer
var _botones: HBoxContainer


func _ready() -> void:
	layer = 50
	process_mode = Node.PROCESS_MODE_ALWAYS
	var caja := PanelContainer.new()
	caja.theme = EstiloInterfaz.tema()
	caja.add_theme_stylebox_override("panel", _banda(EstiloInterfaz.NEON))
	caja.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	caja.set_anchors_preset(Control.PRESET_CENTER_TOP)
	caja.grow_horizontal = Control.GROW_DIRECTION_BOTH
	caja.offset_top = 120.0
	add_child(caja)
	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", 10)
	caja.add_child(columna)

	var cabecera := HBoxContainer.new()
	cabecera.alignment = BoxContainer.ALIGNMENT_CENTER
	cabecera.add_theme_constant_override("separation", 12)
	cabecera.add_child(_icono(ICONOS, ICONO_PAUSA, EstiloInterfaz.NEON))
	_titulo = EstiloInterfaz.etiqueta("", 22, EstiloInterfaz.NEON)
	cabecera.add_child(_titulo)
	columna.add_child(cabecera)

	_lista = HBoxContainer.new()
	_lista.alignment = BoxContainer.ALIGNMENT_CENTER
	_lista.add_theme_constant_override("separation", 22)
	columna.add_child(_lista)

	_botones = HBoxContainer.new()
	_botones.alignment = BoxContainer.ALIGNMENT_CENTER
	_botones.add_theme_constant_override("separation", 16)
	_botones.add_child(EstiloInterfaz.boton("SÍ", func(): votado.emit(true), 120.0))
	_botones.add_child(EstiloInterfaz.boton("NO", func(): votado.emit(false), 120.0))
	columna.add_child(_botones)
	visible = false


## puedo_votar: false para el que la ha pedido y para quien ya ha votado.
func abrir(quien: String, puedo_votar: bool) -> void:
	_titulo.text = "%s quiere parar la partida" % quien
	_botones.visible = puedo_votar
	visible = true


## Cada voto: {nombre: String, voto: Voto, anfitrion: bool}.
func poner_votos(votos: Array) -> void:
	for hijo in _lista.get_children():
		hijo.queue_free()
	for datos in votos:
		var fila := HBoxContainer.new()
		fila.add_theme_constant_override("separation", 6)
		fila.add_child(_icono(VOTOS, datos.voto, COLORES_VOTO[datos.voto]))
		if datos.anfitrion:
			fila.add_child(_icono(ICONOS, ICONO_ANFITRION, COLOR_ANFITRION))
		fila.add_child(EstiloInterfaz.etiqueta(datos.nombre, 16))
		_lista.add_child(fila)


## Un icono de 12x12 de una tira, al doble y teñido.
func _icono(tira: Texture2D, indice: int, color: Color) -> TextureRect:
	var trozo := AtlasTexture.new()
	trozo.atlas = tira
	trozo.region = Rect2(indice * 12.0, 0.0, 12.0, 12.0)
	var icono := TextureRect.new()
	icono.texture = trozo
	icono.custom_minimum_size = Vector2(24.0, 24.0)
	icono.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icono.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	icono.modulate = color
	return icono


func _banda(color: Color) -> StyleBoxTexture:
	var banda := StyleBoxTexture.new()
	banda.texture = BANDA
	banda.texture_margin_left = 16.0
	banda.texture_margin_right = 16.0
	banda.texture_margin_top = 8.0
	banda.texture_margin_bottom = 8.0
	banda.content_margin_left = 30.0
	banda.content_margin_right = 30.0
	banda.content_margin_top = 12.0
	banda.content_margin_bottom = 12.0
	banda.modulate_color = color
	return banda
