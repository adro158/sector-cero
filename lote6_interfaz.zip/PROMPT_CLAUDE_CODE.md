Hoy toca la **interfaz y el lanzador**: el logo con glitch en el menú, retratos de los personajes, los iconos de las mejoras rehechos, iconos para los afijos de los élites y una cabecera nueva para el lanzador. Los he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto.** Dime qué ficheros vas a tocar y dónde salen los retratos y los iconos de los afijos. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 6 en la raíz del repo. Mira con `git status` qué ha llegado.

Para ver cómo tiene que quedar:
- `vista_lote6.png`: todo el lote.
- `captura_*.png` y `menu_glitch.gif`: grabados en Godot 4.7.2 con los cambios de `referencia/interfaz.diff`.

`LEEME.txt` tiene los tamaños y los tiempos.

El diff está hecho sobre `8bd3506`. Si ya están metidos los lotes anteriores, adáptalo: el lote 5 toca `enemigo_elite.gd` y `aura_lenta.tres`.

## Los ficheros

Nada va en grises: todo va ya con su color.

| Fichero | Tamaño | Dónde |
|---|---|---|
| `projecte/medios/interfaz/logo_sector_cero.png` | 512x128 | título del menú, a x1 |
| `projecte/medios/interfaz/logo_sector_cero_glitch.png` | 4 x 512x128 | el glitch del título |
| `projecte/medios/interfaz/retrato_{mago,espadachin,segador}.png` | 64x64 | panel del equipo y ventana de caída, a x1 |
| `projecte/recursos/mejoras/iconos/*.png` (11) | 16x16 | machacan a los de ahora, mismos nombres |
| `projecte/recursos/enemigos/afijos/iconos/*.png` (4) | 16x16 | reglas y encima del élite |
| `lanzador/cabecera.png` | 960x260 | arriba del lanzador, de lado a lado, a x1 |

## Cómo lo quiero

### Iconos de mejora

- No hace falta tocar código: se cargan solos.
- `projecte/herramientas/generar_sprites.gd` vuelve a dibujar ocho de ellos con el estilo antiguo, así que si alguien lo ejecuta, los machaca. Ya no le queda nada que generar: quítalo (con su `.uid`).
- Arregla lo que lo nombre, menos la bitácora, que es historia.

### Logo del menú

- En `menu_principal.gd`, cambia la etiqueta "SECTOR CERO" por un `TextureRect`:
  - con el logo
  - con filtro `NEAREST`
  - a tamaño real (`STRETCH_KEEP_CENTERED`)
- El "latido" del título lo cambias por el glitch:
  - Un `AtlasTexture` de la tira.
  - El fotograma 0 casi todo el rato, entre 2 y 5 s al azar.
  - Luego los fotogramas 1, 2 y 3 a 0,07 s cada uno, y vuelta al 0.
- En la prueba lo hice con un tween en bucle y `tween_callback` que cambian `region`.
- Para el azar, que no gaste el de la partida.

### Retratos

- Un campo nuevo `@export var retrato: Texture2D` en `DatosPersonaje`, y rellénalo en los tres `.tres`.
- **Panel del equipo** (`panel_equipo.gd`, tecla C): el retrato a la izquierda de cada ficha, a x1. Si el personaje ha caído, ponlo en gris.
- **Ventana de caída** (`panel_caida.gd`): el retrato como `icon` de cada botón.
- **Reglas:** en la pestaña Personajes ahora se usa el primer fotograma de la hoja a 48x48. Propónme si se cambia por el retrato. Escalado a 48 se deforma: o se enseña a 64, o se deja como está.

### Iconos de los afijos

- Un campo nuevo `@export var icono: Texture2D` en `DatosAfijoElite`, y rellénalo en los cuatro `.tres` de `recursos/enemigos/afijos/`.
- **Reglas:** en `panel_reglas.gd`, la lista de afijos pasa `afijo.icono` a `_fila` en vez de `null`.
- **En la partida:** encima del nombre del élite, sus iconos en fila, centrados y a x1. En la prueba los puse en el `_draw` de `enemigo_elite.gd`, 20 px de paso.
- Propónme si también van en el aviso del HUD cuando aparece un élite.

### Cabecera del lanzador

- En `lanzador/lanzador.gd`, la cabecera sustituye a la fila de arriba (el icono y los dos textos). Va arriba de lado a lado, a tamaño real:
  - `TextureRect` con anclas `PRESET_TOP_WIDE`
  - 260 px de alto
  - `STRETCH_KEEP_CENTERED` y `NEAREST`
- El margen de arriba del resto pasa a 280.
- Quita `ICONO` de `lanzador.gd` si ya no se usa (`icono_linux.gd` tiene el suyo).
- El lema "Eres un antivirus..." desaparece con la fila. Si lo quieres conservar en otro sitio, propónmelo.

## Al terminar

- **Validación del CLAUDE.md:** import y `--quit-after` en `projecte/`, y también en `lanzador/`.
- **Capturas con ventana:**
  - el menú, con el logo y un momento del glitch
  - la subida de nivel y la columna de mejoras del HUD
  - las reglas: mejoras, afijos y personajes
  - un élite con dos afijos
  - el panel del equipo con un personaje caído
  - la ventana de caída
  - el lanzador

  Para que salgan, usa el menú de desarrollador (F1) o una instrumentación temporal. Mis pruebas están en `referencia/prueba_*.gd`. Borra la instrumentación al acabar.
- No cambia el balance, así que no hace falta el simulador. Pasa una partida para comprobar que no salen errores.
- **Documentación:**
  - `creditos.md`:
    - Lo del lote 6 lo hizo Claude, con IA, como lo demás.
    - Los 11 iconos de mejora ya son todos de Claude: arregla la fila de "8 propios, generados por código" y el párrafo que habla de `generar_sprites.gd`.
  - `documentacion_tecnica.md`: los campos nuevos y la carpeta `medios/interfaz/`.
  - El manual, si enseña el menú, el lanzador o los paneles.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- **Qué se commitea:** solo lo de `projecte/`, `lanzador/` y la documentación. No se commitean:
  - las vistas previas (los `.png` y `.gif` de la raíz)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - uno por cada cosa: logo, retratos, iconos de afijos, cabecera del lanzador y quitar `generar_sprites.gd`, con el tipo que toque
  - `docs`
- No publiques ninguna release, tampoco del lanzador.
