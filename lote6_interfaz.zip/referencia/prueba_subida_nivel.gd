extends SceneTree

# Prueba temporal: partida con varias mejoras regaladas (columna del HUD) y
# una subida de nivel (las tres tarjetas), para ver los iconos nuevos.
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 3:
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		var niveles: Node = _raiz.get_node("SistemaNiveles")
		for n in ["dano", "cadencia", "alcance", "velocidad", "vida", "actualizar_firmas", "cambio_en_caliente", "cache_ampliada"]:
			niveles.regalar(load("res://recursos/mejoras/datos/%s.tres" % n))
	if _frames == 8:
		root.get_node("BusEventos").experiencia_ganada.emit(5)
	return _frames > 20
