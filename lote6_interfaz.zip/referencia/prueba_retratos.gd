extends SceneTree

# Prueba temporal: el panel del equipo abierto (C) y la ventana de caída, para
# ver los retratos.
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _buscar(nodo: Node, ruta: String) -> Node:
	if nodo.get_script() != null and nodo.get_script().resource_path == ruta:
		return nodo
	for hijo in nodo.get_children():
		var hallado := _buscar(hijo, ruta)
		if hallado != null:
			return hallado
	return null


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
	if _frames == 5:
		_buscar(root, "res://escenas/interfaz/panel_equipo.gd")._panel.visible = true
	if _frames == 12:
		var equipo := _buscar(root, "res://escenas/interfaz/panel_equipo.gd")
		var estado: Array = equipo._estado.duplicate(true)
		estado[0].caido = true
		equipo._estado = estado
		_buscar(root, "res://escenas/interfaz/panel_caida.gd")._al_caer(estado, 0)
	return _frames > 18
