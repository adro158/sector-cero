extends SceneTree

# Prueba temporal: dos élites quietos con dos afijos cada uno (los cuatro
# iconos encima) y después la ventana de reglas en la lista de afijos.
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		var jugador: Node2D = _raiz.get_node("Jugador")
		jugador.get_node("Salud").invencible = true
		jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		var parejas := [["blindado", "replicante"], ["aura_lenta", "explosivo"]]
		var sitios := [Vector2(-150, -40), Vector2(150, -40)]
		for i in 2:
			var elite: Node2D = _raiz.get_node("Elite%d" % (i + 1))
			elite.datos = elite.datos.duplicate()
			elite.datos.velocidad = 0.0
			var lista: Array[DatosAfijoElite] = []
			for a in parejas[i]:
				lista.append(load("res://recursos/enemigos/afijos/%s.tres" % a))
			elite.aparecer(jugador.global_position + sitios[i], lista)
	if _frames == 30:
		root.get_children().back().queue_free()
		var reglas: Control = load("res://escenas/interfaz/panel_reglas.gd").new()
		var capa := CanvasLayer.new()
		root.add_child(capa)
		capa.add_child(reglas)
		reglas.abrir()
		reglas._pestanas.current_tab = 3
	if _frames == 34:
		var desplazable: ScrollContainer = root.get_children().back().get_child(0)._pestanas.get_child(3)
		desplazable.scroll_vertical = 100000
	return _frames > 40
