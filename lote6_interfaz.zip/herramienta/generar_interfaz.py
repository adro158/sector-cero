"""Genera todo el lote 6 (interfaz y lanzador) de SECTOR CERO.

Uso:  python3 generar_interfaz.py <carpeta del repo> <carpeta de salida>

Lee del repo las hojas de los personajes, la placa base y NÚCLEO CERO, y deja
en la carpeta de salida los PNG con la misma ruta que en el repo:
  projecte/recursos/mejoras/iconos/*.png           11 iconos de mejora, 16x16
  projecte/recursos/enemigos/afijos/iconos/*.png   4 iconos de afijo, 16x16
  projecte/medios/interfaz/logo_sector_cero*.png   el logo y su tira de glitch
  projecte/medios/interfaz/retrato_*.png           3 retratos de 64x64
  lanzador/cabecera.png                            la cabecera de 960x260
Necesita numpy y Pillow, y pixel.py en la misma carpeta.
"""
import os
import sys

import cabecera
import iconos
import logo
import retratos


def main(repo, salida):
    def ruta(*partes):
        return os.path.join(salida, *partes)
    for carpeta in ['projecte/recursos/mejoras/iconos', 'projecte/recursos/enemigos/afijos/iconos',
                    'projecte/medios/interfaz', 'lanzador']:
        os.makedirs(ruta(carpeta), exist_ok=True)
    iconos.generar(ruta('projecte/recursos/mejoras/iconos'), ruta('projecte/recursos/enemigos/afijos/iconos'))
    logo.generar(ruta('projecte/medios/interfaz/logo_sector_cero.png'),
                 ruta('projecte/medios/interfaz/logo_sector_cero_glitch.png'))
    retratos.generar(os.path.join(repo, 'projecte/escenas/jugabilidad/jugador'), ruta('projecte/medios/interfaz'))
    cabecera.generar(os.path.join(repo, 'projecte'), ruta('projecte/medios/interfaz/logo_sector_cero.png'),
                     ruta('lanzador/cabecera.png'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
