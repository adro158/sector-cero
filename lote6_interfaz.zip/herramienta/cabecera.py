"""Cabecera del lanzador de 960x260 (lote 6): la placa base de fondo,
NÚCLEO CERO enorme y oscuro detrás, los tres personajes delante (a x2) y el
logo a la izquierda."""
import numpy as np
from PIL import Image

from pixel import bayer

W, H = 960, 260


def pegar(a, im, x, y):
    im = np.array(im.convert('RGBA')).astype(np.float64)
    h, w = im.shape[:2]
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0:
        return
    src = im[y0 - y:y1 - y, x0 - x:x1 - x]
    al = src[..., 3:4] / 255.0
    a[y0:y1, x0:x1, :3] = src[..., :3] * al + a[y0:y1, x0:x1, :3] * (1 - al)


def generar(proyecto, ruta_logo, ruta):
    b = bayer(H, W)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
    a = np.zeros((H, W, 3), np.float64)
    # la placa base, oscurecida
    atlas = np.array(Image.open(f'{proyecto}/medios/texturas/suelo_placa.png').convert('RGB')).astype(np.float64)
    tira = np.concatenate([atlas[0:256, i * 256:(i + 1) * 256] for i in range(4)], axis=1)
    a[:256] = tira[:, :W] * 0.30
    a[256:] = tira[:4, :W] * 0.30
    # NÚCLEO CERO (forma 3) a x2, detrás y a la derecha, con un resplandor rojo y dorado
    jefe = Image.open(f'{proyecto}/medios/sprites/jefe_final/jefe_final.png').convert('RGBA').crop((0, 384, 192, 576))
    jefe = jefe.resize((384, 384), Image.NEAREST)
    jx, jy = 520, -70
    r = np.hypot(xx - (jx + 192), yy - (jy + 200))
    halo = np.clip(1 - r / 260, 0, 1)
    a += (np.array((255, 70, 60)) * 0.30 * halo[..., None]) * (b[..., None] < 0.75)
    a += (np.array((255, 190, 80)) * 0.12 * halo[..., None] ** 2)
    jefe_a = np.array(jefe).astype(np.float64)
    jefe_a[..., :3] *= 0.62                                   # al fondo: más oscuro
    pegar(a, Image.fromarray(jefe_a.astype(np.uint8)), jx, jy)
    # los tres personajes a x2, delante, mirando hacia el centro
    hojas = [('antivirus_8_direcciones.png', 7), ('ciberespadachin_8_direcciones.png', 0), ('segador_ciber_8_direcciones.png', 1)]
    xs = [560, 680, 800]
    for (hoja, fila), x in zip(hojas, xs):
        im = Image.open(f'{proyecto}/escenas/jugabilidad/jugador/{hoja}').convert('RGBA').crop((0, fila * 72, 64, fila * 72 + 72))
        im = im.resize((128, 144), Image.NEAREST)
        # sombra en el suelo
        sombra = (np.hypot((xx - (x + 64)) / 34, (yy - 250) / 6) <= 1) & (b < 0.6)
        a[sombra] *= 0.5
        pegar(a, im, x, H - 144 - 4)
    # oscuro a la izquierda (para el logo) y abajo
    izq = np.clip(1 - xx / 560, 0, 1) ** 1.4
    a *= (1 - 0.55 * izq)[..., None]
    abajo = np.clip((yy - 200) / 60, 0, 1)
    a *= (1 - 0.35 * abajo)[..., None]
    # el logo
    logo = Image.open(ruta_logo).convert('RGBA')
    pegar(a, logo, 24, (H - 128) // 2)
    # líneas de barrido y una línea de neón abajo
    a[(yy % 3) == 2] *= 0.88
    a[H - 2:] = (0, 217, 242)
    a[H - 3] = (0, 120, 150)
    Image.fromarray(np.clip(np.round(a), 0, 255).astype(np.uint8), 'RGB').save(ruta)
