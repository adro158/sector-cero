"""Logo "SECTOR CERO" de 512x128 (lote 6): letras de pixel art de neón cian
con el cero tachado (Ø) como en el icono, brillo, líneas de barrido y algo de
glitch. Saca también una tira de 4 fotogramas con el glitch más o menos fuerte,
para animarlo en el menú.
"""
import numpy as np
from PIL import Image

from pixel import bayer

LETRAS = {
    'S': [".####", "#....", "#....", ".###.", "....#", "....#", "####."],
    'E': ["#####", "#....", "#....", "####.", "#....", "#....", "#####"],
    'C': [".####", "#....", "#....", "#....", "#....", "#....", ".####"],
    'T': ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."],
    'O': [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."],
    'R': ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"],
}
CELDA = 8
ANCHO_LETRA = 5 * CELDA
ALTO_LETRA = 7 * CELDA
SEPARACION = 6
ESPACIO = 16
W, H = 512, 128

NEON = [(0, 60, 80), (0, 120, 150), (0, 217, 242), (120, 236, 255), (220, 250, 255)]
ROJO = [(110, 14, 30), (255, 77, 102), (255, 170, 180)]
FONDO_CONTORNO = (4, 10, 18)


def mascara_letra(filas):
    """Celdas de 8x8. Las esquinas redondeadas del dibujo (dos celdas que solo se
    tocan en diagonal) se unen con medio cuadrado en diagonal, y las esquinas de
    fuera se cortan a 45 grados: letras de trazo grueso con chaflanes."""
    m = np.zeros((ALTO_LETRA, ANCHO_LETRA), bool)
    def lleno(cx, cy):
        return 0 <= cy < 7 and 0 <= cx < 5 and filas[cy][cx] == '#'
    yy, xx = np.mgrid[0:CELDA, 0:CELDA]
    for cy in range(7):
        for cx in range(5):
            if lleno(cx, cy):
                bloque = np.ones((CELDA, CELDA), bool)
                corte = 3
                if not lleno(cx - 1, cy) and not lleno(cx, cy - 1) and not lleno(cx - 1, cy - 1):
                    bloque &= ~(xx + yy < corte)
                if not lleno(cx + 1, cy) and not lleno(cx, cy - 1) and not lleno(cx + 1, cy - 1):
                    bloque &= ~((CELDA - 1 - xx) + yy < corte)
                if not lleno(cx - 1, cy) and not lleno(cx, cy + 1) and not lleno(cx - 1, cy + 1):
                    bloque &= ~(xx + (CELDA - 1 - yy) < corte)
                if not lleno(cx + 1, cy) and not lleno(cx, cy + 1) and not lleno(cx + 1, cy + 1):
                    bloque &= ~((CELDA - 1 - xx) + (CELDA - 1 - yy) < corte)
            else:
                # medio cuadrado en diagonal para unir dos celdas que se tocan en esquina
                bloque = np.zeros((CELDA, CELDA), bool)
                if lleno(cx + 1, cy) and lleno(cx, cy + 1):
                    bloque |= xx + yy >= CELDA - 1
                if lleno(cx - 1, cy) and lleno(cx, cy + 1):
                    bloque |= (CELDA - 1 - xx) + yy >= CELDA - 1
                if lleno(cx + 1, cy) and lleno(cx, cy - 1):
                    bloque |= xx + (CELDA - 1 - yy) >= CELDA - 1
                if lleno(cx - 1, cy) and lleno(cx, cy - 1):
                    bloque |= (CELDA - 1 - xx) + (CELDA - 1 - yy) >= CELDA - 1
            m[cy * CELDA:(cy + 1) * CELDA, cx * CELDA:(cx + 1) * CELDA] |= bloque
    return m


def dilatar(m, n=1):
    for _ in range(n):
        d = m.copy()
        d[1:, :] |= m[:-1, :]; d[:-1, :] |= m[1:, :]
        d[:, 1:] |= m[:, :-1]; d[:, :-1] |= m[:, 1:]
        m = d
    return m


def logo_limpio():
    """Las letras sin glitch, y aparte la máscara del tachado de la Ø."""
    letras = np.zeros((H, W), bool)
    tachado = np.zeros((H, W), bool)
    texto = "SECTOR CERO"
    ancho_total = sum(ESPACIO if ch == ' ' else ANCHO_LETRA for ch in texto) + SEPARACION * (len(texto) - 1)
    x = (W - ancho_total) // 2
    y = (H - ALTO_LETRA) // 2
    for i, ch in enumerate(texto):
        if ch == ' ':
            x += ESPACIO + SEPARACION
            continue
        letras[y:y + ALTO_LETRA, x:x + ANCHO_LETRA] |= mascara_letra(LETRAS[ch])
        if i == len(texto) - 1:
            # la O de CERO, tachada como en el icono: barra en diagonal que sobresale
            yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
            cx, cy = x + ANCHO_LETRA / 2 - 0.5, y + ALTO_LETRA / 2 - 0.5
            u = (xx - cx) * 0.55 - (yy - cy) * 0.83
            v = (xx - cx) * 0.83 + (yy - cy) * 0.55
            tachado = (np.abs(v) <= 3.2) & (np.abs(u) <= ALTO_LETRA / 2 + 4)
        x += ANCHO_LETRA + SEPARACION
    return letras, tachado


def pintar(letras, tachado, cortes=(), separacion_rgb=0):
    """Rellena con degradado, contorno, brillo, barrido y glitch."""
    yy, xx = np.mgrid[0:H, 0:W]
    b = bayer(H, W)
    a = np.zeros((H, W, 4), np.float64)
    forma = letras | tachado
    # brillo de neón alrededor (tramado)
    for d, alfa in ((2, 150), (4, 90), (7, 40)):
        anillo = dilatar(forma, d) & ~dilatar(forma, d - 1 if d > 1 else 0) if d > 1 else dilatar(forma, 1) & ~forma
        halo = dilatar(forma, d) & ~forma
        sel = halo & (a[..., 3] == 0) & (b < 1.0 - d / 9)
        a[sel] = (*NEON[2], alfa)
    # contorno
    borde = dilatar(forma, 2) & ~forma
    a[borde] = (*FONDO_CONTORNO, 255)
    # letras: degradado de arriba (casi blanco) a abajo (cian oscuro)
    arriba = (H - ALTO_LETRA) // 2
    t = np.clip((yy - arriba) / ALTO_LETRA, 0, 1)
    for i, (umbral, col) in enumerate(((0.0, NEON[4]), (0.22, NEON[3]), (0.55, NEON[2]), (0.85, NEON[1]))):
        sel = letras & (t + (b - 0.5) * 0.12 >= umbral)
        a[sel] = (*col, 255)
    # bisel: la fila de arriba de cada trazo, clara; la de abajo, oscura
    sube = letras & ~np.roll(letras, 1, axis=0)
    baja = letras & ~np.roll(letras, -1, axis=0)
    a[sube] = (*NEON[4], 255)
    a[baja] = (*NEON[0], 255)
    # líneas de barrido: una de cada cuatro filas, más oscura
    barrido = letras & (yy % 4 == 3)
    a[barrido, :3] *= 0.72
    # el tachado de la Ø, en rojo (la infección)
    a[tachado] = (*NEON[3], 255)
    nucleo = tachado & np.roll(tachado, 2, axis=1) & np.roll(tachado, -2, axis=1)
    a[nucleo] = (*NEON[4], 255)
    # glitch: franjas desplazadas con bordes rojo y cian
    for y0, alto, dx in cortes:
        franja = a[y0:y0 + alto].copy()
        a[y0:y0 + alto] = np.roll(franja, dx, axis=1)
        op = a[y0:y0 + alto, :, 3] > 200
        izq = op & ~np.roll(op, 1, axis=1)
        der = op & ~np.roll(op, -1, axis=1)
        a[y0:y0 + alto][izq] = (*ROJO[1], 255)
        a[y0:y0 + alto][der] = (*NEON[3], 255)
    if separacion_rgb:
        # separación de colores: el rojo hacia un lado y el azul hacia el otro
        r = np.roll(a[..., 0], separacion_rgb, axis=1)
        bl = np.roll(a[..., 2], -separacion_rgb, axis=1)
        al = np.maximum(a[..., 3], np.maximum(np.roll(a[..., 3], separacion_rgb, axis=1), np.roll(a[..., 3], -separacion_rgb, axis=1)))
        a[..., 0], a[..., 2], a[..., 3] = r, bl, al
    return np.clip(np.round(a), 0, 255).astype(np.uint8)


def generar(ruta_logo, ruta_tira):
    letras, tachado = logo_limpio()
    # el logo: dos cortes suaves
    Image.fromarray(pintar(letras, tachado, cortes=[(60, 3, 5)]), 'RGBA').save(ruta_logo)
    fotos = [
        pintar(letras, tachado, cortes=[(60, 3, 5)]),
        pintar(letras, tachado, cortes=[(40, 5, -9), (60, 3, 12), (82, 4, -6)]),
        pintar(letras, tachado, cortes=[(47, 8, 7), (70, 2, -14)], separacion_rgb=2),
        pintar(letras, tachado, cortes=[(58, 2, 3)]),
    ]
    hoja = np.concatenate(fotos, axis=1)
    Image.fromarray(hoja, 'RGBA').save(ruta_tira)
