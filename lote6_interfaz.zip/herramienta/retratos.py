"""Retratos de 64x64 de los tres personajes (lote 6): el busto de su hoja de
8 direcciones (mirando al frente) a x2, sobre un fondo con su color y con un
marco de neón de su color con las esquinas cortadas."""
import numpy as np
from PIL import Image

from pixel import bayer

PERSONAJES = {
    'mago': ('antivirus_8_direcciones.png', (191, 115, 255)),
    'espadachin': ('ciberespadachin_8_direcciones.png', (102, 255, 128)),
    'segador': ('segador_ciber_8_direcciones.png', (255, 89, 89)),
}
FONDO = (8, 16, 26)


def retrato(hoja, color):
    n = 64
    col = np.array(color, float)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    b = bayer(n, n)
    a = np.zeros((n, n, 4), np.float64)
    # fondo: oscuro, con un resplandor de su color detrás de la cabeza y rayas
    r = np.hypot((xx - 31.5) / 1.0, (yy - 26) / 1.1)
    mezcla = np.clip(0.42 - r / 70, 0, 0.42)
    fondo = np.array(FONDO, float)
    a[..., :3] = fondo + (col - fondo) * mezcla[..., None]
    a[..., 3] = 255
    rayas = ((xx + yy) % 6 == 0) & (b < 0.5)
    a[rayas, :3] = a[rayas, :3] * 0.8 + col * 0.06
    # el busto: 30x30 del fotograma de frente, a x2
    busto = np.array(Image.open(hoja).convert('RGBA').crop((17, 5, 47, 35)).resize((60, 60), Image.NEAREST)).astype(np.float64)
    al = busto[..., 3:4] / 255.0
    a[2:62, 2:62, :3] = busto[..., :3] * al + a[2:62, 2:62, :3] * (1 - al)
    # marco de 2 px de su color, con las esquinas cortadas
    borde = (xx < 2) | (xx > n - 3) | (yy < 2) | (yy > n - 3)
    esquina = np.minimum(np.minimum(xx, n - 1 - xx), 99) + np.minimum(yy, n - 1 - yy)
    claro = col + (255 - col) * 0.4
    oscuro = col * 0.45
    a[borde, :3] = col
    a[borde & ((xx < 1) | (yy < 1)), :3] = claro
    a[borde & ((xx > n - 2) | (yy > n - 2)), :3] = oscuro
    # esquinas cortadas a 45 grados (transparentes) con un remate claro
    corte = esquina < 5
    a[corte, 3] = 0
    filo = (esquina >= 5) & (esquina < 7)
    a[filo, :3] = claro
    a[filo, 3] = 255
    return np.clip(np.round(a), 0, 255).astype(np.uint8)


def generar(carpeta_hojas, carpeta):
    for nombre, (hoja, color) in PERSONAJES.items():
        Image.fromarray(retrato(f'{carpeta_hojas}/{hoja}', color), 'RGBA').save(f'{carpeta}/retrato_{nombre}.png')
