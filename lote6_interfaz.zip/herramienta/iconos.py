"""Iconos de 16x16 de Sector Cero (lote 6): las 11 mejoras y los 4 afijos.

Todos con el mismo estilo: contorno oscuro de 1 px puesto solo, tres tonos de
su color y un brillo casi blanco. Las herramientas van con el color de su
personaje y los afijos con el de su afijo.
"""
import math

import numpy as np
from PIL import Image

CONTORNO = (8, 12, 20)


def rampa(color):
    """Oscuro, medio, claro y casi blanco a partir de un color."""
    c = np.array(color, float)
    return {'D': tuple(int(v) for v in c * 0.5), 'M': tuple(int(v) for v in c),
            'L': tuple(int(v) for v in c + (255 - c) * 0.45), 'W': tuple(int(v) for v in c + (255 - c) * 0.85)}


def desde_texto(filas, colores):
    a = np.zeros((16, 16, 4), np.uint8)
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch != '.':
                a[y, x] = (*colores[ch], 255)
    return a


def contorno(a):
    op = a[..., 3] > 0
    v = np.zeros_like(op)
    v[1:, :] |= op[:-1, :]; v[:-1, :] |= op[1:, :]
    v[:, 1:] |= op[:, :-1]; v[:, :-1] |= op[:, 1:]
    a[v & ~op] = (*CONTORNO, 255)
    return a


def rejilla():
    yy, xx = np.mgrid[0:16, 0:16].astype(np.float64)
    return xx, yy


def pintar(a, mascara, col):
    a[mascara] = (*col, 255)


# ====================================================================== mejoras
def dano():
    c = rampa((255, 77, 102))
    c.update({'g': (236, 184, 64), 'G': (255, 230, 140), 'h': (90, 60, 40), 'P': (255, 214, 90)})
    return desde_texto([
        "................",
        ".............WL.",
        "............WLM.",
        "...........WLM..",
        "..........WLM...",
        ".........WLM....",
        "........WLM.....",
        "....g..WLM......",
        ".....gWLM.......",
        "......G.........",
        ".....h.g........",
        "....h...g.......",
        "..PP............",
        "..PP............",
        "................",
        "................",
    ], c)


def cadencia():
    c = rampa((255, 213, 74))
    return desde_texto([
        "................",
        "................",
        "..........LL....",
        "..DMMMMMMMWWL...",
        "..........LL....",
        "................",
        "........LL......",
        "DMMMMMMMWWL.....",
        "........LL......",
        "................",
        "..........LL....",
        "..DMMMMMMMWWL...",
        "..........LL....",
        "................",
        "................",
        "................",
    ], c)


def alcance():
    c = rampa((0, 217, 242))
    return desde_texto([
        "................",
        ".......WW.......",
        "......LMML......",
        "................",
        ".....LMMMM......",
        "....M......M....",
        ".L..M......M..L.",
        "WM.M...WW...M.MW",
        "WM.M...WW...M.MW",
        ".L..M......M..L.",
        "....M......M....",
        "......MMMMD.....",
        "................",
        "......LMML......",
        ".......WW.......",
        "................",
    ], c)


def velocidad():
    c = rampa((77, 255, 153))
    return desde_texto([
        "................",
        "................",
        "..LL....LL......",
        "...LL....LL.....",
        "....MM....MM....",
        ".....MM....MM...",
        "......MM....MM..",
        ".......MW....MW.",
        ".......MW....MW.",
        "......MM....MM..",
        ".....MM....MM...",
        "....MM....MM....",
        "...DD....DD.....",
        "..DD....DD......",
        "................",
        "................",
    ], c)


def vida():
    c = rampa((255, 90, 130))
    a = np.zeros((16, 16, 4), np.uint8)
    xx, yy = rejilla()
    corazon = (np.hypot(xx - 4.8, yy - 5.2) <= 3.3) | (np.hypot(xx - 10.2, yy - 5.2) <= 3.3)
    corazon |= (yy >= 5.2) & (np.abs(xx - 7.5) <= (13.6 - yy) * 0.95) & (yy <= 13.2)
    pintar(a, corazon, c['M'])
    pintar(a, corazon & (xx + yy > 18), c['D'])
    pintar(a, corazon & (np.hypot(xx - 4.6, yy - 4.4) <= 1.6), c['L'])
    a[3, 4] = (*c['W'], 255)
    # una cruz de "más" en el centro
    for x, y in ((8, 6), (8, 7), (8, 8), (7, 7), (9, 7)):
        a[y, x] = (*c['W'], 255)
    return a


def actualizar_firmas():
    c = rampa((90, 160, 255))
    from PIL import ImageDraw
    m = Image.new('L', (16, 16), 0)
    ImageDraw.Draw(m).polygon([(2, 1), (13, 1), (13, 8), (7.5, 14), (2, 8)], fill=255)
    escudo = np.array(m) > 0
    a = np.zeros((16, 16, 4), np.uint8)
    xx, yy = rejilla()
    pintar(a, escudo, c['M'])
    pintar(a, escudo & (xx > 8), c['D'])
    pintar(a, escudo & ((yy <= 1) | (xx <= 2)), c['L'])
    for x, y in ((4, 7), (5, 8), (6, 9), (7, 8), (8, 7), (9, 6), (10, 5), (11, 4), (5, 7), (6, 8), (7, 7), (8, 6), (9, 5), (10, 4)):
        a[y, x] = (*c['W'], 255)
    return a


def cambio_en_caliente():
    c = rampa((255, 154, 60))
    return desde_texto([
        "................",
        "................",
        "..........L.....",
        "..........LL....",
        "..DMMMMMMMWWL...",
        "..........LL....",
        "..........L.....",
        "................",
        "................",
        ".....L..........",
        "....LL..........",
        "...LWWMMMMMMMD..",
        "....LL..........",
        ".....L..........",
        "................",
        "................",
    ], c)


def cache_ampliada():
    c = rampa((232, 90, 255))
    c.update({'s': (225, 230, 240), 'S': (150, 160, 180), 'y': (255, 213, 74), 'Y': (255, 245, 190)})
    return desde_texto([
        "................",
        ".......Y........",
        "......yYy.......",
        ".......y........",
        "................",
        "..ss......ss....",
        "..SS......SS....",
        "..LM......LM....",
        "..LM......LM....",
        "..LM......LM....",
        "..LMM....MMD....",
        "...LMMMMMMD.....",
        "....DDDDDD......",
        "................",
        "................",
        "................",
    ], c)


def arma_ping():
    c = rampa((191, 115, 255))
    a = np.zeros((16, 16, 4), np.uint8)
    xx, yy = rejilla()
    r = np.hypot(xx - 3, yy - 12)
    cuarto = (xx >= 3) & (yy <= 12)
    pintar(a, cuarto & (np.abs(r - 5.0) < 0.8), c['M'])
    pintar(a, cuarto & (np.abs(r - 9.5) < 0.8), c['M'])
    pintar(a, cuarto & (np.abs(r - 5.0) < 0.8) & (xx - 3 < 12 - yy), c['L'])
    pintar(a, cuarto & (np.abs(r - 9.5) < 0.8) & (xx - 3 < 12 - yy), c['L'])
    pintar(a, r <= 1.6, c['W'])
    a[12, 4] = (*c['L'], 255)
    return a


def arma_firewall():
    c = rampa((102, 255, 128))
    c.update({'b': (40, 150, 70), 'B': (26, 100, 48), 'm': (10, 40, 20)})
    return desde_texto([
        "................",
        ".......W........",
        "......WLM.......",
        "...L..LWM...L...",
        "..LM.MLWLM.LM...",
        "..LMMLWWWLMLM...",
        "..MLLWWWWWLLM...",
        "...MLLWWWLLM....",
        ".mmmmmmmmmmmmm..",
        ".bbbmbbbbbmbbb..",
        ".BBBmBBBBBmBBB..",
        ".mmmmmmmmmmmmm..",
        ".bbbbbmbbbbbmb..",
        ".BBBBBmBBBBBmB..",
        ".mmmmmmmmmmmmm..",
        "................",
    ], c)


def arma_escaner():
    c = rampa((255, 89, 89))
    a = np.zeros((16, 16, 4), np.uint8)
    xx, yy = rejilla()
    r = np.hypot(xx - 7.5, yy - 7.5)
    th = (np.arctan2(yy - 7.5, xx - 7.5) + math.pi / 2 + 2 * math.pi) % (2 * math.pi)
    dentro = r <= 5.6
    # la estela del haz, detrás del haz (que apunta arriba a la derecha)
    pintar(a, dentro & (th > 0.25) & (th < 1.5), c['D'])
    pintar(a, dentro & (th > 0.25) & (th < 0.8), c['M'])
    pintar(a, dentro & (th <= 0.25) & (r > 0.8), c['W'])
    pintar(a, np.abs(r - 6.4) < 0.6, c['M'])
    pintar(a, (np.abs(r - 6.4) < 0.6) & (xx + yy < 14), c['L'])
    a[11, 5] = (*c['L'], 255)
    a[7, 7] = a[8, 8] = a[7, 8] = a[8, 7] = (*c['L'], 255)
    return a


# ====================================================================== afijos
def blindado():
    c = rampa((140, 190, 255))
    c.update({'r': (235, 240, 250)})
    return desde_texto([
        "................",
        "................",
        "....LLLLLLL.....",
        "...LMMMMMMMM....",
        "..LMrMMMMMrMD...",
        "..LMMMMMMMMMD...",
        "..WWWWWWWWWWD...",
        "..LLLLLLLLLLD...",
        "..LMMMMMMMMMD...",
        "..LMrMMMMMrMD...",
        "...MMMMMMMMD....",
        "....DDDDDDD.....",
        "................",
        "................",
        "................",
        "................",
    ], c)


def replicante():
    c = rampa((102, 255, 128))
    c.update({'g': (40, 110, 60)})
    return desde_texto([
        "................",
        ".....g..........",
        "....g.g.........",
        "...g...g........",
        "..g...LW........",
        ".g...LMMW.......",
        "..g.LMMMMW......",
        "...LMMDMMMW.....",
        "...gLMMMMMD.....",
        "....gLMMMD......",
        ".....gLMD.......",
        "......gD........",
        "................",
        "................",
        "................",
        "................",
    ], c)


def aura_lenta():
    c = rampa((153, 217, 255))
    a = np.zeros((16, 16, 4), np.uint8)
    for k in range(6):
        ang = k * math.pi / 3 + math.pi / 2
        for t in np.arange(0, 6.6, 0.5):
            x, y = 7.5 + math.cos(ang) * t, 7.5 + math.sin(ang) * t
            a[int(round(y)), int(round(x))] = (*c['M' if t > 1.5 else 'W'], 255)
        # ramitas
        for lado in (-1, 1):
            b = ang + lado * math.pi / 4
            px_, py_ = 7.5 + math.cos(ang) * 4, 7.5 + math.sin(ang) * 4
            for t in (1, 2):
                a[int(round(py_ + math.sin(b) * t)), int(round(px_ + math.cos(b) * t))] = (*c['L'], 255)
    a[7, 7] = a[8, 8] = a[7, 8] = a[8, 7] = (*c['W'], 255)
    return a


def explosivo():
    c = rampa((255, 128, 38))
    c.update({'k': (86, 78, 98), 'K': (146, 136, 160), 'h': (214, 206, 226), 'y': (255, 230, 120), 'f': (196, 156, 112)})
    return desde_texto([
        "................",
        "...........y..y.",
        "............Wy..",
        "...........yWW..",
        "..........f..y..",
        ".........f......",
        "......kkfk......",
        ".....kKKkkk.....",
        "....kKhKkkkk....",
        "....kKKkkkkM....",
        "....kkkkkkkM....",
        "....kkkkkkMM....",
        ".....kkkMML.....",
        "......MMMM......",
        "................",
        "................",
    ], c)


MEJORAS = {
    'dano': dano, 'cadencia': cadencia, 'alcance': alcance, 'velocidad': velocidad, 'vida': vida,
    'actualizar_firmas': actualizar_firmas, 'cambio_en_caliente': cambio_en_caliente,
    'cache_ampliada': cache_ampliada, 'arma_ping': arma_ping, 'arma_firewall': arma_firewall,
    'arma_escaner': arma_escaner,
}
AFIJOS = {'blindado': blindado, 'replicante': replicante, 'aura_lenta': aura_lenta, 'explosivo': explosivo}


def generar(carpeta_mejoras, carpeta_afijos):
    for nombre, f in MEJORAS.items():
        Image.fromarray(contorno(f()), 'RGBA').save(f'{carpeta_mejoras}/{nombre}.png')
    for nombre, f in AFIJOS.items():
        Image.fromarray(contorno(f()), 'RGBA').save(f'{carpeta_afijos}/{nombre}.png')
