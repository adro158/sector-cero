extends SceneTree

# Prueba temporal: fase 2 con el suelo dañado, NÚCLEO CERO quieto con el
# escudo levantado y una ancla de cada herramienta. Se rompen de una en una.
const HERRAMIENTAS := ["mago", "espadachin", "segador", "mago"]
var _raiz: Node
var _frames := 0
var _anclas: Array = []


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		var jugador: Node2D = _raiz.get_node("Jugador")
		jugador.get_node("Salud").invencible = true
		jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		root.get_node("BusEventos").fase_cambiada.emit(2)
		var jefe: Node2D = _raiz.get_node("JefeFinal")
		jefe.aparecer(jugador.global_position + Vector2(0, -60))
		jefe.process_mode = Node.PROCESS_MODE_DISABLED
		var escudo: Node2D = jefe.get_node("Escudo")
		escudo.process_mode = Node.PROCESS_MODE_ALWAYS
		_anclas = escudo.get_children()
		for i in _anclas.size():
			_anclas[i].herramienta = HERRAMIENTAS[i]
		escudo.levantar()
	for i in _anclas.size():
		if _frames == 60 + i * 25:
			_anclas[i].danar_en_area(_anclas[i].global_position, 5.0, 999999.0)
	return _frames > 60 + 4 * 25 + 30
