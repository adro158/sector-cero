"""Utilidades de pixel art para el jefe final de Sector Cero: capas RGBA de
numpy, polígonos, líneas, círculos, contornos y brillos tramados."""
import math
import numpy as np
from PIL import Image, ImageDraw

BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0 + 1 / 32.0
CONTORNO = (10, 6, 12)


def bayer(h, w):
    return np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w]


class Capa:
    def __init__(self, w, h=None):
        h = h or w
        self.w, self.h = w, h
        self.a = np.zeros((h, w, 4), np.float64)

    # ---------------------------------------------------------------- básico
    def px(self, x, y, c, alfa=255):
        x, y = int(round(x)), int(round(y))
        if 0 <= x < self.w and 0 <= y < self.h:
            self.a[y, x] = (*c[:3], alfa)

    def mascara_poligono(self, pts):
        m = Image.new('L', (self.w, self.h), 0)
        ImageDraw.Draw(m).polygon([(float(x), float(y)) for x, y in pts], fill=255)
        return np.array(m) > 0

    def mascara_elipse(self, cx, cy, rx, ry):
        yy, xx = np.mgrid[0:self.h, 0:self.w]
        return ((xx - cx) / max(rx, 1e-6)) ** 2 + ((yy - cy) / max(ry, 1e-6)) ** 2 <= 1.0

    def rellenar(self, mascara, color, alfa=255):
        self.a[mascara] = (*color[:3], alfa)

    def rellenar_rampa(self, mascara, rampa, campo, tramado=0.0):
        """campo: array 0..1 (1 = más claro) del tamaño de la capa. Con tramado,
        el paso entre colores se mezcla con el patrón Bayer en vez de ir a saltos."""
        if tramado:
            campo = campo + (bayer(self.h, self.w) - 0.5) * tramado
        t = np.clip(campo, 0, 0.9999)
        idx = (t * len(rampa)).astype(int)
        for i, col in enumerate(rampa):
            m = mascara & (idx == i)
            self.a[m] = (*col[:3], 255)

    def poligono(self, pts, color):
        self.rellenar(self.mascara_poligono(pts), color)

    def linea(self, p0, p1, color, ancho=1, alfa=255):
        (x0, y0), (x1, y1) = p0, p1
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for k in range(n + 1):
            x = x0 + (x1 - x0) * k / n
            y = y0 + (y1 - y0) * k / n
            for dx in range(ancho):
                for dy in range(ancho):
                    self.px(x + dx - (ancho - 1) / 2, y + dy - (ancho - 1) / 2, color, alfa)

    def polilinea(self, pts, color, ancho=1):
        for p0, p1 in zip(pts[:-1], pts[1:]):
            self.linea(p0, p1, color, ancho)

    def circulo(self, cx, cy, r, color, alfa=255):
        self.rellenar(self.mascara_elipse(cx, cy, r, r), color, alfa)

    def opaco(self):
        return self.a[..., 3] > 0

    # ---------------------------------------------------------------- acabados
    def contorno(self, color=CONTORNO, solo_fuera=True):
        op = self.a[..., 3] > 200
        vec = np.zeros_like(op)
        vec[1:, :] |= op[:-1, :]
        vec[:-1, :] |= op[1:, :]
        vec[:, 1:] |= op[:, :-1]
        vec[:, :-1] |= op[:, 1:]
        borde = vec & ~op
        if solo_fuera:
            borde &= self.a[..., 3] < 1
        self.a[borde] = (*color[:3], 255)

    def brillo(self, color, alfa, radio=2):
        """Halo tramado alrededor de lo opaco (sin tapar lo que ya hay)."""
        op = self.a[..., 3] > 0
        lejos = np.full(op.shape, 99.0)
        lejos[op] = 0
        # distancia aproximada por capas
        cur = op.copy()
        for r in range(1, radio + 1):
            nuevo = cur.copy()
            nuevo[1:, :] |= cur[:-1, :]
            nuevo[:-1, :] |= cur[1:, :]
            nuevo[:, 1:] |= cur[:, :-1]
            nuevo[:, :-1] |= cur[:, 1:]
            lejos[nuevo & ~cur] = r
            cur = nuevo
        b = bayer(self.h, self.w)
        for r in range(1, radio + 1):
            m = (lejos == r) & (b < 1.0 - (r - 1) / radio * 0.6)
            self.a[m] = (*color[:3], alfa * (1 - (r - 1) / (radio + 1)))

    def pegar(self, otra, ox=0, oy=0):
        """Pone otra capa (o array RGBA) encima, en ox, oy."""
        b = otra.a if isinstance(otra, Capa) else otra.astype(np.float64)
        h, w = b.shape[:2]
        x0, y0 = int(ox), int(oy)
        xs0, ys0 = max(0, -x0), max(0, -y0)
        xd0, yd0 = max(0, x0), max(0, y0)
        ancho = min(w - xs0, self.w - xd0)
        alto = min(h - ys0, self.h - yd0)
        if ancho <= 0 or alto <= 0:
            return
        src = b[ys0:ys0 + alto, xs0:xs0 + ancho]
        dst = self.a[yd0:yd0 + alto, xd0:xd0 + ancho]
        sa = src[..., 3:4] / 255.0
        da = dst[..., 3:4] / 255.0
        oa = sa + da * (1 - sa)
        rgb = np.where(oa > 0, (src[..., :3] * sa + dst[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6), 0)
        self.a[yd0:yd0 + alto, xd0:xd0 + ancho] = np.concatenate([rgb, oa * 255], axis=-1)

    def espejo(self):
        c = Capa(self.w, self.h)
        c.a = self.a[:, ::-1].copy()
        return c

    def desplazar(self, dx, dy):
        c = Capa(self.w, self.h)
        c.pegar(self, dx, dy)
        return c

    def uint8(self):
        return np.clip(np.round(self.a), 0, 255).astype(np.uint8)


def texto_pixel(capa, x, y, filas, color, escala=1):
    for r, fila in enumerate(filas):
        for k, v in enumerate(fila):
            if v in '1#':
                for dx in range(escala):
                    for dy in range(escala):
                        capa.px(x + k * escala + dx, y + r * escala + dy, color)


def camino_quebrado(rng, x, y, ang, largo, quiebro=0.5, paso=2.0):
    pts = [(x, y)]
    hecho = 0.0
    while hecho < largo:
        ang += rng.uniform(-quiebro, quiebro)
        x += math.cos(ang) * paso
        y += math.sin(ang) * paso
        hecho += paso
        pts.append((x, y))
    return pts
