"""Anclas del escudo de NÚCLEO CERO, una por herramienta (lote 2 de Sector Cero).

Misma forma y fotogramas que jefe_final_ancla.png y jefe_final_cadena.png,
pero el candado y la cadena van con el color del personaje cuya herramienta
las rompe, y en el candado brilla su emblema:

- mago:       cristal morado (#BF73FF)
- espadachin: espada verde   (#66FF80)
- segador:    guadaña roja   (#FF5959)

Saca, para cada uno:
- jefe_final_ancla_<personaje>.png   5 x 48x56 (0-3 brillando, 4 rota)
- jefe_final_cadena_<personaje>.png  2 x 16x10

Uso: python3 generar_anclas.py  (numpy y Pillow; usa pixel.py)
"""
import math
import os
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixel import Capa

OUT = './'
PLATA = [(52, 54, 74), (84, 88, 112), (124, 128, 154), (168, 172, 196), (214, 218, 236)]
# rampas de cada personaje: 0 y 1 muy oscuros, 2 oscuro, 3 su color, 4 claro, 5 casi blanco
RAMPAS = {
    'mago': [(34, 14, 58), (62, 26, 104), (110, 48, 176), (191, 115, 255), (222, 180, 255), (248, 236, 255)],
    'espadachin': [(8, 44, 22), (18, 90, 44), (40, 170, 80), (102, 255, 128), (180, 255, 190), (236, 255, 238)],
    'segador': [(52, 8, 14), (110, 18, 30), (190, 40, 52), (255, 89, 89), (255, 170, 160), (255, 236, 230)],
}
# emblemas de 11 x 12: W casi blanco, L claro, C color, D oscuro (el contorno se pone solo)
EMBLEMAS = {
    'mago': [
        ".....W.....",
        "....WLC....",
        "...WLLCC...",
        "..WLLLCCD..",
        ".WLLLLCCDD.",
        "LLLLLLCCCDD",
        ".LLLLCCCDD.",
        "..LLLCCDD..",
        "...LLCDD...",
        "....LCD....",
        ".....C.....",
        "...........",
    ],
    'espadachin': [
        ".....W.....",
        "....WWL....",
        "....WWL....",
        "....WWL....",
        "....WWL....",
        "....WWL....",
        "....WWL....",
        ".CCCCCCCCC.",
        ".D..DCD..D.",
        ".....D.....",
        "....LCC....",
        "...........",
    ],
    'segador': [
        "...CCCCCCD.",
        ".CCLLLLLLCD",
        "CLLWWW...CD",
        "LW.......CD",
        "W........CD",
        "W........CD",
        ".........CD",
        "........CD.",
        "........CD.",
        ".......CD..",
        ".......CD..",
        "......CD...",
    ],
}


def guardar(fotogramas, nombre):
    alto, ancho = fotogramas[0].h, fotogramas[0].w
    hoja = np.zeros((alto, ancho * len(fotogramas), 4), np.uint8)
    for i, c in enumerate(fotogramas):
        hoja[:, i * ancho:(i + 1) * ancho] = c.uint8()
    Image.fromarray(hoja, 'RGBA').save(OUT + nombre)


def emblema(capa, quien, x0, y0, brillo):
    """Pinta el emblema con su contorno oscuro; `brillo` (0-3) aclara los colores."""
    R = RAMPAS[quien]
    col = {'W': R[5], 'L': R[4], 'C': R[3], 'D': R[2]}
    sube = {'D': 'C', 'C': 'L', 'L': 'W', 'W': 'W'}
    figura = Capa(capa.w, capa.h)
    for y, fila in enumerate(EMBLEMAS[quien]):
        for x, ch in enumerate(fila):
            if ch == '.':
                continue
            # en el fotograma más brillante todo sube un tono
            if brillo == 2:
                ch = sube[ch]
            figura.px(x0 + x, y0 + y, col[ch])
    op = figura.a[..., 3] > 0
    borde = np.zeros_like(op)
    borde[1:, :] |= op[:-1, :]; borde[:-1, :] |= op[1:, :]
    borde[:, 1:] |= op[:, :-1]; borde[:, :-1] |= op[:, 1:]
    capa.rellenar(borde & ~op, R[0])
    capa.pegar(figura)


def ancla(quien):
    R = RAMPAS[quien]
    fotos = []
    for f in range(5):
        capa = Capa(48, 56)
        rota = f == 4
        # base
        for y in range(44, 54):
            for x in range(8, 40):
                capa.px(x, y, PLATA[2] if y == 44 else (PLATA[1] if y < 50 else PLATA[0]))
        # columna, con una franja de su color
        for y in range(18 if not rota else 30, 44):
            for x in range(16, 32):
                capa.px(x, y, PLATA[3] if x < 20 else (PLATA[2] if x < 28 else PLATA[1]))
        franja = [R[3], R[4], R[5], R[4]][f % 4] if not rota else R[1]
        for x in range(16, 32):
            capa.px(x, 36, franja if x < 28 else R[2])
            capa.px(x, 37, R[2] if not rota else R[0])
        if not rota:
            # el arco del candado
            for y in range(2, 14):
                for x in range(16, 33):
                    d = math.hypot(x - 24, y - 13)
                    if 5.5 <= d <= 8.5 and y <= 13:
                        capa.px(x, y, PLATA[3] if x < 24 else PLATA[2])
            # el cuerpo: oscuro, con un marco de neón de su color
            for y in range(12, 29):
                for x in range(11, 38):
                    capa.px(x, y, R[1] if x < 30 else R[0])
            marco = [R[3], R[4], R[3], R[3]][f % 4]
            for x in range(11, 38):
                capa.px(x, 12, R[4]); capa.px(x, 28, R[2])
            for y in range(12, 29):
                capa.px(11, y, marco); capa.px(37, y, R[2])
            for x in range(12, 37):
                capa.px(x, 13, R[2])
            # el emblema, que late
            emblema(capa, quien, 19, 15, [1, 2, 1, 0][f % 4])
            # argolla de la cadena a un lado
            capa.rellenar(capa.mascara_elipse(41, 31, 3, 3), PLATA[3])
            capa.px(41, 31, (20, 20, 30))
        else:
            # roto: trozos del candado en el suelo y la columna partida
            for (x, y, c) in ((10, 41, R[3]), (14, 43, R[2]), (34, 42, R[3]), (38, 40, R[2]), (22, 39, R[4]), (27, 42, R[1])):
                capa.circulo(x, y, 2, c)
            capa.linea((16, 30), (22, 27), PLATA[3], 2); capa.linea((22, 27), (31, 31), PLATA[2], 2)
        capa.contorno()
        if not rota:
            halo = Capa(48, 56)
            halo.a = capa.a.copy()
            halo.brillo(R[3], [90, 120, 140, 110][f % 4], 2)
            halo.a[capa.a[..., 3] > 0] = 0
            halo.pegar(capa)
            capa = halo
        fotos.append(capa)
    guardar(fotos, f'jefe_final_ancla_{quien}.png')


def cadena(quien):
    R = RAMPAS[quien]
    fotos = []
    for f in range(2):
        capa = Capa(16, 10)
        a, b = (0, 9) if f == 0 else (9, 0)
        # eslabón de lado (dos raíles) y eslabón de frente (una barra)
        for x in range(a + 1 if a == 0 else a, a + 8):
            capa.px(x, 3, R[4]); capa.px(x, 6, R[2])
        capa.px(a if a == 0 else a - 1, 4, R[3]); capa.px(a if a == 0 else a - 1, 5, R[3])
        capa.px(a + 8 if a == 0 else a + 7, 4, R[3]); capa.px(a + 8 if a == 0 else a + 7, 5, R[3])
        for x in range(b, b + 7):
            capa.px(x, 4, R[4]); capa.px(x, 5, R[3])
        # la energía que pasa por la cadena
        capa.px(4 + f * 8, 4, R[5])
        capa.px(4 + f * 8, 5, R[4])
        capa.contorno((10, 6, 12))
        fotos.append(capa)
    guardar(fotos, f'jefe_final_cadena_{quien}.png')


if __name__ == '__main__':
    for quien in RAMPAS:
        ancla(quien)
        cadena(quien)
    print('ok')
