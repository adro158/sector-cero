Hoy toca lo de los **candados de NÚCLEO CERO** del punto 3.5 de `requisitos_y_estado.md`: cada ancla del escudo solo recibe daño de una herramienta y se ve de qué color es. Los sprites los he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y cómo vas a hacer que cada ancla solo reciba daño de su herramienta. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 2 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `anclas_en_juego.gif`: grabado en Godot 4.7.2 en la fase 2, con NÚCLEO CERO y el escudo de verdad
- `vista_lote2.png`: las de ahora y las nuevas, a x2

Los detalles de cada sprite están en `LEEME.txt`.

## Los sprites

En `projecte/medios/sprites/jefe_final/`, con la misma forma, tamaño y fotogramas que `jefe_final_ancla.png` y `jefe_final_cadena.png`:

| Ancla (5 x 48x56) | Cadena (2 x 16x10) | Herramienta | Color |
|---|---|---|---|
| `jefe_final_ancla_mago.png` | `jefe_final_cadena_mago.png` | Ping | morado #BF73FF, con un cristal |
| `jefe_final_ancla_espadachin.png` | `jefe_final_cadena_espadachin.png` | Firewall | verde #66FF80, con una espada |
| `jefe_final_ancla_segador.png` | `jefe_final_cadena_segador.png` | Escáner | rojo #FF5959, con una guadaña |

Fotogramas 0-3 brillando y el 4 rota, como ahora. Las evoluciones de cada herramienta cuentan como la herramienta.

## Lo que quiero (punto 3.5 de `requisitos_y_estado.md`)

- **Una herramienta por ancla.** Cada ancla solo recibe daño de la herramienta de su color: hay que ir cambiando de personaje.
  - Son 4 anclas y 3 herramientas: propónme cómo repartirlas (por ejemplo, una de cada y la cuarta al azar), y que no queden dos del mismo color juntas si es fácil.
  - Si un personaje ha caído, que no salga un ancla que solo él puede romper. Propón tú cómo.
- **Más vida:** las anclas pasan de 300 a unos 800, por la dificultad. Si no se rompen las 4 en 12 s, las rotas se vuelven a cerrar.
- **Que se note de quién es cada una:**
  - la barra de vida del ancla, del color de su herramienta
  - su ficha (click en el ancla), con su sprite y su color
  - cuando le pega una herramienta que no es la suya, un aviso pequeño (por ejemplo un "0" gris o un destello apagado), para que se entienda que así no se rompe. Propón lo más simple.

`referencia/anclas_por_herramienta.diff` es el cambio probado **solo del dibujo**:
- en `dibujo_jefe_final.gd`, los diccionarios `ANCLAS` y `CADENAS`
- `cadena()` acepta la hoja
- cada ancla tiene `herramienta`

No hace lo del daño. Haz el código como veas más fácil de explicar.

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`.
- Con ventana, haz que salga el jefe final con el escudo (menú de desarrollador, F1, o una instrumentación temporal). Haz capturas de:
  - las cuatro anclas con su color
  - una herramienta pegando a un ancla que no es la suya
  - las anclas rotas
  - las rotas cerrándose otra vez a los 12 s

  Borra la instrumentación al acabar.
- **Simulador:** el bot tiene que cambiar de personaje para romper las anclas. Pasa 10 partidas por dificultad y dame las victorias y dónde muere el bot. Antes de tocar números, compáralo con las victorias que queremos en cada dificultad (están en `requisitos_y_estado.md`).
- **Documentación:**
  - `creditos.md`: los sprites del lote 2 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md`, el manual y el panel de reglas (cómo se rompe el escudo).
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/` y la documentación. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- **Commits pequeños** con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat` con las anclas por herramienta
  - `docs`
- No publiques ninguna release.
