Hoy toca que **las evoluciones se vean en el personaje**: cuando evoluciona la herramienta de un personaje, su arma cambia de aspecto, con unas hojas de sprites que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo, aunque el CLAUDE.md diga que no se añada contenido.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y espera a que te diga que sí.

He descomprimido `armas_evolucionadas.zip` en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `vista_armas_evolucionadas.png`: la hoja de siempre al lado de la evolucionada
- `armas_evolucionadas_en_juego.gif`: grabado en una partida real (Godot 4.7.2, `--write-movie`) con estos PNG y con los cambios de `referencia/`

## Las hojas

En `projecte/escenas/jugabilidad/jugador/`, al lado de las de siempre:

| Fichero | Personaje | Evolución | Qué cambia |
|---|---|---|---|
| `segador_ciber_8_direcciones_evolucion.png` | Segador | Análisis heurístico | Guadaña más grande con el lomo de oro y dos púas, runas que se encienden, una luz de escaneo que recorre la hoja, energía roja que sube por el mango y brasas en la punta |
| `antivirus_8_direcciones_evolucion.png` | Mago | Ping de inundación | Dos puntas moradas que abrazan la calavera, ondas de ping que salen de ella, orbes que giran, los ojos al blanco y energía cian por el mango |
| `ciberespadachin_8_direcciones_evolucion.png` | Espadachín | Firewall perimetral | Espada más larga y ancha, con tramos como ladrillos, llamas verdes a los lados, guarda de oro con una gema y más brillo |

Tienen **el mismo formato que las de siempre**: 384x576, 6 columnas (pasos) por 8 filas (direcciones) de 64x72, con el mismo orden de filas. El cuerpo es idéntico píxel a píxel; solo cambia el arma. Los efectos (escaneo, ondas, llamas, energía) van con los 6 fotogramas de andar. Quieto se ve el fotograma 0, como ahora, así que los efectos se paran: me vale así.

## Cómo integrarlo

`referencia/hoja_evolucion.diff` es el cambio probado:

1. `datos_personaje.gd`: un `@export var hoja_evolucion: Texture2D` debajo de `hoja`.
2. Los tres `.tres` de `recursos/personajes/datos/`: `hoja_evolucion` apuntando a su PNG. Deja que Godot les ponga el `uid` al importar.
3. `cambio_personaje.gd`, en `_aplicar()`: si el arma del personaje ya no es la de sus datos (`_armas[_indice] != personaje.arma`), pone `hoja_evolucion` en el `Sprite`; si no, `hoja`.

Así vale también cuando evoluciona un personaje que está en el banquillo: `evolucionar()` solo llama a `_aplicar()` si es el activo, y al entrar después ya sale con la hoja nueva. Está probado con `referencia/captura_evolucion.gd`: cada personaje anda, evoluciona y sigue andando; al final pasa por los tres y los tres tienen la hoja evolucionada.

- No hay señales nuevas, ni `class_name` nuevo, ni cambios en `project.godot`: no hace falta subir `EJECUTABLE_MINIMO`.
- El panel de reglas sigue usando `hoja` para el icono del personaje, y está bien.
- `cambio_personaje.gd` ya tiene 230 líneas y pasa a 232. Si lo ves mejor, saca la elección de la hoja a una función pequeña, pero que siga siendo fácil de explicar.
- Si ves una forma más sencilla de hacerlo, propónmela antes.

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`. Después, con ventana, da las tres evoluciones desde el menú de desarrollador (F1) y haz capturas de cada personaje andando, antes y después.
- Comprueba también que cambiar de personaje con E/Q después de evolucionar uno deja a cada uno con su hoja.
- No cambia el balance: no hace falta el simulador, pero pasa una partida para comprobar que no salen errores.
- Documentación:
  - `creditos.md`: las hojas evolucionadas son de Claude, con IA, como las de los personajes.
  - `documentacion_tecnica.md`: lo de la hoja al evolucionar.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/`. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- Commits con la convención de `documentacio/flujo_de_trabajo.md`: uno `assets` con los tres PNG, otro `feat` con el cambio de hoja y otro `docs`.
- No publiques ninguna release.
