"""Remove the staff (pole, skull, ribbons, head glow, sparks) from the original frames."""
from seg import *

N4 = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])
N8 = np.ones((3, 3), bool)


def grip_hand(F, staff_like, face):
    """Skin component touching the staff = the hand that held it."""
    skin = cmask(F, SKIN) & ~face
    lab, n = ndi.label(skin, structure=N8)
    near = ndi.binary_dilation(staff_like, structure=N8, iterations=1)
    best, bn = None, 0
    for i in range(1, n + 1):
        comp = lab == i
        k = (comp & near).sum()
        if k > bn:
            bn, best = k, comp
    return best


def remove_staff(F, S):
    H, W = F.shape[:2]
    out = F.copy()
    op = F[..., 3] == 255
    outl = cmask(F, OUTLINE)
    # ribbon incl. its orange highlights (flood from the red ribbon over red+orange)
    ro = cmask(F, RED | ORANGE) & ~S['lining']
    lab, n = ndi.label(ro, structure=N4)
    rib = S['ribbon'].copy()
    for i in range(1, n + 1):
        comp = lab == i
        if (comp & S['ribbon']).any():
            rib |= comp
    rib[S['sk_box'][3] + 24:] = False
    staff_like = S['staff'] | S['skull'] | rib
    # skull eye pixels / dark skull details sit inside the skull bbox
    x0, y0, x1, y1 = S['sk_box']
    box = np.zeros_like(op)
    box[max(0, y0 - 1):y1 + 2, max(0, x0 - 1):x1 + 2] = True
    staff_like |= box & op & ~cmask(F, ROBE) & ~S['face'] & ~S['lining'] & ~outl
    hand = grip_hand(F, S['staff'], S['face'])
    # metal spike at the bottom of the pole (bone/skin coloured pixels touching the pole, below the hand)
    if hand is not None:
        hy = np.nonzero(hand)[0].max()
        tipc = cmask(F, BONE | SKIN) & ~S['face'] & ~hand
        grow = staff_like.copy()
        for _ in range(3):
            add = ndi.binary_dilation(grow, structure=N8) & tipc
            add[:hy + 3] = False
            grow |= add
        staff_like = grow

    R = staff_like.copy()
    R |= outl & ndi.binary_dilation(staff_like, structure=N8)
    if hand is not None:
        R &= ~hand
    body = op & ~R

    # head glow + staff sparks
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    yy, xx = np.mgrid[0:H, 0:W]
    glow = (F[..., 3] > 0) & (F[..., 3] < 255) & (F[..., 0] > 100)
    near_head = (xx - cx) ** 2 + (yy - cy) ** 2 < 11 ** 2
    out[glow & near_head] = 0
    out[cmask(F, MAGIC_STAFF)] = 0

    body_fill = body & ~outl
    for y, x in zip(*np.nonzero(R)):
        row = body[y]
        col = body[:, x]
        left = row[max(0, x - 7):x].any()
        right = row[x + 1:x + 8].any()
        up = col[max(0, y - 7):y].any()
        down = col[y + 1:y + 8].any()
        inside = left and right and up and down
        if inside:
            # nearest non-outline body pixel on this row
            cand = [(abs(xx_ - x), xx_) for xx_ in range(max(0, x - 9), min(W, x + 10)) if body_fill[y, xx_]]
            if cand:
                _, sx = min(cand)
                out[y, x] = F[y, sx]
                continue
        out[y, x] = (0, 0, 0, 0)
    # re-outline: removed pixels now empty but touching the body
    newop = out[..., 3] == 255
    solid = newop & ~cmask(out, OUTLINE)
    edge = R & ~newop & ndi.binary_dilation(solid, structure=N4)
    out[edge] = (*list(OUTLINE)[0], 255)
    # a removed pixel might have been an outline between body and pole: keep the silhouette closed
    return out, hand


if __name__ == '__main__':
    A = np.zeros((5 * FH, 6 * FW, 4), np.uint8)
    for d in range(5):
        for f in range(6):
            F = frame(d, f)
            S = segment(F)
            o, hand = remove_staff(F, S)
            A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW] = o
            if hand is not None:
                ys, xs = np.nonzero(hand)
                print(d, f, 'hand', xs.mean().round(1), ys.mean().round(1), len(xs))
            else:
                print(d, f, 'NO HAND')
    im = Image.fromarray(A)
    bg = Image.new('RGBA', im.size, (120, 130, 120, 255))
    bg.alpha_composite(im)
    bg.resize((im.width * 4, im.height * 4), Image.NEAREST).save(BASE + 'nostaff.png')
