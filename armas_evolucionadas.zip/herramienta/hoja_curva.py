"""Rasteriza una hoja curva a partir de una línea central con grosor por punto.
Cada píxel recibe una letra según lo cerca que está del filo (lado cóncavo) o
del lomo (lado convexo): W filo, L, R, D y G el lomo."""
import numpy as np


def rasterizar(puntos, grosores, ancho, alto, capas=(('W', 0.2), ('L', 0.4), ('R', 0.7), ('D', 0.84), ('G', 1.01))):
    P, Wd = [], []
    for (a, b), (wa, wb) in zip(zip(puntos[:-1], puntos[1:]), zip(grosores[:-1], grosores[1:])):
        for t in np.linspace(0, 1, 60, endpoint=False):
            P.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
            Wd.append(wa + (wb - wa) * t)
    P.append(puntos[-1]); Wd.append(grosores[-1])
    P, Wd = np.array(P, float), np.array(Wd)
    T = np.gradient(P, axis=0)
    T /= np.maximum(np.linalg.norm(T, axis=1)[:, None], 1e-9)
    N = np.stack([T[:, 1], -T[:, 0]], 1)   # a la izquierda de la marcha: el lomo
    g = np.full((alto, ancho), '.', '<U1')
    u_campo = np.full((alto, ancho), -1.0)
    for r in range(alto):
        for c in range(ancho):
            q = np.array([c + 0.5, r + 0.5])
            dd = np.linalg.norm(P - q, axis=1)
            i = int(dd.argmin())
            d = float(np.dot(q - P[i], N[i]))
            w = Wd[i]
            # en los extremos de la línea no se alarga más allá del punto
            if dd[i] > abs(d) + 0.6:
                continue
            if abs(d) <= w / 2:
                u = (d + w / 2) / max(w, 1e-6)
                for letra, lim in capas:
                    if u < lim:
                        g[r, c] = letra
                        break
                u_campo[r, c] = u
    return g, u_campo
