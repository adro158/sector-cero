"""Semantic segmentation of the necromancer sprite frames (64x72)."""
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

import os
BASE = os.path.dirname(os.path.abspath(__file__)) + '/'
ATLAS = np.array(Image.open(BASE + 'orig/necromante_sprites/atlas_8dir_64px.png').convert('RGBA')).astype(np.int32)
FW, FH = 64, 72


def frame(d, f):
    return ATLAS[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW].copy()


OUTLINE = {(12, 6, 10)}
ROBE = {(18, 13, 18), (24, 18, 24), (30, 22, 28), (38, 28, 36), (44, 32, 40), (54, 40, 50),
        (60, 44, 52), (72, 54, 64), (80, 60, 68), (94, 72, 82)}
LEGS = {(22, 16, 20), (30, 22, 26), (32, 24, 28), (42, 32, 38), (54, 42, 48), (14, 10, 12)}
BOOTS = {(20, 12, 10), (30, 18, 14), (32, 20, 16), (46, 30, 22), (48, 30, 22), (62, 42, 30),
         (68, 44, 30), (80, 56, 40), (92, 62, 42), (118, 82, 56)}
STAFF = {(30, 20, 16), (50, 34, 24), (72, 50, 34), (96, 68, 46), (122, 90, 62)}
BELT = {(62, 36, 22), (86, 52, 30)}
RED = {(34, 10, 12), (40, 6, 10), (62, 10, 16), (70, 10, 16), (90, 16, 22), (104, 18, 24),
       (120, 26, 30), (140, 28, 32), (150, 24, 24), (176, 44, 40), (170, 30, 30), (150, 40, 40),
       (80, 20, 20)}
ORANGE = {(120, 40, 20), (160, 64, 28), (196, 96, 40), (210, 72, 54), (224, 132, 60)}
FACE_ONLY = {(40, 20, 24), (70, 54, 54), (80, 60, 60), (82, 66, 64), (96, 84, 80), (104, 92, 86),
             (122, 110, 102)}
SKIN = {(80, 70, 66), (114, 102, 94), (148, 136, 124), (180, 168, 154), (206, 196, 182)}
BONE = {(92, 80, 66), (132, 118, 98), (172, 158, 134), (206, 194, 168), (234, 226, 202)}
EYE = {(255, 64, 64)}
MAGIC_HAND = {(176, 24, 64), (238, 64, 104), (255, 120, 150), (255, 160, 180)}
MAGIC_STAFF = {(240, 90, 120), (255, 190, 200), (200, 30, 60), (130, 16, 40)}


def cmask(F, cset):
    rgb = F[..., :3]
    op = F[..., 3] == 255
    m = np.zeros(F.shape[:2], bool)
    for c in cset:
        m |= (rgb[..., 0] == c[0]) & (rgb[..., 1] == c[1]) & (rgb[..., 2] == c[2])
    return m & op


def segment(F):
    """Return dict of boolean masks for special parts of the frame."""
    op = F[..., 3] == 255
    bone = cmask(F, BONE | SKIN | EYE)
    eye = cmask(F, EYE)
    red = cmask(F, RED)

    # --- skull: bone component (8-conn) with the smallest top y
    lab, n = ndi.label(bone, structure=np.ones((3, 3)))
    best, besty = None, 999
    for i in range(1, n + 1):
        ys, xs = np.nonzero(lab == i)
        if len(ys) >= 6 and ys.min() < besty:
            besty, best = ys.min(), i
    skull = lab == best
    ys, xs = np.nonzero(skull)
    sk_box = (xs.min(), ys.min(), xs.max(), ys.max())

    # --- face: component of face/skin/eye colors that contains face-only colours or a face eye
    facec = cmask(F, FACE_ONLY | SKIN | EYE) & ~skull
    lab, n = ndi.label(facec, structure=np.ones((3, 3)))
    face = np.zeros_like(op)
    seeds = cmask(F, FACE_ONLY) | (eye & ~skull)
    for i in range(1, n + 1):
        comp = lab == i
        if (comp & seeds).any():
            face |= comp
    face_eye = eye & face
    # hood lining = red pixels touching the face (grow twice)
    lining = np.zeros_like(op)
    if face.any():
        cur = face.copy()
        for _ in range(2):
            grow = ndi.binary_dilation(cur, structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])) & red & ~lining
            lining |= grow
            cur = cur | grow

    # --- ribbon: red pixels flood-filled from those near the skull
    x0, y0, x1, y1 = sk_box
    near = np.zeros_like(op)
    near[max(0, y0 - 2):y1 + 4, max(0, x0 - 3):x1 + 4] = True
    lab, n = ndi.label(red & ~lining, structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]]))
    ribbon = np.zeros_like(op)
    for i in range(1, n + 1):
        comp = lab == i
        if (comp & near).any():
            ribbon |= comp
    ribbon[y1 + 22:] = False

    return dict(skull=skull, sk_box=sk_box, face=face, face_eye=face_eye, lining=lining, ribbon=ribbon,
                robe=cmask(F, ROBE), staff=cmask(F, STAFF))
