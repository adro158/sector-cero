"""Third cyber mage: black / red / gold, gold visor, energy scythe."""
from render import make_circuit_texture, best_shift, lum, atlas
from nostaff import *

MAP3 = {
    (12, 6, 10): (8, 6, 8),
    # robe -> near black
    (94, 72, 82): (80, 76, 80), (80, 60, 68): (64, 60, 64), (72, 54, 64): (56, 52, 57),
    (60, 44, 52): (44, 41, 45), (54, 40, 50): (38, 35, 39), (44, 32, 40): (31, 29, 33),
    (38, 28, 36): (27, 25, 29), (30, 22, 28): (21, 20, 23), (24, 18, 24): (17, 16, 19),
    (18, 13, 18): (13, 12, 15),
    # legs
    (14, 10, 12): (12, 10, 12), (22, 16, 20): (26, 24, 27), (30, 22, 26): (32, 30, 34),
    (32, 24, 28): (34, 32, 36), (42, 32, 38): (44, 41, 46), (54, 42, 48): (58, 54, 60),
    # boots -> black steel
    (20, 12, 10): (18, 17, 19), (30, 18, 14): (24, 23, 26), (32, 20, 16): (27, 26, 29),
    (46, 30, 22): (36, 34, 38), (48, 30, 22): (38, 36, 40), (62, 42, 30): (48, 46, 51),
    (68, 44, 30): (52, 50, 55), (80, 56, 40): (64, 61, 67), (92, 62, 42): (72, 69, 76),
    (118, 82, 56): (96, 92, 100),
    # scythe pole: black steel with gold inlay
    (30, 20, 16): (18, 16, 18), (50, 34, 24): (36, 33, 37), (72, 50, 34): (54, 50, 56),
    (96, 68, 46): (200, 150, 50), (122, 90, 62): (250, 212, 110),
    # belt
    (62, 36, 22): (40, 36, 40), (86, 52, 30): (60, 56, 62),
    # red cloth -> crimson
    (34, 10, 12): (36, 6, 12), (40, 6, 10): (42, 6, 12), (62, 10, 16): (70, 10, 20),
    (70, 10, 16): (80, 12, 22), (80, 20, 20): (92, 14, 26), (90, 16, 22): (104, 16, 28),
    (104, 18, 24): (122, 18, 32), (120, 26, 30): (142, 22, 36), (140, 28, 32): (166, 26, 40),
    (150, 24, 24): (176, 26, 40), (150, 40, 40): (180, 34, 46), (170, 30, 30): (200, 34, 46),
    (176, 44, 40): (214, 48, 56),
    # orange trim -> gold
    (120, 40, 20): (140, 96, 24), (160, 64, 28): (190, 136, 36), (196, 96, 40): (236, 184, 64),
    (210, 72, 54): (240, 176, 70), (224, 132, 60): (255, 226, 130),
    # hands -> black steel gauntlets
    (80, 70, 66): (40, 38, 42), (114, 102, 94): (58, 55, 61), (148, 136, 124): (80, 76, 84),
    (180, 168, 154): (106, 101, 110), (206, 196, 182): (136, 130, 140),
    # face-only (fallback)
    (40, 20, 24): (6, 4, 6), (70, 54, 54): (6, 4, 6), (80, 60, 60): (6, 4, 6),
    (82, 66, 64): (6, 4, 6), (96, 84, 80): (6, 4, 6), (104, 92, 86): (6, 4, 6),
    (122, 110, 102): (6, 4, 6),
    # bone ornaments -> gold
    (92, 80, 66): (120, 80, 20), (132, 118, 98): (170, 122, 34), (172, 158, 134): (214, 166, 56),
    (206, 194, 168): (244, 206, 100), (234, 226, 202): (255, 236, 160),
    (255, 64, 64): (255, 214, 90),
    # off-hand magic -> red embers
    (176, 24, 64): (130, 10, 20), (238, 64, 104): (230, 40, 40), (255, 120, 150): (255, 110, 80),
    (255, 160, 180): (255, 190, 140),
    (240, 90, 120): (255, 110, 80), (255, 190, 200): (255, 190, 140), (200, 30, 60): (230, 40, 40),
    (130, 16, 40): (130, 10, 20),
}
GLOW3 = (255, 40, 50)
VOID3, RIM3 = (6, 4, 6), (16, 10, 12)
VISOR_HI, VISOR, VISOR_LO = (255, 246, 200), (255, 208, 80), (170, 104, 20)
CIRC3, CIRC3_DIM, NODE3 = (226, 38, 50), (146, 24, 36), (255, 196, 110)

# scythe head, drawn for a blade that sticks out to the right (mirrored for the left)
BLADE = [
    ".oooooo.......",
    "oDRRRRRooo....",
    "oDRRRRRRRRoo..",
    "oDRLLLLLRRRRo.",
    ".oWWWWWLLLLRRo",
    "..oo...WWWWLRo",
    "........oooWRo",
    "...........oWo",
    "............o.",
]
BLADE_COL = {'o': (70, 6, 14), 'D': (150, 18, 30), 'R': (236, 42, 50), 'L': (255, 120, 96),
             'W': (255, 228, 206)}
GOLD_D, GOLD, GOLD_L = (150, 100, 24), (230, 176, 60), (255, 230, 140)
POLE_D, POLE = (18, 16, 18), (54, 50, 56)
OUT = (8, 6, 8)


def remove_head(F, S):
    """Remove skull, ribbons, head glow and sparks but keep the pole."""
    H, W = F.shape[:2]
    out = F.copy()
    op = F[..., 3] == 255
    outl = cmask(F, OUTLINE)
    ro = cmask(F, RED | ORANGE) & ~S['lining']
    lab, n = ndi.label(ro, structure=N4)
    rib = S['ribbon'].copy()
    for i in range(1, n + 1):
        comp = lab == i
        if (comp & S['ribbon']).any():
            rib |= comp
    rib[S['sk_box'][3] + 24:] = False
    x0, y0, x1, y1 = S['sk_box']
    box = np.zeros_like(op)
    box[max(0, y0 - 1):y1 + 2, max(0, x0 - 1):x1 + 2] = True
    kill = S['skull'] | rib | (box & op & ~cmask(F, ROBE) & ~S['face'] & ~S['lining'] & ~outl & ~S['staff'])
    R = kill | (outl & ndi.binary_dilation(kill, structure=N8))
    body = op & ~R
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    yy, xx = np.mgrid[0:H, 0:W]
    glow = (F[..., 3] > 0) & (F[..., 3] < 255) & (F[..., 0] > 100)
    out[glow & ((xx - cx) ** 2 + (yy - cy) ** 2 < 11 ** 2)] = 0
    out[cmask(F, MAGIC_STAFF)] = 0
    body_fill = body & ~outl
    for y, x in zip(*np.nonzero(R)):
        row, col = body[y], body[:, x]
        inside = row[max(0, x - 7):x].any() and row[x + 1:x + 8].any() and \
            col[max(0, y - 7):y].any() and col[y + 1:y + 8].any()
        if inside:
            cand = [(abs(q - x), q) for q in range(max(0, x - 9), min(W, x + 10)) if body_fill[y, q]]
            if cand:
                out[y, x] = F[y, min(cand)[1]]
                continue
        out[y, x] = (0, 0, 0, 0)
    newop = out[..., 3] == 255
    solid = newop & ~cmask(out, OUTLINE)
    edge = R & ~newop & ndi.binary_dilation(solid, structure=N4)
    out[edge] = (*list(OUTLINE)[0], 255)
    return out


def put(out, x, y, col, a=255):
    H, W = out.shape[:2]
    if not (0 <= x < W and 0 <= y < H):
        return
    if a == 255:
        out[y, x] = (*col, 255)
    elif out[y, x, 3] < a:
        out[y, x] = (*col, a)


def draw_scythe(out, S, staff_mask):
    H, W = out.shape[:2]
    x0, y0, x1, y1 = S['sk_box']
    cy = (y0 + y1 + 1) // 2
    # pole x from the pole pixels just below the old skull
    ys, xs = np.nonzero(staff_mask[y1 + 1:y1 + 8])
    px = int(round(xs.mean())) if len(xs) else (x0 + x1 + 1) // 2
    s = 1 if px >= 32 else -1
    ty = cy - 1
    # pole extension from ty to the existing pole
    ybot = y1 + 2
    for y in range(ty, ybot + 1):
        if out[y, px, 3] == 255 and y > y1:
            break
        put(out, px - 1, y, OUT); put(out, px + 1, y, OUT)
        put(out, px, y, POLE)
    # blade (plus glow behind it on empty pixels)
    bx0 = px + s * 1
    by0 = ty - 2
    pix = []
    for r, row in enumerate(BLADE):
        for c, ch in enumerate(row):
            if ch == '.':
                continue
            x = bx0 + s * c
            y = by0 + r
            pix.append((x, y, BLADE_COL[ch]))
    m = np.zeros((H, W), bool)
    for x, y, _ in pix:
        if 0 <= x < W and 0 <= y < H:
            m[y, x] = True
    g1 = ndi.binary_dilation(m, structure=N8) & ~m
    g2 = ndi.binary_dilation(m, structure=N8, iterations=2) & ~m & ~g1
    for y, x in zip(*np.nonzero(g2)):
        put(out, x, y, GLOW3, 34)
    for y, x in zip(*np.nonzero(g1)):
        put(out, x, y, GLOW3, 80)
    for x, y, col in pix:
        put(out, x, y, col)
    # gold collar + finial
    for dx in (-1, 0, 1):
        put(out, px + dx, ty, GOLD if dx else GOLD_L)
        put(out, px + dx, ty + 1, GOLD_D if dx else GOLD)
    put(out, px - 2, ty, OUT); put(out, px + 2, ty, OUT)
    put(out, px - 2, ty + 1, OUT); put(out, px + 2, ty + 1, OUT)
    put(out, px, ty - 1, GOLD)
    put(out, px, ty - 2, GOLD_L)
    put(out, px - 1, ty - 1, OUT); put(out, px + 1, ty - 1, OUT)
    put(out, px - 1, ty - 2, OUT); put(out, px + 1, ty - 2, OUT)
    put(out, px, ty - 3, OUT)


def convert3(F, S, tex, shift):
    H, W = F.shape[:2]
    base = remove_head(F, S)
    out = base.copy()
    for y in range(H):
        for x in range(W):
            a = base[y, x, 3]
            if a == 0:
                continue
            c = tuple(int(v) for v in base[y, x, :3])
            if a == 255:
                out[y, x, :3] = MAP3[c]
            elif c != (0, 0, 0):
                out[y, x, :3] = GLOW3
    dy, dx = shift
    robe = cmask(base, ROBE)
    for y in range(H):
        for x in range(W):
            if not robe[y, x]:
                continue
            ty, tx = y - dy, x - dx
            if not (0 <= ty < H and 0 <= tx < W) or tex[ty, tx] == 0:
                continue
            if tex[ty, tx] == 2:
                out[y, x, :3] = NODE3
            elif lum(tuple(int(v) for v in base[y, x, :3])) >= 40:
                out[y, x, :3] = CIRC3
            else:
                out[y, x, :3] = CIRC3_DIM
    # face: black void with a glowing gold visor across the eye line
    out[S['lining'], :3] = RIM3
    out[S['face'], :3] = VOID3
    eyes = np.nonzero(S['face_eye'])
    if len(eyes[0]):
        ey = int(eyes[0].min())
        row = np.nonzero(S['face'][ey])[0]
        if len(row):
            xa, xb = row.min(), row.max()
            if xb - xa >= 4:
                xa, xb = xa + 1, xb - 1
            mid = (xa + xb) / 2
            for x in range(xa, xb + 1):
                out[ey, x, :3] = VISOR_HI if abs(x - mid) <= 0.6 else VISOR
                if S['face'][ey + 1, x]:
                    out[ey + 1, x, :3] = VISOR_LO
    draw_scythe(out, S, cmask(base, STAFF))
    return out.astype(np.uint8)


def build_all3():
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        base0 = remove_head(frame(d, 0), segs[0])
        robe0 = cmask(base0, ROBE)
        tex = make_circuit_texture(robe0, seed=4242 + 31 * d)
        for f in range(6):
            F = frame(d, f)
            b = remove_head(F, segs[f])
            shift = best_shift(robe0, cmask(b, ROBE))
            frames[(d, f)] = convert3(F, segs[f], tex, shift)
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(6):
            frames[(dst, f)] = frames[(src, f)][:, ::-1].copy()
    return frames


if __name__ == '__main__':
    fr = build_all3()
    A = Image.fromarray(atlas(fr))
    A.save(BASE + 'new3_atlas_64.png')
    bg = Image.new('RGBA', A.size, (28, 28, 36, 255))
    bg.alpha_composite(A)
    im = bg.resize((A.width * 4, A.height * 4), Image.NEAREST)
    im.crop((0, 0, im.width, im.height // 2)).save(BASE + 'p3_top.png')
    im.crop((0, im.height // 2, im.width, im.height)).save(BASE + 'p3_bot.png')
    cells = [(0, 0), (1, 2), (2, 3), (3, 1), (4, 0)]
    z = Image.new('RGBA', (len(cells) * 64 * 6, 72 * 6), (28, 28, 36, 255))
    for i, (d, f) in enumerate(cells):
        z.alpha_composite(A.crop((f * 64, d * 72, f * 64 + 64, d * 72 + 72)).resize((384, 432), Image.NEAREST), (i * 384, 0))
    z.save(BASE + 'p3_zoom.png')
