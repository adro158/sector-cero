"""Turn the necromancer sprites into the cyber/tech wizard look."""
import random
from seg import *

# ------------------------------------------------------------------ palette
MAP = {
    # outline
    (12, 6, 10): (10, 9, 20),
    # robe (dark plum -> dark slate blue)
    (94, 72, 82): (92, 106, 148), (80, 60, 68): (74, 84, 124), (72, 54, 64): (66, 74, 112),
    (60, 44, 52): (54, 58, 92), (54, 40, 50): (48, 50, 82), (44, 32, 40): (40, 41, 70),
    (38, 28, 36): (34, 34, 60), (30, 22, 28): (28, 28, 50), (24, 18, 24): (22, 21, 40),
    (18, 13, 18): (17, 16, 31),
    # legs / trousers
    (14, 10, 12): (14, 14, 24), (22, 16, 20): (28, 30, 44), (30, 22, 26): (36, 38, 54),
    (32, 24, 28): (38, 40, 58), (42, 32, 38): (50, 54, 76), (54, 42, 48): (66, 72, 98),
    # boots -> gunmetal armour boots
    (20, 12, 10): (18, 19, 30), (30, 18, 14): (24, 26, 40), (32, 20, 16): (27, 29, 44),
    (46, 30, 22): (36, 39, 58), (48, 30, 22): (38, 41, 60), (62, 42, 30): (48, 52, 74),
    (68, 44, 30): (52, 56, 80), (80, 56, 40): (64, 70, 96), (92, 62, 42): (72, 78, 106),
    (118, 82, 56): (96, 104, 136),
    # staff wood -> dark metal pole with a glowing cable
    (30, 20, 16): (20, 22, 34), (50, 34, 24): (38, 42, 60), (72, 50, 34): (56, 62, 86),
    (96, 68, 46): (56, 136, 235), (122, 90, 62): (100, 235, 150),
    # belt leather -> dark metal belt
    (62, 36, 22): (42, 46, 66), (86, 52, 30): (62, 68, 94),
    # red cloth -> violet
    (34, 10, 12): (30, 14, 52), (40, 6, 10): (34, 12, 58), (62, 10, 16): (52, 20, 92),
    (70, 10, 16): (58, 22, 100), (80, 20, 20): (66, 28, 112), (90, 16, 22): (74, 30, 128),
    (104, 18, 24): (86, 36, 150), (120, 26, 30): (100, 44, 172), (140, 28, 32): (118, 52, 200),
    (150, 24, 24): (126, 54, 210), (150, 40, 40): (130, 62, 214), (170, 30, 30): (144, 66, 232),
    (176, 44, 40): (150, 76, 240),
    # orange trim -> neon violet
    (120, 40, 20): (110, 56, 190), (160, 64, 28): (150, 84, 235), (196, 96, 40): (184, 112, 255),
    (210, 72, 54): (196, 110, 255), (224, 132, 60): (222, 170, 255),
    # skin (hands) -> metal gloves
    (80, 70, 66): (44, 48, 68), (114, 102, 94): (60, 66, 90), (148, 136, 124): (80, 88, 116),
    (180, 168, 154): (106, 116, 146), (206, 196, 182): (134, 144, 172),
    # face-only colours (only used if a face pixel escaped the face mask)
    (40, 20, 24): (8, 8, 16), (70, 54, 54): (8, 8, 16), (80, 60, 60): (8, 8, 16),
    (82, 66, 64): (8, 8, 16), (96, 84, 80): (8, 8, 16), (104, 92, 86): (8, 8, 16),
    (122, 110, 102): (8, 8, 16),
    # bone ornaments -> steel buckles / studs
    (92, 80, 66): (56, 62, 84), (132, 118, 98): (84, 92, 120), (172, 158, 134): (114, 124, 154),
    (206, 194, 168): (146, 156, 184), (234, 226, 202): (184, 194, 216),
    (255, 64, 64): (120, 255, 255),
    # pink magic -> green / cyan data sparks
    (176, 24, 64): (20, 140, 90), (238, 64, 104): (60, 220, 130), (255, 120, 150): (120, 255, 170),
    (255, 160, 180): (190, 255, 215),
    (240, 90, 120): (90, 240, 200), (255, 190, 200): (205, 255, 240), (200, 30, 60): (40, 200, 170),
    (130, 16, 40): (20, 120, 110),
}
GLOW_RGB = (70, 235, 190)

VOID = (5, 5, 11)
VOID_RIM = (13, 13, 25)
EYE_CORE = (175, 255, 255)
EYE_LOW = (45, 185, 220)

CIRCUIT = (168, 84, 246)
CIRCUIT_DIM = (116, 56, 186)
NODE = (230, 170, 255)

CABLES = [(255, 142, 44), (80, 222, 96), (64, 146, 255)]

# CPU chip, 9x9 including pins. '.' = leave as is
CHIP = [
    ". . p . p . p . .",
    ". O O O O O O O .",
    "p O B M M M M O p",
    ". O M g G g m O .",
    "p O M G C G m O p",
    ". O M b G b m O .",
    "p O M m m m m O p",
    ". O O O O O O O .",
    ". . p . p . p . .",
]
CHIP_COL = {
    'O': (16, 18, 32), 'M': (74, 84, 108), 'B': (112, 124, 150), 'm': (54, 62, 84),
    'p': (150, 160, 178),
    'g': (60, 200, 170), 'G': (90, 240, 190), 'b': (50, 150, 230), 'C': (215, 255, 240),
}
LEDS = [(255, 150, 40), (255, 228, 60), (100, 240, 90), (70, 225, 255)]


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def shade(col, k):
    return tuple(int(max(0, min(255, round(v * k)))) for v in col)


# ------------------------------------------------------------------ circuit texture
def make_circuit_texture(robe0, seed):
    """Random circuit traces (vertical runs, 45deg jogs, short horizontal stubs, end nodes)."""
    rng = random.Random(seed)
    H, W = robe0.shape
    tex = np.zeros((H, W), np.uint8)  # 0 none, 1 trace, 2 node
    interior = ndi.binary_erosion(robe0, structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]]))
    ys, xs = np.nonzero(interior)
    if len(xs) == 0:
        return tex
    occupied = np.zeros((H, W), bool)

    def free(path):
        for px, py in path:
            if not (0 <= px < W and 0 <= py < H) or not interior[py, px]:
                return False
            if occupied[max(0, py - 2):py + 3, max(0, px - 2):px + 3].any():
                return False
        return True

    pts = list(zip(xs, ys))
    rng.shuffle(pts)
    budget = len(pts) // 48
    for (x, y) in pts:
        if budget <= 0:
            break
        if occupied[max(0, y - 2):y + 3, max(0, x - 2):x + 3].any():
            continue
        path = [(x, y)]
        cx, cy = x, y
        segs = rng.choice([['v'], ['v', 'd', 'v'], ['v', 'd', 'v'], ['v', 'd'], ['d', 'v'], ['v', 'h']])
        for s in segs:
            if s == 'v':
                n = rng.randint(3, 7)
                for _ in range(n):
                    cy += 1; path.append((cx, cy))
            elif s == 'd':
                dxs = rng.choice([-1, 1])
                for _ in range(rng.randint(1, 2)):
                    cx += dxs; cy += 1; path.append((cx, cy))
            else:
                dxs = rng.choice([-1, 1])
                for _ in range(2):
                    cx += dxs; path.append((cx, cy))
        if len(path) < 5 or not free(path):
            continue
        budget -= 1
        for px, py in path:
            tex[py, px] = 1
            occupied[py, px] = True
        tex[path[-1][1], path[-1][0]] = 2
        if rng.random() < 0.35:
            tex[path[0][1], path[0][0]] = 2
    return tex


def best_shift(ref, cur):
    best, bs = (0, 0), -1
    for dy in range(-4, 5):
        for dx in range(-3, 4):
            s = (np.roll(np.roll(ref, dy, 0), dx, 1) & cur).sum()
            if s > bs:
                bs, best = s, (dy, dx)
    return best


# ------------------------------------------------------------------ main conversion
def convert(F, S, tex, shift):
    H, W = F.shape[:2]
    out = F.copy()
    op = F[..., 3] == 255
    rgb = F[..., :3]

    # 1. palette remap of opaque pixels
    for y in range(H):
        for x in range(W):
            a = F[y, x, 3]
            if a == 0:
                continue
            c = tuple(int(v) for v in rgb[y, x])
            if a == 255:
                if c in MAP:
                    out[y, x, :3] = MAP[c]
                else:
                    raise KeyError(c)
            elif c != (0, 0, 0):  # translucent glow
                out[y, x, :3] = GLOW_RGB

    # 2. robe circuits (texture moves with the body bob)
    dy, dx = shift
    robe = S['robe']
    for y in range(H):
        for x in range(W):
            if not robe[y, x]:
                continue
            ty, tx = y - dy, x - dx
            if not (0 <= ty < H and 0 <= tx < W):
                continue
            t = tex[ty, tx]
            if t == 0:
                continue
            base = tuple(int(v) for v in F[y, x, :3])
            if t == 2:
                out[y, x, :3] = NODE
            elif lum(base) >= 40:
                out[y, x, :3] = CIRCUIT
            else:
                out[y, x, :3] = CIRCUIT_DIM

    # 3. hood opening -> black void with glowing cyan eyes
    out[S['lining'], :3] = VOID_RIM
    out[S['face'], :3] = VOID
    for y, x in zip(*np.nonzero(S['face_eye'])):
        out[y, x, :3] = EYE_CORE
        if y + 1 < H and S['face'][y + 1, x] and not S['face_eye'][y + 1, x]:
            out[y + 1, x, :3] = EYE_LOW

    # 4. ribbons -> loose coloured cables (1px strands with gaps)
    rib = S['ribbon']
    if rib.any():
        rys, rxs = np.nonzero(rib)
        x0 = rxs.min()
        for y, x in zip(rys, rxs):
            k = x - x0
            if k % 2 == 1:
                out[y, x] = (0, 0, 0, 0)
                continue
            l = lum(tuple(int(v) for v in F[y, x, :3]))
            f = 0.55 + 0.6 * min(1.0, l / 70.0)
            out[y, x, :3] = shade(CABLES[(k // 2) % 3], f)
            out[y, x, 3] = 255
        # drop the old ribbon outline where it now floats in the air
        outl = cmask(F, OUTLINE)
        ribd = ndi.binary_dilation(rib, structure=np.ones((3, 3)))
        other = op & ~rib & ~outl
        near_other = ndi.binary_dilation(other, structure=np.ones((3, 3)))
        kill = outl & ribd & ~near_other
        out[kill] = (0, 0, 0, 0)

    # 5. skull -> glowing CPU chip with status LEDs
    x0, y0, x1, y1 = S['sk_box']
    cx, cy = (x0 + x1 + 1) // 2, (y0 + y1 + 1) // 2
    # wipe the skull itself (the chip is drawn on top)
    out[S['skull']] = (0, 0, 0, 0)
    for j, row in enumerate(CHIP):
        for i, ch in enumerate(row.split(' ')):
            if ch == '.':
                continue
            px, py = cx - 4 + i, cy - 4 + j
            if 0 <= px < W and 0 <= py < H:
                out[py, px] = (*CHIP_COL[ch], 255)
    for i, col in enumerate(LEDS):
        px, py = cx - 3 + 2 * i, cy - 6
        if 0 <= px < W and 0 <= py < H:
            out[py, px] = (*col, 255)
    # remove leftover outline pixels of the skull that are now floating
    return out.astype(np.uint8)


def build_all():
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        tex = make_circuit_texture(segs[0]['robe'], seed=1000 + d)
        for f in range(6):
            F = frame(d, f)
            shift = best_shift(segs[0]['robe'], segs[f]['robe'])
            frames[(d, f)] = convert(F, segs[f], tex, shift)
    # mirrored directions: 6<-4, 7<-3, 8<-2 (0-based 5<-3, 6<-2, 7<-1)
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(6):
            frames[(dst, f)] = frames[(src, f)][:, ::-1].copy()
    return frames


def atlas(frames):
    A = np.zeros((8 * FH, 6 * FW, 4), np.uint8)
    for (d, f), fr in frames.items():
        A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW] = fr
    return A


if __name__ == '__main__':
    fr = build_all()
    A = Image.fromarray(atlas(fr))
    A.save(BASE + 'new_atlas_64.png')
    bg = Image.new('RGBA', A.size, (28, 28, 36, 255))
    bg.alpha_composite(A)
    bg.resize((A.width * 4, A.height * 4), Image.NEAREST).save(BASE + 'new_atlas_preview.png')
