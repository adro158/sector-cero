"""Second cyber mage: green/black + amber accents, energy sword instead of a staff."""
import math
from render import make_circuit_texture, best_shift, lum, atlas
from nostaff import *

MAP2 = {
    (12, 6, 10): (7, 12, 9),
    # robe -> charcoal with a green tint
    (94, 72, 82): (86, 100, 94), (80, 60, 68): (68, 80, 75), (72, 54, 64): (60, 71, 67),
    (60, 44, 52): (48, 57, 53), (54, 40, 50): (42, 50, 47), (44, 32, 40): (35, 42, 39),
    (38, 28, 36): (30, 36, 34), (30, 22, 28): (24, 29, 27), (24, 18, 24): (19, 24, 22),
    (18, 13, 18): (15, 19, 18),
    # legs
    (14, 10, 12): (12, 16, 14), (22, 16, 20): (26, 32, 29), (30, 22, 26): (33, 40, 36),
    (32, 24, 28): (35, 43, 38), (42, 32, 38): (46, 56, 50), (54, 42, 48): (60, 72, 65),
    # boots -> gunmetal
    (20, 12, 10): (20, 22, 22), (30, 18, 14): (26, 29, 29), (32, 20, 16): (29, 32, 32),
    (46, 30, 22): (38, 42, 42), (48, 30, 22): (40, 44, 44), (62, 42, 30): (50, 55, 55),
    (68, 44, 30): (54, 60, 60), (80, 56, 40): (66, 72, 72), (92, 62, 42): (74, 81, 80),
    (118, 82, 56): (98, 106, 104),
    # (staff colours, only in case a pixel survived)
    (30, 20, 16): (22, 26, 26), (50, 34, 24): (40, 46, 46), (72, 50, 34): (58, 66, 64),
    (96, 68, 46): (80, 90, 88), (122, 90, 62): (100, 112, 108),
    # belt
    (62, 36, 22): (44, 50, 48), (86, 52, 30): (64, 72, 70),
    # red cloth -> emerald
    (34, 10, 12): (10, 36, 20), (40, 6, 10): (11, 42, 22), (62, 10, 16): (14, 64, 32),
    (70, 10, 16): (16, 72, 36), (80, 20, 20): (19, 84, 41), (90, 16, 22): (21, 94, 46),
    (104, 18, 24): (24, 110, 53), (120, 26, 30): (29, 127, 61), (140, 28, 32): (34, 146, 71),
    (150, 24, 24): (36, 155, 74), (150, 40, 40): (41, 158, 78), (170, 30, 30): (44, 173, 83),
    (176, 44, 40): (54, 186, 94),
    # orange trim -> bright lime
    (120, 40, 20): (40, 160, 70), (160, 64, 28): (70, 210, 90), (196, 96, 40): (120, 250, 120),
    (210, 72, 54): (110, 240, 120), (224, 132, 60): (190, 255, 180),
    # hands -> metal gloves
    (80, 70, 66): (46, 52, 50), (114, 102, 94): (62, 70, 68), (148, 136, 124): (84, 94, 90),
    (180, 168, 154): (110, 122, 118), (206, 196, 182): (140, 152, 146),
    # face-only (fallback)
    (40, 20, 24): (4, 8, 6), (70, 54, 54): (4, 8, 6), (80, 60, 60): (4, 8, 6),
    (82, 66, 64): (4, 8, 6), (96, 84, 80): (4, 8, 6), (104, 92, 86): (4, 8, 6),
    (122, 110, 102): (4, 8, 6),
    # bone ornaments -> steel
    (92, 80, 66): (58, 66, 64), (132, 118, 98): (86, 96, 92), (172, 158, 134): (116, 128, 122),
    (206, 194, 168): (150, 162, 156), (234, 226, 202): (190, 202, 196),
    (255, 64, 64): (255, 205, 60),
    # off-hand magic -> amber sparks
    (176, 24, 64): (150, 80, 10), (238, 64, 104): (240, 150, 30), (255, 120, 150): (255, 200, 80),
    (255, 160, 180): (255, 232, 150),
    (240, 90, 120): (255, 200, 80), (255, 190, 200): (255, 232, 150), (200, 30, 60): (240, 150, 30),
    (130, 16, 40): (150, 80, 10),
}
GLOW2 = (255, 170, 40)
VOID2, RIM2 = (4, 8, 6), (10, 18, 14)
EYE_CORE2, EYE_LOW2 = (255, 216, 80), (225, 125, 20)
CIRC2, CIRC2_DIM, NODE2 = (52, 196, 90), (32, 126, 60), (170, 255, 180)

# energy sword
POMMEL = (190, 202, 196)
HANDLE = (30, 34, 34)
GUARD = (86, 96, 92)
GUARD_TIP = (255, 190, 50)
BLADE_CORE = (235, 255, 235)
BLADE_MID = (100, 255, 140)
BLADE_EDGE = (40, 200, 90)
BLADE_GLOW = (80, 255, 130)

# blade direction (screen space) for the 5 unique directions
SWORD_DIR = {0: (0.36, 1.0), 1: (-0.36, 1.0), 2: (-0.55, 1.0), 3: (0.36, 1.0), 4: (-0.36, 1.0)}
BLADE_LEN = 17


def put(out, x, y, col, a=255, over=True):
    H, W = out.shape[:2]
    x, y = int(round(x)), int(round(y))
    if not (0 <= x < W and 0 <= y < H):
        return
    if a == 255:
        out[y, x] = (*col, 255)
    else:
        # translucent glow only onto empty / translucent pixels
        if out[y, x, 3] == 255:
            return
        if out[y, x, 3] < a:
            out[y, x] = (*col, a)


def draw_sword(out, hand, d):
    ys, xs = np.nonzero(hand)
    gx, gy = xs.mean(), ys.mean()
    dx, dy = SWORD_DIR[d]
    n = math.hypot(dx, dy)
    ux, uy = dx / n, dy / n
    t0 = 3.0
    t1 = t0 + BLADE_LEN
    # glow first (behind the blade, only on empty pixels)
    t = t0 - 0.5
    while t <= t1 + 1.5:
        cx, cy = gx + ux * t, gy + uy * t
        for o, a in ((-2, 70), (2, 70), (-3, 28), (3, 28)):
            put(out, cx + o, cy, BLADE_GLOW, a)
        t += 0.5
    for extra, a in ((2.0, 70), (3.0, 30)):
        put(out, gx + ux * (t1 + extra), gy + uy * (t1 + extra), BLADE_GLOW, a)
    # blade
    t = t0
    while t <= t1:
        cx, cy = gx + ux * t, gy + uy * t
        tip = t > t1 - 2.5
        if not tip:
            put(out, cx - 1, cy, BLADE_EDGE if ux > 0 else BLADE_MID)
            put(out, cx + 1, cy, BLADE_MID if ux > 0 else BLADE_EDGE)
        else:
            put(out, cx - (1 if ux > 0 else -1), cy, BLADE_EDGE) if t < t1 - 1.2 else None
        put(out, cx, cy, BLADE_CORE)
        t += 0.5
    # guard (horizontal bar with amber tips)
    cx, cy = gx + ux * 2.0, gy + uy * 2.0
    for o in (-2, -1, 0, 1, 2):
        put(out, cx + o, cy, GUARD_TIP if abs(o) == 2 else GUARD)
    put(out, cx, cy, POMMEL)
    # handle end + pommel sticking out above the hand
    put(out, gx - ux * 2.0, gy - uy * 2.0, HANDLE)
    put(out, gx - ux * 3.0, gy - uy * 3.0, POMMEL)
    # outline the hard metal bits so they read on light backgrounds
    return out


def convert2(F, S, tex, shift, d):
    H, W = F.shape[:2]
    base, hand = remove_staff(F, S)
    out = base.copy()
    for y in range(H):
        for x in range(W):
            a = base[y, x, 3]
            if a == 0:
                continue
            c = tuple(int(v) for v in base[y, x, :3])
            if a == 255:
                out[y, x, :3] = MAP2[c]
            elif c != (0, 0, 0):
                out[y, x, :3] = GLOW2
    # circuits
    dy, dx = shift
    robe = cmask(base, ROBE)
    for y in range(H):
        for x in range(W):
            if not robe[y, x]:
                continue
            ty, tx = y - dy, x - dx
            if not (0 <= ty < H and 0 <= tx < W):
                continue
            t = tex[ty, tx]
            if t == 0:
                continue
            if t == 2:
                out[y, x, :3] = NODE2
            elif lum(tuple(int(v) for v in base[y, x, :3])) >= 40:
                out[y, x, :3] = CIRC2
            else:
                out[y, x, :3] = CIRC2_DIM
    # face
    out[S['lining'], :3] = RIM2
    out[S['face'], :3] = VOID2
    for y, x in zip(*np.nonzero(S['face_eye'])):
        out[y, x, :3] = EYE_CORE2
        if y + 1 < H and S['face'][y + 1, x] and not S['face_eye'][y + 1, x]:
            out[y + 1, x, :3] = EYE_LOW2
    # sword, then the hand back on top of the grip
    if hand is not None:
        hand_px = out[hand].copy()
        draw_sword(out, hand, d)
        out[hand] = hand_px
    return out.astype(np.uint8)


def build_all2():
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        base0, _ = remove_staff(frame(d, 0), segs[0])
        robe0 = cmask(base0, ROBE)
        tex = make_circuit_texture(robe0, seed=7000 + 13 * d)
        for f in range(6):
            F = frame(d, f)
            b, _ = remove_staff(F, segs[f])
            shift = best_shift(robe0, cmask(b, ROBE))
            frames[(d, f)] = convert2(F, segs[f], tex, shift, d)
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(6):
            frames[(dst, f)] = frames[(src, f)][:, ::-1].copy()
    return frames


if __name__ == '__main__':
    fr = build_all2()
    A = Image.fromarray(atlas(fr))
    A.save(BASE + 'new2_atlas_64.png')
    bg = Image.new('RGBA', A.size, (28, 28, 36, 255))
    bg.alpha_composite(A)
    bg.resize((A.width * 4, A.height * 4), Image.NEAREST).save(BASE + 'new2_atlas_preview.png')
    im = bg.resize((A.width * 4, A.height * 4), Image.NEAREST)
    im.crop((0, 0, im.width, im.height // 2)).save(BASE + 'p2_top.png')
    im.crop((0, im.height // 2, im.width, im.height)).save(BASE + 'p2_bot.png')
