"""Segador con la guadaña evolucionada (Escáner -> Análisis heurístico).

Es la misma hoja de siempre (se genera igual, con render3.py) cambiando solo
la guadaña:
- hoja más grande y gruesa, con el lomo de oro y runas grabadas que se
  encienden por turnos
- una luz de escaneo que recorre la hoja del mango a la punta (6 fotogramas)
- energía roja que sube por el mango
- brillo más fuerte y brasas que caen de la punta

Uso: python3 generar_segador_evolucion.py [salida.png]
"""
import sys

import numpy as np
from PIL import Image

import evo_comun as ec
import render3 as r3
from render import make_circuit_texture, best_shift
from seg import segment, frame, cmask, ROBE
from hoja_curva import rasterizar

ESTADO = {'f': 0}

OUT = r3.OUT
GOLD_D, GOLD, GOLD_L = r3.GOLD_D, r3.GOLD, r3.GOLD_L
POLE = r3.POLE
GLOW = (255, 46, 56)

# la hoja, hacia la derecha (en espejo si el mango está a la izquierda): una
# media luna con el lomo de oro arriba y el filo blanco abajo, que acaba en un
# gancho hacia abajo
FORMA, _ = rasterizar([(0.5, 6), (4.5, 4), (9, 3.6), (12.2, 5.4), (13.7, 9), (13.1, 13)],
                      [3.2, 4.6, 5.2, 4.6, 3.0, 0.8], 15, 15)
FORMA[12:, :][FORMA[12:, :] != '.'] = 'W'          # la punta, al rojo blanco
for c in (3, 6, 9):                                 # runas grabadas en el centro
    filas = [r for r in range(15) if FORMA[r, c] == 'R']
    if filas:
        FORMA[filas[len(filas) // 2], c] = 'r'
# dos púas de oro en el lomo
PUAS = []
for c in (5, 10):
    arriba = min(r for r in range(FORMA.shape[0]) if FORMA[r, c] != '.')
    PUAS += [(c, arriba - 1, 'G'), (c - 1, arriba - 2, 'A')]
COL = {'o': (70, 6, 14), 'G': (236, 184, 64), 'g': (150, 100, 24), 'D': (150, 18, 30),
       'R': (236, 42, 50), 'r': (100, 10, 22), 'L': (255, 120, 96), 'W': (255, 228, 206),
       'H': (255, 255, 240), 'A': (255, 214, 120)}
# la luz de escaneo sube un tono cada color
ESCANEO = {'D': 'R', 'R': 'L', 'L': 'W', 'W': 'H', 'G': 'A', 'g': 'G', 'r': 'A'}
# la energía del mango
PULSO, PULSO_D = (255, 86, 70), (170, 28, 40)


def dibujar_guadana_evolucionada(out, S, staff_mask):
    f = ESTADO['f']
    H, W = out.shape[:2]
    x0, y0, x1, y1 = S['sk_box']
    cy = (y0 + y1 + 1) // 2
    ys, xs = np.nonzero(staff_mask[y1 + 1:y1 + 8])
    px = int(round(xs.mean())) if len(xs) else (x0 + x1 + 1) // 2
    s = 1 if px >= 32 else -1
    ty = cy - 1

    # el mango, como el de siempre
    ybot = y1 + 2
    for y in range(ty, ybot + 1):
        if out[y, px, 3] == 255 and y > y1:
            break
        ec.poner(out, px - 1, y, OUT); ec.poner(out, px + 1, y, OUT)
        ec.poner(out, px, y, POLE)

    # energía que sube por el mango: pulsos cada 6 px que suben 2 px por fotograma
    mango = staff_mask.copy()
    mango[:ty + 2] = False
    mango[:, :px - 1] = False
    mango[:, px + 2:] = False
    for y in range(ty + 2, H):
        for x in (px, px + (1 if s < 0 else -1)):
            if not (0 <= x < W) or not mango[y, x]:
                continue
            fase = (y + 2 * f) % 6
            if fase == 0:
                out[y, x, :3] = PULSO
            elif fase == 1:
                out[y, x, :3] = PULSO_D
        if (y + 2 * f) % 6 == 0 and mango[y, px]:
            ec.poner(out, px - 2, y, GLOW, 70); ec.poner(out, px + 2, y, GLOW, 70)

    # la hoja
    bx0 = px + s * 1
    by0 = ty - 5
    banda = int(2.6 * f)
    runa = 0
    pix = []
    letras = [(c, r, FORMA[r, c]) for r in range(FORMA.shape[0]) for c in range(FORMA.shape[1]) if FORMA[r, c] != '.']
    letras += PUAS
    for c, r, ch in letras:
        if ch == 'r':
            # las runas se encienden por turnos
            if (runa + f) % 3 == 0:
                ch = 'A'
            runa += 1
        if banda <= c < banda + 2 and ch in ESCANEO:
            ch = ESCANEO[ch]
        pix.append((bx0 + s * c, by0 + r, COL[ch]))
    m = np.zeros((H, W), bool)
    for x, y, _ in pix:
        if 0 <= x < W and 0 <= y < H:
            m[y, x] = True
    contorno = ec.ndi.binary_dilation(m, structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])) & ~m
    ec.halo(out, m | contorno, GLOW, (120, 64, 26))
    for y, x in zip(*np.nonzero(contorno)):
        ec.poner(out, x, y, COL['o'])
    for x, y, col in pix:
        ec.poner(out, x, y, col)

    # brasas que caen de la punta
    for k in range(3):
        fase = (f + 2 * k) % 6
        x = bx0 + s * (14 + (k - 1) * 2 + fase * 0.4)
        y = by0 + 14 + fase * 1.5
        col = COL['W'] if fase < 2 else (COL['L'] if fase < 4 else COL['R'])
        ec.poner(out, x, y, col, 255 if fase < 4 else 150)

    # anilla de oro con una gema roja, y el remate de arriba más alto
    for dx in (-1, 0, 1):
        ec.poner(out, px + dx, ty, GOLD if dx else (255, 96, 80))
        ec.poner(out, px + dx, ty + 1, GOLD_D if dx else GOLD)
    for dy in (0, 1):
        ec.poner(out, px - 2, ty + dy, OUT); ec.poner(out, px + 2, ty + dy, OUT)
    ec.poner(out, px, ty - 1, GOLD)
    ec.poner(out, px, ty - 2, GOLD_L)
    ec.poner(out, px, ty - 3, (255, 250, 220))
    for dy in (1, 2, 3):
        ec.poner(out, px - 1, ty - dy, OUT); ec.poner(out, px + 1, ty - dy, OUT)
    ec.poner(out, px, ty - 4, OUT)


def construir(dibujo):
    r3.draw_scythe = dibujo
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        base0 = r3.remove_head(frame(d, 0), segs[0])
        robe0 = cmask(base0, ROBE)
        tex = make_circuit_texture(robe0, seed=4242 + 31 * d)
        for f in range(6):
            F = frame(d, f)
            b = r3.remove_head(F, segs[f])
            shift = best_shift(robe0, cmask(b, ROBE))
            ESTADO['f'] = f
            frames[(d, f)] = r3.convert3(F, segs[f], tex, shift)
    return ec.hoja(ec.espejar(frames))


if __name__ == '__main__':
    salida = sys.argv[1] if len(sys.argv) > 1 else 'segador_ciber_8_direcciones_evolucion.png'
    Image.fromarray(construir(dibujar_guadana_evolucionada), 'RGBA').save(salida)
    print('ok', salida)
