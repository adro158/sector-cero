"""Espadachín con la espada evolucionada (Firewall -> Firewall perimetral).

Es la misma hoja de siempre (se genera igual, con render2.py) cambiando solo
la espada:
- hoja más larga y ancha, con el centro blanco y tramos como ladrillos (un
  cortafuegos)
- llamas verdes que suben por los dos lados y cambian en cada fotograma
- guarda más ancha de oro con una gema verde, y pomo de oro
- brillo más fuerte

Uso: python3 generar_espadachin_evolucion.py [salida.png]
"""
import math
import sys

import numpy as np
from PIL import Image

import evo_comun as ec
import render2 as r2
from render import make_circuit_texture, best_shift
from seg import segment, frame, cmask, ROBE

ESTADO = {'f': 0}

LARGO = 22
NUCLEO = (240, 255, 240)
CLARO = (130, 255, 160)
MEDIO = (60, 230, 110)
BORDE = (24, 140, 64)
OSCURO = (10, 60, 30)
BRILLO = (80, 255, 130)
LLAMA = [(235, 255, 235), (170, 255, 190), (90, 240, 130)]
ORO_D, ORO, ORO_L = (150, 100, 24), (236, 184, 64), (255, 230, 140)
GEMA, GEMA_L = (60, 255, 140), (220, 255, 230)
CONTORNO = (8, 22, 14)


def ruido(i, j, f):
    """Número fijo entre 0 y 1 para cada sitio y fotograma (las llamas)."""
    return ((i * 73856093) ^ (j * 19349663) ^ (f * 83492791)) % 1000 / 1000.0


def dibujar_espada_evolucionada(out, hand, d):
    f = ESTADO['f']
    H, W = out.shape[:2]
    ys, xs = np.nonzero(hand)
    gx, gy = xs.mean(), ys.mean()
    dx, dy = r2.SWORD_DIR[d]
    n = math.hypot(dx, dy)
    ux, uy = dx / n, dy / n
    t0, t1 = 4.0, 4.0 + LARGO

    # la hoja: centro blanco y un claro a cada lado, más el borde oscuro del
    # lado de la sombra; se afina en la punta
    hoja = {}
    t = t0
    sombra = -1 if ux > 0 else 1
    while t <= t1:
        cx, cy = gx + ux * t, gy + uy * t
        resto = t1 - t
        # tramos como ladrillos: cada 4 px el centro se apaga un poco
        junta = (t - t0) % 4 < 0.6 and resto > 3
        hoja[(int(round(cx)), int(round(cy)))] = CLARO if junta else NUCLEO
        if resto > 1.2:
            hoja[(int(round(cx - sombra)), int(round(cy)))] = CLARO
            hoja[(int(round(cx + sombra)), int(round(cy)))] = MEDIO
        if resto > 3.5:
            hoja[(int(round(cx + 2 * sombra)), int(round(cy)))] = BORDE
        t += 0.5
    m = np.zeros((H, W), bool)
    for (x, y) in hoja:
        if 0 <= x < W and 0 <= y < H:
            m[y, x] = True
    contorno = ec.ndi.binary_dilation(m, structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])) & ~m

    # llamas verdes que salen de los dos filos y cambian en cada fotograma
    llamas = []
    for k in range(LARGO // 2):
        t = t0 + 2 + k * 2
        if t > t1 - 2:
            break
        cx, cy = gx + ux * t, gy + uy * t
        for lado in (-1, 1):
            r = ruido(k, lado + 2, f)
            if r < 0.35:
                continue
            largo = 2 + int((r - 0.35) / 0.65 * 2.99)    # de 2 a 4 píxeles
            borde = 2 if lado == sombra else 1
            for h in range(largo):
                x = cx + lado * (borde + 1 + h)
                y = cy - 0.7 * h - 0.5
                col = LLAMA[2] if h == 0 else (LLAMA[1] if h < largo - 1 else LLAMA[0])
                llamas.append((x, y, col, 255 if h < largo - 1 or largo == 1 else 190))

    ec.halo(out, m | contorno, BRILLO, (100, 45))
    for x, y, col, a in llamas:
        ec.poner(out, x, y, col, a)
    for y, x in zip(*np.nonzero(contorno)):
        if out[y, x, 3] < 255:
            ec.poner(out, x, y, OSCURO)
    for (x, y), col in hoja.items():
        ec.poner(out, x, y, col)

    # guarda de oro con una gema verde, justo debajo de la mano
    cx, cy = gx + ux * 3.0, gy + uy * 3.0
    for o in range(-3, 4):
        col = ORO_L if abs(o) == 3 else (ORO if abs(o) >= 2 else ORO_D)
        ec.poner(out, cx + o, cy, col)
        if out[int(round(cy)) - 1, int(round(cx + o)), 3] < 255:
            ec.poner(out, cx + o, cy - 1, CONTORNO)
        ec.poner(out, cx + o, cy + 1, CONTORNO if abs(o) > 1 else ORO_D)
    ec.poner(out, cx - 4, cy, CONTORNO)
    ec.poner(out, cx + 4, cy, CONTORNO)
    ec.poner(out, cx - 1, cy, GEMA)
    ec.poner(out, cx, cy, GEMA_L)
    ec.poner(out, cx + 1, cy, GEMA)
    # empuñadura y pomo de oro por encima de la mano
    ec.poner(out, gx - ux * 2.0, gy - uy * 2.0, (30, 34, 34))
    ec.poner(out, gx - ux * 3.0, gy - uy * 3.0, ORO)
    ec.poner(out, gx - ux * 4.0, gy - uy * 4.0, ORO_L)
    return out


def construir(dibujo):
    r2.draw_sword = dibujo
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        base0, _ = r2.remove_staff(frame(d, 0), segs[0])
        robe0 = cmask(base0, ROBE)
        tex = make_circuit_texture(robe0, seed=7000 + 13 * d)
        for f in range(6):
            F = frame(d, f)
            b, _ = r2.remove_staff(F, segs[f])
            shift = best_shift(robe0, cmask(b, ROBE))
            ESTADO['f'] = f
            frames[(d, f)] = r2.convert2(F, segs[f], tex, shift, d)
    return ec.hoja(ec.espejar(frames))


if __name__ == '__main__':
    salida = sys.argv[1] if len(sys.argv) > 1 else 'ciberespadachin_8_direcciones_evolucion.png'
    Image.fromarray(construir(dibujar_espada_evolucionada), 'RGBA').save(salida)
    print('ok', salida)
