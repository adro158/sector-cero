"""Cosas comunes de las hojas evolucionadas de los personajes de Sector Cero.

Las hojas son de 6 columnas (fotogramas de andar) x 8 filas (direcciones) de
64x72. Las filas 5, 6 y 7 son las 3, 2 y 1 en espejo, como en las hojas de
siempre, así que solo se dibujan las 5 primeras.
"""
import os
import sys

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

AQUI = os.path.dirname(os.path.abspath(__file__))
# los scripts con los que se hicieron las hojas de siempre (seg.py, render*.py,
# nostaff.py) están en la misma carpeta
sys.path.insert(0, AQUI)

FW, FH = 64, 72
N8 = np.ones((3, 3), bool)


def poner(out, x, y, col, a=255):
    """Píxel opaco, o translúcido solo donde no hay nada opaco (los brillos van detrás)."""
    H, W = out.shape[:2]
    x, y = int(round(x)), int(round(y))
    if not (0 <= x < W and 0 <= y < H):
        return
    if a >= 255:
        out[y, x] = (*col[:3], 255)
    elif out[y, x, 3] < a:
        out[y, x] = (*col[:3], a)


def halo(out, mascara, col, alfas):
    """Brillo tramado alrededor de una máscara: un anillo por cada alfa."""
    actual = mascara.copy()
    for a in alfas:
        anillo = ndi.binary_dilation(actual, structure=N8) & ~actual
        for y, x in zip(*np.nonzero(anillo)):
            poner(out, x, y, col, a)
        actual |= anillo


def espejar(frames):
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(6):
            frames[(dst, f)] = frames[(src, f)][:, ::-1].copy()
    return frames


def hoja(frames):
    A = np.zeros((8 * FH, 6 * FW, 4), np.uint8)
    for (d, f), a in frames.items():
        A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW] = a
    return A


def leer_hoja(ruta):
    return np.array(Image.open(ruta).convert('RGBA'))


def fotograma(A, d, f):
    return A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW].copy()
