"""Mago con el bastón evolucionado (Ping -> Ping de inundación).

Parte de la hoja de siempre (antivirus_8_direcciones.png). Es el ejemplo del
profesor con otros colores, píxel a píxel, así que la calavera y el mango se
localizan con seg.py en el original y se dibuja encima:
- ondas de ping que salen de la calavera y se agrandan (6 fotogramas)
- tres orbes de datos que giran alrededor de la calavera
- la calavera con los ojos al blanco y un brillo cian
- energía cian que sube por el mango

Uso: python3 generar_mago_evolucion.py <antivirus_8_direcciones.png> [salida.png]
"""
import math
import sys

import numpy as np
from PIL import Image

import evo_comun as ec
from seg import segment, frame, cmask, STAFF, EYE

CIAN = (37, 234, 252)
CIAN_C = (178, 248, 255)
CIAN_O = (27, 171, 184)
BLANCO = (235, 255, 255)
MORADO = (196, 58, 196)
MORADO_C = (236, 140, 255)
PULSO, PULSO_D = (120, 250, 255), (27, 171, 184)


def evolucionar(F, S, f):
    out = F.copy()
    H, W = out.shape[:2]
    x0, y0, x1, y1 = S['sk_box']
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2

    # ondas de ping: dos anillos que salen de la calavera y se agrandan
    yy, xx = np.mgrid[0:H, 0:W]
    dist = np.hypot((xx - cx) * 1.0, (yy - cy) * 1.15)
    for k in range(2):
        paso = (f + 3 * k) % 6
        radio = 6 + paso * 2.2
        alfa = int(230 - paso * 32)
        anillo = np.abs(dist - radio) < 0.55
        for y, x in zip(*np.nonzero(anillo)):
            ec.poner(out, x, y, CIAN_C if paso < 2 else CIAN, alfa)

    # brillo cian alrededor de la calavera
    ec.halo(out, S['skull'], CIAN, (130, 60))

    # energía que sube por el mango
    mango = S['staff'] & (yy > y1 + 1)
    for y, x in zip(*np.nonzero(mango)):
        fase = (y + 2 * f) % 6
        if fase == 0:
            out[y, x, :3] = PULSO
        elif fase == 1:
            out[y, x, :3] = PULSO_D

    # dos puntas de metal morado que salen del mango y abrazan la calavera
    for lado in (-1, 1):
        borde = x0 - 1 if lado < 0 else x1 + 1
        puntos = [(cx + lado * 2, y1 + 2), (borde + lado * 1, y1), (borde + lado * 2, cy), (borde + lado * 1, y0 - 1)]
        for (ax, ay), (bx, by) in zip(puntos[:-1], puntos[1:]):
            pasos = int(max(abs(bx - ax), abs(by - ay)) * 2) + 1
            for i in range(pasos + 1):
                x = ax + (bx - ax) * i / pasos
                y = ay + (by - ay) * i / pasos
                ec.poner(out, x, y, MORADO)
                sx, sy = int(round(x + lado)), int(round(y))
                if 0 <= sx < W and 0 <= sy < H and out[sy, sx, 3] < 255:
                    ec.poner(out, sx, sy, (70, 21, 86))
        tx, ty = puntos[-1]
        ec.poner(out, tx, ty, MORADO_C)
        ec.poner(out, tx, ty - 1, BLANCO)
        ec.poner(out, tx, ty - 2, CIAN, 150)

    # ojos de la calavera al blanco
    ojos = cmask(F, {(38, 236, 255)}) & S['skull']
    out[ojos, :3] = BLANCO

    # tres orbes que giran: los de detrás solo donde no hay nada
    for k in range(3):
        ang = 2 * math.pi * (f / 6 + k / 3)
        ox = cx + math.cos(ang) * 8.5
        oy = cy + 2 + math.sin(ang) * 3.0
        delante = math.sin(ang) > 0
        for (dx, dy), col in (((0, 0), BLANCO), ((1, 0), CIAN), ((0, 1), CIAN), ((1, 1), CIAN_O)):
            x, y = int(round(ox + dx)), int(round(oy + dy))
            if 0 <= x < W and 0 <= y < H and (delante or out[y, x, 3] < 255):
                out[y, x] = (*col, 255)
        for dx, dy in ((-1, 0), (2, 0), (0, -1), (1, -1), (0, 2), (1, 2)):
            ec.poner(out, ox + dx, oy + dy, CIAN, 90)

    # la cinta morada, un tono más clara
    cinta = S['ribbon']
    clara = cinta & cmask(F, {(159, 49, 196), (196, 58, 196)})
    out[clara, :3] = MORADO_C
    return out


def construir(hoja_base):
    frames = {}
    for d in range(5):
        for f in range(6):
            S = segment(frame(d, f))
            frames[(d, f)] = evolucionar(ec.fotograma(hoja_base, d, f), S, f)
    return ec.hoja(ec.espejar(frames))


if __name__ == '__main__':
    base = ec.leer_hoja(sys.argv[1])
    salida = sys.argv[2] if len(sys.argv) > 2 else 'antivirus_8_direcciones_evolucion.png'
    Image.fromarray(construir(base), 'RGBA').save(salida)
    print('ok', salida)
