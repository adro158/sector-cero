extends SceneTree

# Prueba temporal: cada personaje anda con el arma de siempre, evoluciona su
# herramienta y sigue andando por las 8 direcciones con la hoja nueva. Al final
# pasa por los tres y comprueba que el Sprite tiene la hoja evolucionada.
const EVOLUCIONES := {
	"Segador": "res://recursos/mejoras/datos/evolucion_escaner.tres",
	"Mago": "res://recursos/mejoras/datos/evolucion_ping.tres",
	"Espadachín": "res://recursos/mejoras/datos/evolucion_firewall.tres",
}
const DIRECCIONES := [Vector2.DOWN, Vector2(-1, 1), Vector2.LEFT, Vector2(-1, -1), Vector2.UP, Vector2(1, -1), Vector2.RIGHT, Vector2(1, 1)]
const POR_PERSONAJE := 150
const ANTES := 40

var _raiz: Node
var _frames := 0
var _cambio: Node
var _sprite: Sprite2D


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _soltar() -> void:
	for accion in ["mover_arriba", "mover_abajo", "mover_izquierda", "mover_derecha"]:
		Input.action_release(accion)


func _andar(direccion: Vector2) -> void:
	_soltar()
	if direccion.x > 0: Input.action_press("mover_derecha")
	if direccion.x < 0: Input.action_press("mover_izquierda")
	if direccion.y > 0: Input.action_press("mover_abajo")
	if direccion.y < 0: Input.action_press("mover_arriba")


func _process(_delta: float) -> bool:
	_frames += 1
	var jugador: Node2D = _raiz.get_node("Jugador")
	if _frames == 2:
		jugador.get_node("Salud").invencible = true
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		_cambio = jugador.get_node("CambioPersonaje")
		_sprite = jugador.get_node("Sprite")
	if _frames < 3:
		return false
	var bloque := (_frames - 3) / POR_PERSONAJE
	var t := (_frames - 3) % POR_PERSONAJE
	if bloque >= 3:
		_soltar()
		if t == 1:
			for i in 3:
				_cambio._entrar(i)
				_cambio._aplicar()
				print("al volver a ", _cambio.personajes[i].nombre, ": ", _sprite.texture.resource_path.get_file())
		return t > 10
	var personaje: DatosPersonaje = _cambio.personajes[bloque]
	if t == 0:
		_cambio._entrar(bloque)
		_cambio._aplicar()
		print(personaje.nombre, " antes: ", _sprite.texture.resource_path.get_file())
	if t == ANTES:
		var mejora: DatosMejora = load(EVOLUCIONES[personaje.nombre])
		_cambio.evolucionar(mejora.arma_base, mejora.arma)
		print(personaje.nombre, " después: ", _sprite.texture.resource_path.get_file())
	if t < ANTES:
		_andar(DIRECCIONES[(t / 10) % 8])
	else:
		_andar(DIRECCIONES[((t - ANTES) / 13) % 8])
	return false
