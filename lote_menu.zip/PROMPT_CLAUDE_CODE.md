Hoy toca **rehacer el menú principal** para que tenga menos botones, con sprites nuevos. Las piezas las he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre. Trabaja en la rama `adam/menu-nuevo`, que sale de `main`. Valida en headless y no hagas push ni abras el PR hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar o crear y qué hace cada ventana. Espera a que te diga que sí. Pregúntame en el plan lo que no exista todavía; no te lo inventes:
- **Las misiones no existen:** ni la misión de hoy, ni su barra, ni la pestaña MISIONES.
- **Los «premios sin ver» del aviso de COLECCIÓN** dependen del pase y de las misiones.
- **COLECCIÓN es la ventana de las skins de Alan** (`escenas/skins/ventana_skins.gd`, con ARMARIO, PASE y TIENDA; mira `documentacio/equipo/reparto.md`). El botón solo la abre. Para añadirle MISIONES o cambiarle el aspecto, propón una issue para Alan y no toques sus ficheros.
- **El texto de las novedades:** hoy solo lo enseña el lanzador. Dime de dónde lo sacaría el juego y cómo sabe si ya se ha visto (para la insignia NUEVO).

El zip está en la rama `zips-lotes` del repo, que solo guarda los zips y no se fusiona con `main`. Bájalo y descomprímelo en la raíz del repo, encima de lo que hay, sin cambiar de rama:

```
git fetch origin zips-lotes
git show origin/zips-lotes:lote_menu.zip > /tmp/lote_menu.zip
unzip -o /tmp/lote_menu.zip -d .
```

Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `maqueta_menu.png` y `maqueta_jugar.png`: el menú y la ventana JUGAR montados en Godot 4.7.2 con las piezas, a 1280x720.
- `vista/`: cada pieza a x4, estirada y teñida.

Medidas, fotogramas, márgenes y qué se tiñe: `LEEME.txt`.

## Las piezas

Están en `projecte/medios/interfaz/`. Casi todas van en grises y se tiñen con `modulate`. Van ya de color `dificultad_iconos`, `novedades_nuevo` y `aviso_numero`.

| Fichero | Tamaño | Para qué |
|---|---|---|
| `menu_boton_grande.png` | 5 x 64x32, 9 trozos (30, 10, 10, 10) | los botones grandes y EMPEZAR: normal, encima, pulsado, foco y desactivado |
| `menu_iconos.png` | 17 x 16x16 | jugar, colección, perfil, opciones, salir, solo, en red, ayuda, versión, novedades, cuenta, ranking, partidas, armario, misiones, pase, tienda |
| `menu_tarjeta.png` | 3 x 48x48, margen 12 | las tarjetas del modo y la dificultad: normal, encima y elegida |
| `dificultad_iconos.png` | 3 x 24x24 | FÁCIL, MEDIA y DIFÍCIL |
| `menu_cuenta.png` | 2 x 48x20, 9 trozos (22, 6, 8, 6) | la cuenta en la esquina, con su icono |
| `peana.png` | 2 x 64x20 | la peana de cada personaje: normal y encendida |
| `cartel.png` y `cartel_pico.png` | 40x40 (margen 10) y 12x8 | el cartel encima del personaje |
| `novedades_marco.png`, `novedades_pestana.png` y `novedades_nuevo.png` | 48x48 (margen 12), 24x12 (3 trozos) y 2 x 32x12 | la tarjeta de novedades |
| `aviso_numero.png` | 2 x 14x14 | el aviso con número sobre COLECCIÓN: normal y latido |
| `mision_barra.png` y `mision_barra_relleno.png` | 96x8 cada una | la barra de la misión de hoy |
| `ventana.png` y `ventana_titulo.png` | 64x64 (margen 16) y 64x20 (margen 8) | el fondo de todas las ventanas y la banda del título |

## Cómo lo quiero

- **El menú** (`escenas/menu_principal/`):
  - Cuatro botones grandes en columna: JUGAR (destacado), COLECCIÓN, PERFIL y OPCIONES.
  - SALIR, pequeño en una esquina; la cuenta (`menu_cuenta.png`, abre `panel_cuenta.gd`) en otra.
  - En el centro, el logo y los tres personajes en sus peanas (`personajes_menu.gd`).
  - Al pasar el ratón (o el foco del mando) por un personaje, su peana se enciende y sale el cartel con su nombre, su herramienta y su ulti (`DatosPersonaje`: `nombre`, `arma.nombre`, `nombre_ulti`). Pulsarlo sigue abriendo el armario.
  - En una esquina, la tarjeta de novedades. En COLECCIÓN, el aviso con número. Debajo de los personajes, la misión de hoy: estas tres, según lo que te diga en el plan.
- **JUGAR** abre una ventana (`ventana.png` y `ventana_titulo.png`):
  - Dos tarjetas para el modo: SOLO, y EN RED, que lleva a la sala (`sala_red.gd`).
  - Tres para la dificultad, que sustituyen a `selector_dificultad.gd` y guardan la opción igual que ahora.
  - «¿Cómo se juega?» abre las reglas.
  - EMPEZAR.
- **PERFIL** junta la cuenta, los récords y, en pestañas (`pestanas.png`, como ahora), las partidas y el ranking (`panel_ranking.gd`).
- **OPCIONES** (`panel_opciones.gd`) gana la pestaña VERSIÓN: la versión, ACTUALIZAR y VERSIONES, que hoy están debajo del menú. Recuerda que desde el lanzador (`--desde-lanzador`) no salen ACTUALIZAR ni VERSIONES.
- Todas las ventanas usan `ventana.png` con su banda de título.
- **Teclado y mando:** todo se tiene que poder usar con el teclado y el mando, como ahora: foco en los botones y las tarjetas, Esc cierra la ventana y Enter es EMPEZAR. En la web no hay SALIR, y el táctil tiene que seguir funcionando.
- **Guías:**
  - `referencia/piezas_menu.gd`: cada pieza con sus márgenes y el botón grande. Puedes pasarlo a `EstiloInterfaz`.
  - `referencia/maqueta_menu.gd` y `referencia/maqueta_jugar.gd`: las maquetas, sin lógica.
  - Hazlo como sea más fácil de explicar.
- **Partir el menú:** `menu_principal.gd` ya tiene 241 líneas. Pásame en el plan cómo lo partirías (por ejemplo, un script por ventana, con `preload` y sin `class_name`).
- **Ficheros de paso:** si hace falta tocar alguno, va en un PR pequeño y aparte, como dice el CLAUDE.md. No toques nada de Alan.

## Al terminar

- **Validación del CLAUDE.md** (`/validar`). El menú es la escena principal: `--quit-after` lo carga. Carga también `escenas/juego.tscn`, porque EMPEZAR tiene que seguir llevando a la partida.
- **Capturas con ventana:**
  - el menú
  - un personaje con el ratón encima y su cartel
  - la ventana JUGAR con una tarjeta elegida
  - PERFIL con cada pestaña
  - OPCIONES en VERSIÓN
  - un botón con el foco del mando
- **Documentación:**
  - `creditos.md`: las piezas del menú las hizo Claude, con IA, como las demás.
  - `manual_usuario.md` (el menú cambia) y `documentacion_tecnica.md`.
  - La entrada de la sesión en `documentacio/bitacora/` y `requisitos_y_estado.md`.
  - Las issues para Alan, si hacen falta.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - `vista/`
  - `maqueta_menu.png` y `maqueta_jugar.png`
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat(menu)`, uno por ventana
  - `docs`
- **Al decirte "ya he acabado":** `/cerrar` (push de la rama y su PR). No publiques ninguna versión.
