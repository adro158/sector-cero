extends RefCounted

## Las piezas del menú principal nuevo (lote del menú), listas para usar: los
## estilos de 9 trozos, los recortes de las tiras y el botón grande. Es la
## guía de la maqueta; en el juego puede acabar dentro de EstiloInterfaz.
##
## Sin class_name: se carga con preload.

## El orden de menu_iconos.png (17 de 16x16).
enum Icono { JUGAR, COLECCION, PERFIL, OPCIONES, SALIR, SOLO, EN_RED, AYUDA, VERSION,
	NOVEDADES, CUENTA, RANKING, PARTIDAS, ARMARIO, MISIONES, PASE, TIENDA }
## Los fotogramas de menu_tarjeta.png.
enum Tarjeta { NORMAL, ENCIMA, ELEGIDA }

const BOTON_GRANDE := preload("res://medios/interfaz/menu_boton_grande.png")
const ICONOS := preload("res://medios/interfaz/menu_iconos.png")
const TARJETA := preload("res://medios/interfaz/menu_tarjeta.png")
const DIFICULTAD := preload("res://medios/interfaz/dificultad_iconos.png")
const CUENTA := preload("res://medios/interfaz/menu_cuenta.png")
const PEANA := preload("res://medios/interfaz/peana.png")
const CARTEL := preload("res://medios/interfaz/cartel.png")
const CARTEL_PICO := preload("res://medios/interfaz/cartel_pico.png")
const NOVEDADES := preload("res://medios/interfaz/novedades_marco.png")
const NOVEDADES_PESTANA := preload("res://medios/interfaz/novedades_pestana.png")
const NUEVO := preload("res://medios/interfaz/novedades_nuevo.png")
const AVISO := preload("res://medios/interfaz/aviso_numero.png")
const MISION_MARCO := preload("res://medios/interfaz/mision_barra.png")
const MISION_RELLENO := preload("res://medios/interfaz/mision_barra_relleno.png")
const VENTANA := preload("res://medios/interfaz/ventana.png")
const VENTANA_TITULO := preload("res://medios/interfaz/ventana_titulo.png")


## Un fotograma de una tira de 9 trozos, teñido. margenes y contenido van en
## el orden izquierda, arriba, derecha y abajo.
static func estilo(tira: Texture2D, fotograma: int, lado: Vector2, margenes: Array, contenido: Array, color: Color) -> StyleBoxTexture:
	var nuevo := StyleBoxTexture.new()
	nuevo.texture = tira
	nuevo.region_rect = Rect2(Vector2(fotograma * lado.x, 0.0), lado)
	nuevo.texture_margin_left = margenes[0]
	nuevo.texture_margin_top = margenes[1]
	nuevo.texture_margin_right = margenes[2]
	nuevo.texture_margin_bottom = margenes[3]
	nuevo.content_margin_left = contenido[0]
	nuevo.content_margin_top = contenido[1]
	nuevo.content_margin_right = contenido[2]
	nuevo.content_margin_bottom = contenido[3]
	nuevo.modulate_color = color
	return nuevo


static func trozo(tira: Texture2D, fotograma: int, lado: Vector2) -> AtlasTexture:
	var nuevo := AtlasTexture.new()
	nuevo.atlas = tira
	nuevo.region = Rect2(Vector2(fotograma * lado.x, 0.0), lado)
	return nuevo


static func icono(cual: Icono) -> AtlasTexture:
	return trozo(ICONOS, cual, Vector2(16.0, 16.0))


## Un dibujo de una tira a escala entera, teñido y sin suavizar.
static func dibujo(tira: Texture2D, fotograma: int, lado: Vector2, escala: float, color: Color = Color.WHITE) -> TextureRect:
	var nuevo := TextureRect.new()
	nuevo.texture = trozo(tira, fotograma, lado)
	nuevo.custom_minimum_size = lado * escala
	nuevo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	nuevo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	nuevo.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	nuevo.modulate = color
	return nuevo


## El botón grande (5 de 64x32: normal, encima, pulsado, foco y desactivado;
## márgenes 30, 10, 10 y 10). El icono va centrado en el hueco de 24x24 de la
## izquierda (empieza en x = 3: 3 + 4 = 7) y el texto, después de la raya
## (x = 28). El foco es transparente por dentro: Godot lo pinta encima.
static func boton_grande(texto: String, cual: Icono, color: Color, color_encima: Color, ancho := 280.0) -> Button:
	var boton := Button.new()
	boton.text = texto
	boton.icon = icono(cual)
	boton.alignment = HORIZONTAL_ALIGNMENT_LEFT
	boton.custom_minimum_size = Vector2(ancho, 32.0)
	boton.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	boton.add_theme_constant_override("h_separation", 16)
	var estados := ["normal", "hover", "pressed", "focus", "disabled"]
	var colores := [color, color_encima, color_encima, color_encima, color]
	for i in estados.size():
		boton.add_theme_stylebox_override(estados[i], estilo(BOTON_GRANDE, i, Vector2(64.0, 32.0), [30, 10, 10, 10], [7, 4, 14, 4], colores[i]))
	for nombre in ["icon_normal_color", "icon_focus_color"]:
		boton.add_theme_color_override(nombre, color)
	for nombre in ["icon_hover_color", "icon_pressed_color", "icon_hover_pressed_color"]:
		boton.add_theme_color_override(nombre, color_encima)
	for nombre in ["font_color", "font_focus_color"]:
		boton.add_theme_color_override(nombre, EstiloInterfaz.TEXTO)
	EstiloInterfaz.poner_letra(boton, 22)
	return boton


## Las tarjetas de JUGAR (48x48, margen 12).
static func tarjeta(estado: Tarjeta, color: Color) -> StyleBoxTexture:
	return estilo(TARJETA, estado, Vector2(48.0, 48.0), [12, 12, 12, 12], [16, 14, 16, 14], color)


## La ventana (64x64, margen 16) y la banda del título (64x20, margen 8).
static func ventana(color: Color) -> StyleBoxTexture:
	return estilo(VENTANA, 0, Vector2(64.0, 64.0), [16, 16, 16, 16], [32, 36, 32, 26], color)


static func ventana_titulo(color: Color) -> StyleBoxTexture:
	return estilo(VENTANA_TITULO, 0, Vector2(64.0, 20.0), [8, 8, 8, 8], [22, 4, 22, 4], color)


## El cartel (40x40, margen 10).
static func cartel(color: Color) -> StyleBoxTexture:
	return estilo(CARTEL, 0, Vector2(40.0, 40.0), [10, 10, 10, 10], [14, 10, 14, 12], color)


## La etiqueta de la cuenta (2 de 48x20: márgenes 22, 6, 8 y 6). De alto,
## siempre 20: el icono está en el trozo de la izquierda.
static func cuenta(encima: bool, color: Color) -> StyleBoxTexture:
	return estilo(CUENTA, 1 if encima else 0, Vector2(48.0, 20.0), [22, 6, 8, 6], [26, 1, 12, 1], color)


static func novedades(color: Color) -> StyleBoxTexture:
	return estilo(NOVEDADES, 0, Vector2(48.0, 48.0), [12, 12, 12, 12], [18, 18, 18, 14], color)
