extends Control

## Maqueta del menú principal nuevo, montada con las piezas del lote del menú.
## Solo enseña dónde va cada cosa (no hace nada al pulsar): a la izquierda los
## cuatro botones grandes, arriba el logo, en medio los personajes en sus
## peanas (el Espadachín con el ratón encima y su cartel), debajo la misión de
## hoy, en las esquinas la cuenta, SALIR y la tarjeta de novedades.

const Piezas := preload("res://maqueta/piezas_menu.gd")
const DatosSkin := preload("res://recursos/skins/datos_skin.gd")
const LOGO := preload("res://medios/interfaz/logo_sector_cero.png")
const PERSONAJES := [
	preload("res://recursos/personajes/datos/mago.tres"),
	preload("res://recursos/personajes/datos/espadachin.tres"),
	preload("res://recursos/personajes/datos/segador.tres"),
]
## El personaje con el ratón encima, para la maqueta.
const ENCIMA := 1
const LADO := Vector2(64.0, 72.0)
const NOVEDADES := [
	"Skins: 11 por personaje, 33 en total.",
	"Kernel Panic y NÚCLEO CERO invocan más horda.",
	"En red: los élites y los jefes, sin tirones.",
]

var _nuevo: TextureRect
var _aviso: Control
var _tiempo := 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = EstiloInterfaz.tema()
	var suelo := ColorRect.new()
	suelo.material = load("res://escenas/arena/suelo.tres")
	suelo.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(suelo)

	var logo := TextureRect.new()
	logo.texture = LOGO
	logo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	logo.position = Vector2(640.0 - 256.0 + 90.0, 34.0)
	add_child(logo)

	_crear_botones()
	_crear_personajes()
	_crear_mision()
	_crear_novedades()
	_crear_esquinas()


func _crear_botones() -> void:
	var columna := VBoxContainer.new()
	columna.position = Vector2(48.0, 236.0)
	columna.add_theme_constant_override("separation", 14)
	add_child(columna)
	var suave := EstiloInterfaz.TEXTO_SUAVE
	var neon := EstiloInterfaz.NEON
	var jugar := Piezas.boton_grande("JUGAR", Piezas.Icono.JUGAR, EstiloInterfaz.VICTORIA, Color(0.6, 1.0, 0.8), 300.0)
	columna.add_child(jugar)
	var coleccion := Piezas.boton_grande("COLECCIÓN", Piezas.Icono.COLECCION, suave, neon)
	columna.add_child(coleccion)
	var perfil := Piezas.boton_grande("PERFIL", Piezas.Icono.PERFIL, suave, neon)
	# En la maqueta, PERFIL con el ratón encima.
	perfil.add_theme_stylebox_override("normal", perfil.get_theme_stylebox("hover"))
	perfil.add_theme_color_override("icon_normal_color", neon)
	columna.add_child(perfil)
	columna.add_child(Piezas.boton_grande("OPCIONES", Piezas.Icono.OPCIONES, suave, neon))
	# El aviso con número, sobre la esquina de COLECCIÓN.
	var aviso := Control.new()
	aviso.position = Vector2(280.0 - 18.0, -10.0)
	aviso.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	aviso.draw.connect(_dibujar_aviso.bind(aviso, 3))
	_aviso = aviso
	coleccion.add_child(aviso)


## El aviso (14x14) a x2 y el número en blanco en su centro: la fuente pixel a
## 22 (un número mide 10x14), con la línea de las letras en y = 21.
func _dibujar_aviso(aviso: Control, cuantos: int) -> void:
	var fotograma := int(_tiempo / 0.4) % 2
	aviso.draw_texture_rect_region(Piezas.AVISO, Rect2(0.0, 0.0, 28.0, 28.0), Rect2(fotograma * 14.0, 0.0, 14.0, 14.0))
	aviso.draw_string(EstiloInterfaz.fuente_pixel(), Vector2(0.0, 21.0), str(cuantos), HORIZONTAL_ALIGNMENT_CENTER, 28.0, 22, Color.WHITE)


func _crear_personajes() -> void:
	var fila := Direcciones8.fila(Vector2.DOWN)
	for i in PERSONAJES.size():
		var personaje: DatosPersonaje = PERSONAJES[i]
		var centro_x := 700.0 + (i - 1) * 190.0
		var pies_y := 420.0
		var encendida := i == ENCIMA
		var peana := Piezas.dibujo(Piezas.PEANA, 1 if encendida else 0, Vector2(64.0, 20.0), 2.0, personaje.color)
		peana.position = Vector2(centro_x - 64.0, pies_y - 18.0)
		add_child(peana)
		var recorte := AtlasTexture.new()
		recorte.atlas = DatosSkin.elegida(personaje).hoja
		recorte.region = Rect2(Vector2(0.0, fila * LADO.y), LADO)
		var dibujo := TextureRect.new()
		dibujo.texture = recorte
		dibujo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		dibujo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		dibujo.size = LADO * 2.0
		dibujo.position = Vector2(centro_x - LADO.x, pies_y - LADO.y * 2.0 + 8.0)
		add_child(dibujo)
		if encendida:
			_crear_cartel(personaje, Vector2(centro_x, pies_y - LADO.y * 2.0 + 18.0))


## El cartel encima del personaje: su nombre, su herramienta y su ulti, con el
## pico apuntándole (las 2 filas de arriba del pico tapan el borde del cartel).
func _crear_cartel(personaje: DatosPersonaje, punta: Vector2) -> void:
	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", -2)
	add_child(columna)
	var cartel := PanelContainer.new()
	cartel.add_theme_stylebox_override("panel", Piezas.cartel(personaje.color))
	columna.add_child(cartel)
	var textos := VBoxContainer.new()
	textos.add_theme_constant_override("separation", 2)
	cartel.add_child(textos)
	textos.add_child(EstiloInterfaz.etiqueta(personaje.nombre.to_upper(), 22, personaje.color))
	textos.add_child(EstiloInterfaz.etiqueta("Herramienta: %s" % personaje.arma.nombre, 14))
	textos.add_child(EstiloInterfaz.etiqueta("Ulti: %s" % personaje.nombre_ulti, 14))
	var pico := TextureRect.new()
	pico.texture = Piezas.CARTEL_PICO
	pico.modulate = personaje.color
	pico.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pico.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	columna.add_child(pico)
	# Centrado encima de la cabeza, con la punta del pico en `punta`.
	columna.reset_size()
	columna.position = punta - Vector2(columna.size.x / 2.0, columna.size.y)


func _crear_mision() -> void:
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 12)
	fila.position = Vector2(436.0, 470.0)
	add_child(fila)
	fila.add_child(Piezas.dibujo(Piezas.ICONOS, Piezas.Icono.MISIONES, Vector2(16.0, 16.0), 1.0, EstiloInterfaz.NEON))
	fila.add_child(EstiloInterfaz.etiqueta("MISIÓN DE HOY", 13, EstiloInterfaz.NEON))
	fila.add_child(EstiloInterfaz.etiqueta("Elimina 300 gusanos", 15))
	var barra := Control.new()
	barra.custom_minimum_size = Vector2(192.0, 16.0)
	barra.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	barra.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	barra.draw.connect(func():
		var progreso := 180.0 / 300.0
		barra.draw_texture_rect(Piezas.MISION_MARCO, Rect2(Vector2.ZERO, Vector2(192.0, 16.0)), false, EstiloInterfaz.NEON)
		# El relleno, recortado a lo que va (en píxeles de la pieza, a x2).
		var ancho := roundf(96.0 * progreso)
		barra.draw_texture_rect_region(Piezas.MISION_RELLENO, Rect2(Vector2.ZERO, Vector2(ancho * 2.0, 16.0)), Rect2(0.0, 0.0, ancho, 8.0), EstiloInterfaz.NEON))
	fila.add_child(barra)
	fila.add_child(EstiloInterfaz.etiqueta("180/300", 15, EstiloInterfaz.TEXTO_SUAVE))


## La tarjeta de novedades, abajo a la derecha, con su pestaña encima de la
## esquina (10 px por encima y 8 a la derecha) y la insignia NUEVO.
func _crear_novedades() -> void:
	var caja := Control.new()
	add_child(caja)
	var marco := PanelContainer.new()
	marco.add_theme_stylebox_override("panel", Piezas.novedades(EstiloInterfaz.NEON))
	marco.custom_minimum_size = Vector2(350.0, 0.0)
	caja.add_child(marco)
	var textos := VBoxContainer.new()
	textos.add_theme_constant_override("separation", 4)
	marco.add_child(textos)
	var cabecera := HBoxContainer.new()
	cabecera.add_theme_constant_override("separation", 10)
	cabecera.add_child(EstiloInterfaz.etiqueta("Versión 1.22", 22, EstiloInterfaz.NEON))
	_nuevo = Piezas.dibujo(Piezas.NUEVO, 0, Vector2(32.0, 12.0), 2.0)
	cabecera.add_child(_nuevo)
	textos.add_child(cabecera)
	for linea in NOVEDADES:
		var texto := EstiloInterfaz.etiqueta("· " + linea, 13, EstiloInterfaz.TEXTO)
		texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		texto.custom_minimum_size.x = 310.0
		textos.add_child(texto)
	# Abajo a la derecha, a 24 px de los bordes.
	marco.reset_size()
	caja.position = Vector2(1280.0, 720.0) - marco.size - Vector2(24.0, 24.0)
	var pestana := Control.new()
	pestana.position = Vector2(8.0, -10.0)
	pestana.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	pestana.draw.connect(_dibujar_pestana.bind(pestana))
	caja.add_child(pestana)


## La pestaña de 3 trozos (6, 12 y 6) con «NOVEDADES» en la fuente pixel a 11.
func _dibujar_pestana(pestana: Control) -> void:
	var fuente := EstiloInterfaz.fuente_pixel()
	var texto := "NOVEDADES"
	var ancho := fuente.get_string_size(texto, HORIZONTAL_ALIGNMENT_LEFT, -1, 11).x + 16.0
	var color := EstiloInterfaz.NEON
	var tex := Piezas.NOVEDADES_PESTANA
	pestana.draw_texture_rect_region(tex, Rect2(0.0, 0.0, 6.0, 12.0), Rect2(0.0, 0.0, 6.0, 12.0), color)
	pestana.draw_texture_rect_region(tex, Rect2(6.0, 0.0, ancho - 12.0, 12.0), Rect2(6.0, 0.0, 12.0, 12.0), color)
	pestana.draw_texture_rect_region(tex, Rect2(ancho - 6.0, 0.0, 6.0, 12.0), Rect2(18.0, 0.0, 6.0, 12.0), color)
	pestana.draw_string(fuente, Vector2(8.0, 10.0), texto, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, EstiloInterfaz.NEON)


func _crear_esquinas() -> void:
	# La cuenta, arriba a la derecha.
	var cuenta := Button.new()
	cuenta.text = "adam"
	cuenta.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	cuenta.add_theme_stylebox_override("normal", Piezas.cuenta(false, EstiloInterfaz.NEON))
	cuenta.add_theme_stylebox_override("hover", Piezas.cuenta(true, EstiloInterfaz.NEON))
	cuenta.add_theme_font_size_override("font_size", 16)
	cuenta.custom_minimum_size = Vector2(150.0, 20.0)
	cuenta.position = Vector2(1280.0 - 150.0 - 24.0, 20.0)
	add_child(cuenta)
	# SALIR, pequeño, abajo a la izquierda.
	var salir := EstiloInterfaz.boton("SALIR", func(): pass, 120.0)
	salir.icon = Piezas.icono(Piezas.Icono.SALIR)
	salir.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	salir.position = Vector2(24.0, 720.0 - 44.0 - 20.0)
	add_child(salir)


func _process(delta: float) -> void:
	_tiempo += delta
	# NUEVO parpadea: medio segundo cada fotograma.
	_nuevo.texture.region.position.x = (int(_tiempo / 0.5) % 2) * 32.0
	# El aviso late: cambia de fotograma cada 0,4 s.
	_aviso.queue_redraw()
