extends Control

## Maqueta de la ventana JUGAR, encima del menú: la ventana con su banda de
## título, dos tarjetas para el modo, tres para la dificultad, «¿Cómo se
## juega?» y EMPEZAR. En la maqueta, SOLO y MEDIA están elegidas, DIFÍCIL con
## el ratón encima y EMPEZAR con el foco (para que se vean los estados).

const Piezas := preload("res://maqueta/piezas_menu.gd")
const AMARILLO := Color(1.0, 0.85, 0.25)
const DIFICULTADES := [
	["FÁCIL", "El malware aguanta menos", EstiloInterfaz.VICTORIA],
	["MEDIA", "Como está pensado", AMARILLO],
	["DIFÍCIL", "Más vida y más daño", EstiloInterfaz.DERROTA],
]

var empezar: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = EstiloInterfaz.tema()
	var oscuro := ColorRect.new()
	oscuro.color = Color(0.0, 0.0, 0.0, 0.65)
	oscuro.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(oscuro)

	var ventana := PanelContainer.new()
	ventana.add_theme_stylebox_override("panel", Piezas.ventana(EstiloInterfaz.NEON))
	ventana.custom_minimum_size = Vector2(760.0, 0.0)
	add_child(ventana)
	var columna := VBoxContainer.new()
	columna.add_theme_constant_override("separation", 12)
	ventana.add_child(columna)

	columna.add_child(EstiloInterfaz.etiqueta("MODO", 13, EstiloInterfaz.TEXTO_SUAVE))
	var modos := HBoxContainer.new()
	modos.add_theme_constant_override("separation", 16)
	modos.add_child(_tarjeta_modo(Piezas.Icono.SOLO, "SOLO", "Tú contra el malware", true))
	modos.add_child(_tarjeta_modo(Piezas.Icono.EN_RED, "EN RED", "2 o 3 jugadores", false))
	columna.add_child(modos)

	columna.add_child(EstiloInterfaz.etiqueta("DIFICULTAD", 13, EstiloInterfaz.TEXTO_SUAVE))
	var dificultades := HBoxContainer.new()
	dificultades.add_theme_constant_override("separation", 16)
	var estados := [Piezas.Tarjeta.NORMAL, Piezas.Tarjeta.ELEGIDA, Piezas.Tarjeta.ENCIMA]
	for i in DIFICULTADES.size():
		dificultades.add_child(_tarjeta_dificultad(i, estados[i]))
	columna.add_child(dificultades)

	var abajo := HBoxContainer.new()
	abajo.add_theme_constant_override("separation", 10)
	var ayuda := Button.new()
	ayuda.flat = true
	ayuda.text = "¿Cómo se juega?"
	ayuda.icon = Piezas.icono(Piezas.Icono.AYUDA)
	ayuda.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ayuda.add_theme_color_override("font_color", EstiloInterfaz.NEON)
	ayuda.add_theme_color_override("icon_normal_color", EstiloInterfaz.NEON)
	ayuda.add_theme_font_size_override("font_size", 16)
	ayuda.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	abajo.add_child(ayuda)
	var hueco := Control.new()
	hueco.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	abajo.add_child(hueco)
	empezar = Piezas.boton_grande("EMPEZAR", Piezas.Icono.JUGAR, EstiloInterfaz.VICTORIA, Color(0.6, 1.0, 0.8), 240.0)
	abajo.add_child(empezar)
	columna.add_child(abajo)

	ventana.reset_size()
	ventana.position = (Vector2(1280.0, 720.0) - ventana.size) / 2.0 + Vector2(0.0, 14.0)

	# La banda del título, centrada sobre el borde de arriba.
	var titulo := PanelContainer.new()
	titulo.add_theme_stylebox_override("panel", Piezas.ventana_titulo(EstiloInterfaz.NEON))
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 10)
	fila.add_child(Piezas.dibujo(Piezas.ICONOS, Piezas.Icono.JUGAR, Vector2(16.0, 16.0), 1.0, EstiloInterfaz.NEON))
	fila.add_child(EstiloInterfaz.etiqueta("JUGAR", 22, EstiloInterfaz.NEON))
	titulo.add_child(fila)
	add_child(titulo)
	titulo.reset_size()
	titulo.position = Vector2(ventana.position.x + (ventana.size.x - titulo.size.x) / 2.0, ventana.position.y - titulo.size.y / 2.0)


func _tarjeta_modo(cual: int, nombre: String, detalle: String, elegida: bool) -> PanelContainer:
	var tarjeta := PanelContainer.new()
	var estado := Piezas.Tarjeta.ELEGIDA if elegida else Piezas.Tarjeta.NORMAL
	var color := EstiloInterfaz.NEON if elegida else EstiloInterfaz.TEXTO_SUAVE
	tarjeta.add_theme_stylebox_override("panel", Piezas.tarjeta(estado, color))
	tarjeta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var fila := HBoxContainer.new()
	fila.add_theme_constant_override("separation", 14)
	tarjeta.add_child(fila)
	fila.add_child(Piezas.dibujo(Piezas.ICONOS, cual, Vector2(16.0, 16.0), 2.0, color))
	var textos := VBoxContainer.new()
	textos.add_child(EstiloInterfaz.etiqueta(nombre, 22, EstiloInterfaz.TEXTO if elegida else EstiloInterfaz.TEXTO_SUAVE))
	textos.add_child(EstiloInterfaz.etiqueta(detalle, 14, EstiloInterfaz.TEXTO_SUAVE))
	fila.add_child(textos)
	return tarjeta


func _tarjeta_dificultad(indice: int, estado: int) -> PanelContainer:
	var nombre: String = DIFICULTADES[indice][0]
	var detalle: String = DIFICULTADES[indice][1]
	var color: Color = DIFICULTADES[indice][2]
	var tarjeta := PanelContainer.new()
	tarjeta.add_theme_stylebox_override("panel", Piezas.tarjeta(estado, color if estado != Piezas.Tarjeta.NORMAL else EstiloInterfaz.TEXTO_SUAVE))
	tarjeta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var columna := VBoxContainer.new()
	columna.alignment = BoxContainer.ALIGNMENT_CENTER
	columna.add_theme_constant_override("separation", 6)
	tarjeta.add_child(columna)
	var dibujo := Piezas.dibujo(Piezas.DIFICULTAD, indice, Vector2(24.0, 24.0), 2.0)
	dibujo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	columna.add_child(dibujo)
	var titulo := EstiloInterfaz.etiqueta(nombre, 22, color)
	titulo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	columna.add_child(titulo)
	var texto := EstiloInterfaz.etiqueta(detalle, 13, EstiloInterfaz.TEXTO_SUAVE)
	texto.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	columna.add_child(texto)
	return tarjeta
