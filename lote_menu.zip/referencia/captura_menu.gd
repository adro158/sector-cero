extends SceneTree

## Maquetas del menú nuevo (a 30 fps): 0-59 el menú; 60-119, encima, la
## ventana JUGAR con el foco en EMPEZAR.

var _fotograma := 0
var _jugar: Control


func _initialize() -> void:
	root.add_child(load("res://maqueta/maqueta_menu.gd").new())


func _process(_delta: float) -> bool:
	_fotograma += 1
	if _fotograma == 60:
		_jugar = load("res://maqueta/maqueta_jugar.gd").new()
		root.add_child(_jugar)
	if _fotograma == 62:
		_jugar.empezar.grab_focus()
	return _fotograma >= 120
