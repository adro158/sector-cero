"""Assets del menú principal nuevo de SECTOR CERO: el botón grande, los iconos,
las tarjetas de JUGAR, la cuenta, las peanas de los personajes, el cartel, la
tarjeta de novedades, el aviso con número, la barra de la misión y la ventana.

Casi todo va en grises para teñirlo en el juego, con la paleta de siempre:
contorno 20, oscuro 95, medio 170, claro 235, blanco 255 y fondo 22. Van ya de
color dificultad_iconos, novedades_nuevo y aviso_numero.

Uso:  python3 generar_menu.py <carpeta de salida>
Deja los PNG en <salida>/projecte/medios/interfaz/.
"""
import math
import os
import sys

import numpy as np
from PIL import Image

CONTORNO, OSCURO, MEDIO, CLARO, BLANCO = 20, 95, 170, 235, 255
FONDO = 22

# Colores de los que ya van pintados.
VERDE = (0.30, 1.00, 0.60)      # VICTORIA
AMARILLO = (1.00, 0.85, 0.25)
ROJO = (1.00, 0.30, 0.40)       # DERROTA


def lienzo(w, h):
    return np.zeros((h, w, 4), np.uint8)


def gris(a, x, y, v, alfa=255):
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        a[y, x] = (v, v, v, alfa)


def rect(a, x0, y0, x1, y1, v, alfa=255):
    a[y0:y1 + 1, x0:x1 + 1] = (v, v, v, alfa)


def anillo(a, x0, y0, x1, y1, v, alfa=255):
    rect(a, x0, y0, x1, y0, v, alfa)
    rect(a, x0, y1, x1, y1, v, alfa)
    rect(a, x0, y0, x0, y1, v, alfa)
    rect(a, x1, y0, x1, y1, v, alfa)


def punteado(a, x0, y0, x1, y1, v, paso=2, alfa=255):
    """Un anillo de puntos: uno sí y (paso - 1) no."""
    for x in range(x0, x1 + 1):
        if (x - x0) % paso == 0:
            gris(a, x, y0, v, alfa)
            gris(a, x, y1, v, alfa)
    for y in range(y0, y1 + 1):
        if (y - y0) % paso == 0:
            gris(a, x0, y, v, alfa)
            gris(a, x1, y, v, alfa)


def cortar_esquinas(a, n=2):
    """Esquinas cortadas a 45 grados: se borran y el canto queda de contorno."""
    h, w = a.shape[:2]
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(n):
            for j in range(n - i):
                a[cy + sy * j, cx + sx * i] = 0
        for i in range(n + 1):
            gris(a, cx + sx * i, cy + sy * (n - i), CONTORNO)


def esquinas_brillantes(a, x0, y0, x1, y1, largo, v=BLANCO, grueso=1):
    """Corchetes en las cuatro esquinas de un rectángulo."""
    for (cx, cy, sx, sy) in ((x0, y0, 1, 1), (x1, y0, -1, 1), (x0, y1, 1, -1), (x1, y1, -1, -1)):
        for k in range(largo):
            for g in range(grueso):
                gris(a, cx + sx * k, cy + sy * g, v)
                gris(a, cx + sx * g, cy + sy * k, v)


V = {'o': CONTORNO, 'd': OSCURO, 'm': MEDIO, 'l': CLARO, 'w': BLANCO}


def desde_texto(filas, valores=V):
    h, w = len(filas), len(filas[0])
    a = lienzo(w, h)
    for y, fila in enumerate(filas):
        assert len(fila) == w, (len(fila), fila)
        for x, ch in enumerate(fila):
            if ch != '.':
                v = valores[ch]
                a[y, x] = (v, v, v, 255)
    return a


def pintar(a, x, y, color, brillo=1.0, alfa=255):
    """Un píxel de color: el color por el brillo (0 negro, 1 el color) o, por
    encima de 1, mezclado con blanco."""
    if not (0 <= y < a.shape[0] and 0 <= x < a.shape[1]):
        return
    if brillo <= 1.0:
        r, g, b = (c * brillo for c in color)
    else:
        t = brillo - 1.0
        r, g, b = (c + (1.0 - c) * t for c in color)
    a[y, x] = (round(r * 255), round(g * 255), round(b * 255), alfa)


def guardar(a, ruta):
    Image.fromarray(a, 'RGBA').save(ruta)


# ====================================================================== botón grande
def boton_grande(estado):
    """64x32, 9 trozos con márgenes 30 a la izquierda y 10 en los otros lados.
    El hueco del icono (24x24) va en x 3..26, y 4..27, y la raya que lo separa
    del texto, en x = 28: todo dentro del trozo de la izquierda."""
    if estado == 'foco':
        return foco_grande()
    w, h = 64, 32
    a = lienzo(w, h)
    relleno = {'normal': (24, 235), 'encima': (44, 242), 'pulsado': (80, 250), 'desactivado': (18, 200)}[estado]
    rect(a, 1, 1, w - 2, h - 2, *relleno)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    borde = {'normal': MEDIO, 'encima': CLARO, 'pulsado': BLANCO, 'desactivado': OSCURO}[estado]
    if estado == 'desactivado':
        # a trazos de 2: se ve apagado
        for x in range(1, w - 1):
            if (x // 2) % 2 == 0:
                gris(a, x, 1, borde)
                gris(a, x, h - 2, borde)
        for y in range(1, h - 1):
            if (y // 2) % 2 == 0:
                gris(a, 1, y, borde)
                gris(a, w - 2, y, borde)
    else:
        anillo(a, 1, 1, w - 2, h - 2, borde)
    if estado == 'pulsado':
        # hundido: sombra arriba en vez de luz
        rect(a, 2, 2, w - 3, 2, 50, 250)
    elif estado in ('normal', 'encima'):
        rect(a, 2, 2, w - 3, 2, MEDIO if estado == 'encima' else 60, 240)
        rect(a, 2, h - 3, w - 3, h - 3, 12, 240)
    cortar_esquinas(a, 3)

    # El hueco del icono: un recuadro más oscuro con las esquinas marcadas.
    hueco = {'normal': OSCURO, 'encima': MEDIO, 'pulsado': CLARO, 'desactivado': 50}[estado]
    rect(a, 4, 5, 25, 26, 10, 245)
    anillo(a, 3, 4, 26, 27, hueco)
    if estado != 'desactivado':
        brillo = estado in ('encima', 'pulsado')
        for (cx, cy, sx, sy) in ((3, 4, 1, 1), (26, 4, -1, 1), (3, 27, 1, -1), (26, 27, -1, -1)):
            gris(a, cx, cy, BLANCO if brillo else CLARO)
            gris(a, cx + sx, cy, BLANCO if brillo else MEDIO)
            gris(a, cx, cy + sy, BLANCO if brillo else MEDIO)
    # La raya que separa el icono del texto, de puntos.
    for y in range(5, 27, 2):
        gris(a, 28, y, hueco)

    # A la derecha, dos marcas arriba y una abajo (en las esquinas: no se estiran).
    if estado != 'desactivado':
        marca = MEDIO if estado == 'normal' else BLANCO
        for x in (56, 59):
            rect(a, x, 4, x + 1, 5, marca)
        rect(a, 55, h - 6, 60, h - 6, OSCURO if estado == 'normal' else MEDIO)
    return a


def foco_grande():
    """El foco, transparente por dentro: Godot pinta el estilo de foco encima
    del estado que toque (normal, encima...). Un borde de puntos blancos,
    corchetes gruesos en las esquinas y las del hueco del icono, marcadas."""
    w, h = 64, 32
    a = lienzo(w, h)
    punteado(a, 1, 1, w - 2, h - 2, BLANCO)
    esquinas_brillantes(a, 0, 0, w - 1, h - 1, 7, BLANCO, 2)
    cortar_esquinas_suave(a)
    for (cx, cy, sx, sy) in ((3, 4, 1, 1), (26, 4, -1, 1), (3, 27, 1, -1), (26, 27, -1, -1)):
        for k in range(3):
            gris(a, cx + sx * k, cy, BLANCO)
            gris(a, cx, cy + sy * k, BLANCO)
    return a


def cortar_esquinas_suave(a):
    """Quita los píxeles de los corchetes que caen fuera del corte de 45 grados."""
    h, w = a.shape[:2]
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(2):
            for j in range(2 - i):
                a[cy + sy * j, cx + sx * i] = 0


def botones_grandes():
    return np.concatenate([boton_grande(e) for e in ('normal', 'encima', 'pulsado', 'foco', 'desactivado')], axis=1)


# ====================================================================== iconos 16x16
ICONOS = {
    'jugar': [
        "................",
        "................",
        "...ww...........",
        "...wwww.........",
        "...wwwwww.......",
        "...wwwwwwww.....",
        "...wwwwwwwwww...",
        "...wwwwwwwwwwww.",
        "...llllllllllll.",
        "...llllllllll...",
        "...llllllll.....",
        "...llllll.......",
        "...llll.........",
        "...ll...........",
        "................",
        "................",
    ],
    'coleccion': [
        "................",
        "......mmmmmmmm..",
        "......m......m..",
        "......m......m..",
        "...wwwwwwww..m..",
        "...w......w..m..",
        "...w......w..m..",
        "...w...w..w..m..",
        "...w..www.w..m..",
        "...w.wwwwwwmmm..",
        "...w..www.w.....",
        "...w...w..w.....",
        "...w......w.....",
        "...w......w.....",
        "...wwwwwwww.....",
        "................",
    ],
    'perfil': [
        "................",
        "................",
        ".wwwwwwwwwwwwww.",
        ".w............w.",
        ".w..ww........w.",
        ".w.wwww.mmmmm.w.",
        ".w.wwww.......w.",
        ".w..ww..mmmm..w.",
        ".w............w.",
        ".w.wwww.mmmmm.w.",
        ".w.wwww.......w.",
        ".w............w.",
        ".wwwwwwwwwwwwww.",
        "................",
        "................",
        "................",
    ],
    'salir': [
        "................",
        ".......ww.......",
        ".......ww.......",
        "....w..ww..w....",
        "...ww..ww..ww...",
        "..ww...ww...ww..",
        "..w....ww....w..",
        ".ww....ww....ww.",
        ".w...........lw.",
        ".w...........lw.",
        ".ww.........lww.",
        "..ww.......lww..",
        "...www...llww...",
        "....wwwwwwww....",
        "................",
        "................",
    ],
    'solo': [
        "................",
        "......wwww......",
        ".....wwwwww.....",
        ".....wwwwww.....",
        ".....wwwwww.....",
        "......wwww......",
        "................",
        "....wwwwwwww....",
        "...wwwwwwwwww...",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "..llllllllllll..",
        "................",
        "................",
        "................",
    ],
    'en_red': [
        "................",
        "......wwww......",
        ".mm..wwwwww..mm.",
        "mmmm.wwwwww.mmmm",
        "mmmm.wwwwww.mmmm",
        ".mm...wwww...mm.",
        "................",
        ".mm..wwwwww..mm.",
        "mmm.wwwwwwww.mmm",
        "mmm.wwwwwwww.mmm",
        "mmm.wwwwwwww.mmm",
        "....wwwwwwww....",
        "....llllllll....",
        "................",
        "................",
        "................",
    ],
    'ayuda': [
        "................",
        ".....wwwwww.....",
        "...ww......ww...",
        "..w...wwww...w..",
        "..w..ww..ww..w..",
        ".w.......ww...w.",
        ".w......ww....w.",
        ".w.....ww.....w.",
        ".w.....ww.....w.",
        ".w............w.",
        "..w....ww....w..",
        "..w....ww....w..",
        "...ww......ww...",
        ".....wwwwww.....",
        "................",
        "................",
    ],
    'version': [
        "................",
        "...www..........",
        "..w...w.........",
        "..w...w...www...",
        "..w...w..w...w..",
        "...www...w...w..",
        "....w....w...w..",
        "....w.....www...",
        "....w......w....",
        "....w.....w.....",
        "....w...ww......",
        "....w.ww........",
        "...www..........",
        "..w...w.........",
        "..w...w.........",
        "...www..........",
    ],
    'novedades': [
        "................",
        "......w.........",
        "......w.......w.",
        ".....www.....www",
        ".....www......w.",
        "...wwwwwww......",
        "wwwwwwwwwwwww...",
        "...wwwwwww......",
        ".....lll........",
        ".....lll....w...",
        "......l.....w...",
        "......l...wwwww.",
        "............w...",
        "............w...",
        "................",
        "................",
    ],
    'cuenta': [
        "................",
        ".....wwwwww.....",
        "...ww......ww...",
        "..w...wwww...w..",
        "..w..wwwwww..w..",
        ".w...wwwwww...w.",
        ".w...wwwwww...w.",
        ".w....wwww....w.",
        ".w............w.",
        ".w...llllll...w.",
        "..w.llllllll.w..",
        "..wlllllllllww..",
        "...ww......ww...",
        ".....wwwwww.....",
        "................",
        "................",
    ],
    'ranking': [
        "................",
        "...wwwwwwwwww...",
        ".www........www.",
        "w.w...ww....w.w.",
        "w.w..www....w.w.",
        "w.w...ww....w.w.",
        ".ww...ww....ww..",
        "..w...ww....w...",
        "...w..www..w....",
        "....ww....ww....",
        "......wwww......",
        ".......ww.......",
        ".......ww.......",
        ".....wwwwww.....",
        "....wllllllw....",
        "....wwwwwwww....",
    ],
    'partidas': [
        "................",
        "................",
        ".ww..wwwwwwwwww.",
        ".ww.............",
        "................",
        ".ww..wwwwwwwww..",
        ".ww.............",
        "................",
        ".ww..wwwwwwwwww.",
        ".ww.............",
        "................",
        ".ww..wwwwwww....",
        ".ww.............",
        "................",
        "................",
        "................",
    ],
    'armario': [
        "................",
        ".......ww.......",
        "......w..w......",
        ".........w......",
        "........w.......",
        ".......w........",
        "......wwww......",
        ".....ww..ww.....",
        "....ww....ww....",
        "...ww......ww...",
        "..ww........ww..",
        ".ww..........ww.",
        ".wwwwwwwwwwwwww.",
        ".llllllllllllll.",
        "................",
        "................",
    ],
    'misiones': [
        "................",
        "..ww............",
        "..wwwwwwwwwwww..",
        "..wwllllllllw...",
        "..wwllllllw.....",
        "..wwllllllllw...",
        "..wwwwwwwwwwww..",
        "..ww............",
        "..ww............",
        "..ww............",
        "..ww............",
        "..ww............",
        "..ww............",
        ".wwww...........",
        "................",
        "................",
    ],
    'opciones': [
        "................",
        "......wwww......",
        "..ww..wwww..ww..",
        "..wwwwwwwwwwww..",
        "...wwwwwwwwww...",
        "...wwwmmmmwww...",
        ".wwwwm....mwwww.",
        ".wwwwm....mwwww.",
        ".llllm....mllll.",
        ".llllm....mllll.",
        "...lllmmmmlll...",
        "...llllllllll...",
        "..llllllllllll..",
        "..ll..llll..ll..",
        "......llll......",
        "................",
    ],
    'pase': [
        "................",
        "................",
        "................",
        ".wwwwwwwwwwwwww.",
        ".w.......m....w.",
        ".w...w...m....w.",
        "..w.www.......w.",
        "...wwwww.m.....w",
        "...wwwww.m.....w",
        "..w.www.......w.",
        ".w...w...m....w.",
        ".w.......m....w.",
        ".wwwwwwwwwwwwww.",
        "................",
        "................",
        "................",
    ],
    'tienda': [
        "................",
        "......wwww......",
        ".....w....w.....",
        ".....w....w.....",
        "..wwwwwwwwwwww..",
        "..w..........w..",
        "..w..w....w..w..",
        "..w..........w..",
        ".w............w.",
        ".w............w.",
        ".w............w.",
        ".w............w.",
        ".wwwwwwwwwwwwww.",
        ".llllllllllllll.",
        "................",
        "................",
    ],
}


ORDEN_ICONOS = ['jugar', 'coleccion', 'perfil', 'opciones', 'salir', 'solo', 'en_red', 'ayuda',
                'version', 'novedades', 'cuenta', 'ranking', 'partidas', 'armario', 'misiones',
                'pase', 'tienda']


def icono(nombre):
    return desde_texto(ICONOS[nombre])


def iconos():
    """17 de 16x16, en blanco: el orden de ORDEN_ICONOS."""
    return np.concatenate([icono(n) for n in ORDEN_ICONOS], axis=1)


# ====================================================================== tarjeta
def tarjeta(estado):
    """48x48, 9 trozos con margen 12."""
    w = h = 48
    a = lienzo(w, h)
    relleno = {'normal': (22, 238), 'encima': (36, 242), 'elegida': (44, 246)}[estado]
    rect(a, 1, 1, w - 2, h - 2, *relleno)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    if estado == 'normal':
        anillo(a, 1, 1, w - 2, h - 2, MEDIO)
        rect(a, 2, 2, w - 3, 2, 60, 240)
    elif estado == 'encima':
        anillo(a, 1, 1, w - 2, h - 2, CLARO)
        anillo(a, 2, 2, w - 3, h - 3, OSCURO)
    else:
        # doble: blanco por fuera y claro por dentro, con un hueco oscuro
        anillo(a, 1, 1, w - 2, h - 2, BLANCO)
        anillo(a, 2, 2, w - 3, h - 3, CONTORNO)
        anillo(a, 3, 3, w - 4, h - 4, CLARO)
    cortar_esquinas(a, 4)
    if estado == 'elegida':
        # las esquinas brillan: el canto del corte, blanco, y un punto de luz
        for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
            for i in range(5):
                gris(a, cx + sx * i, cy + sy * (4 - i), BLANCO)
            gris(a, cx + sx * 6, cy + sy * 6, BLANCO)
            gris(a, cx + sx * 7, cy + sy * 6, CLARO)
            gris(a, cx + sx * 6, cy + sy * 7, CLARO)
    # los tornillos de las esquinas, como en panel.png
    tornillo = {'normal': MEDIO, 'encima': CLARO, 'elegida': None}[estado]
    if tornillo is not None:
        for (cx, cy) in ((6, 6), (w - 8, 6), (6, h - 8), (w - 8, h - 8)):
            rect(a, cx, cy, cx + 1, cy + 1, tornillo)
            gris(a, cx + 1, cy + 1, OSCURO)
    return a


def tarjetas():
    return np.concatenate([tarjeta(e) for e in ('normal', 'encima', 'elegida')], axis=1)


# ====================================================================== dificultad
CHEURON = [
    "....xx....",
    "..xx..xx..",
    "xx......xx",
]


def chip_dificultad(marcas, color):
    """24x24, ya de color: un chip con patas y 1, 2 o 3 galones."""
    a = lienzo(24, 24)
    # patas: tres por lado, de 2 de ancho
    for p in (7, 11, 15):
        for k in range(3):
            for g in (0, 1):
                pintar(a, p + g, 2 + k, color, 0.65)        # arriba
                pintar(a, p + g, 19 + k, color, 0.65)       # abajo
                pintar(a, 2 + k, p + g, color, 0.65)        # izquierda
                pintar(a, 19 + k, p + g, color, 0.65)       # derecha
    # el cuerpo: borde oscuro, canto de color y dentro casi negro
    for y in range(5, 19):
        for x in range(5, 19):
            borde = x in (5, 18) or y in (5, 18)
            canto = x in (6, 17) or y in (6, 17)
            if borde:
                pintar(a, x, y, color, 0.30)
            elif canto:
                pintar(a, x, y, color, 1.45 if (x == 6 or y == 6) else 0.75)
            else:
                pintar(a, x, y, color, 0.16)
    for (x, y) in ((5, 5), (18, 5), (5, 18), (18, 18)):
        a[y, x] = 0
    # los galones, centrados (cada uno 3 filas y 1 de separación)
    alto = marcas * 3 + (marcas - 1)
    y0 = 7 + (12 - alto) // 2
    for m in range(marcas):
        for fy, fila in enumerate(CHEURON):
            for fx, ch in enumerate(fila):
                if ch == 'x':
                    pintar(a, 7 + fx, y0 + m * 4 + fy, color, 1.35 if fy == 0 else 1.0)
    return a


def dificultades():
    return np.concatenate([chip_dificultad(1, VERDE), chip_dificultad(2, AMARILLO),
                           chip_dificultad(3, ROJO)], axis=1)


# ====================================================================== cuenta
def cuenta(encima):
    """48x20, 9 trozos: izquierda 22 (con el icono), derecha 8, arriba y
    abajo 6. El icono es el 11 (cuenta), en 3..18 x 2..17."""
    w, h = 48, 20
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, 36 if encima else 22, 240)
    # el compartimento del icono, más oscuro
    rect(a, 2, 2, 19, h - 3, 10, 245)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, CLARO if encima else MEDIO)
    for y in range(2, h - 2):
        gris(a, 20, y, CLARO if encima else OSCURO)
    cortar_esquinas(a, 3)
    # la muesca de la derecha, en la esquina de abajo
    rect(a, w - 6, h - 4, w - 4, h - 4, BLANCO if encima else OSCURO)
    ico = icono('cuenta')
    hay = ico[:, :, 3] > 0
    a[2:18, 3:19][hay] = ico[hay]
    if not encima:
        # sin el ratón, el icono un poco apagado
        sub = a[2:18, 3:19]
        sub[hay, :3] = (sub[hay, :3].astype(int) * 3 // 4).astype(np.uint8)
    return a


def cuentas():
    return np.concatenate([cuenta(False), cuenta(True)], axis=1)


# ====================================================================== peana
def peana(encendida):
    """64x20: una plataforma de circuito redonda vista desde un poco arriba.
    Arriba, la tapa (una elipse); debajo, el canto con sus luces."""
    w, h = 64, 20
    a = lienzo(w, h)
    cx, cy, rx, ry = 32.0, 7.0, 29.5, 5.5
    grosor = 5

    def tapa(x, y):
        return ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1.0

    def dentro(x, y):
        if tapa(x, y):
            return True
        for k in range(1, grosor + 1):
            if tapa(x, y - k):
                return True
        return False

    for y in range(h):
        for x in range(w):
            if not dentro(x, y):
                continue
            if tapa(x, y):
                # la tapa: anillos de pistas
                d = ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2
                if d > 0.78:
                    gris(a, x, y, CLARO if encendida else MEDIO)
                elif 0.36 < d <= 0.46:
                    gris(a, x, y, (BLANCO if encendida else OSCURO) if x % 2 == 0 else (60 if encendida else 40))
                else:
                    gris(a, x, y, 62 if encendida else 40)
            else:
                # el canto: oscuro, con una raya de luz
                fila = y - 1
                while fila >= 0 and not tapa(x, fila):
                    fila -= 1
                hondo = y - fila
                if hondo == 2:
                    gris(a, x, y, MEDIO if encendida else 60)
                else:
                    gris(a, x, y, 30 if encendida else 24)
    # el contorno alrededor de todo
    forma = a[:, :, 3] > 0
    for y in range(h):
        for x in range(w):
            if not forma[y, x]:
                continue
            vecinos = [(x + dx, y + dy) for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0))]
            if any(not (0 <= vx < w and 0 <= vy < h) or not forma[vy, vx] for vx, vy in vecinos):
                if tapa(x, y) and y < cy:
                    gris(a, x, y, BLANCO if encendida else CLARO)
                else:
                    gris(a, x, y, CONTORNO)
    # las luces del canto, cada 6 px
    for x in range(8, 57, 6):
        fila = 0
        while fila < h and not tapa(x, fila):
            fila += 1
        while fila < h and tapa(x, fila):
            fila += 1
        y = fila + 2
        if y < h and forma[y, x]:
            gris(a, x, y, BLANCO if encendida else MEDIO)
    # pistas de la tapa: cuatro hacia el centro, con su vía
    for (x0, x1, y) in ((10, 18, 7), (46, 54, 7)):
        for x in range(x0, x1 + 1):
            gris(a, x, y, CLARO if encendida else 70)
    for (x, y) in ((19, 6), (44, 6)):
        rect(a, x, y, x + 1, y + 1, BLANCO if encendida else MEDIO)
    if encendida:
        # el brillo de alrededor
        brillo = lienzo(w, h)
        for y in range(h):
            for x in range(w):
                if forma[y, x]:
                    continue
                for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
                    vx, vy = x + dx, y + dy
                    if 0 <= vx < w and 0 <= vy < h and forma[vy, vx]:
                        brillo[y, x] = (CLARO, CLARO, CLARO, 110)
                        break
        hay = brillo[:, :, 3] > 0
        a[hay] = brillo[hay]
    return a


def peanas():
    return np.concatenate([peana(False), peana(True)], axis=1)


# ====================================================================== cartel
def cartel():
    """40x40, 9 trozos con margen 10."""
    w = h = 40
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, FONDO, 245)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, CLARO)
    rect(a, 2, 2, w - 3, 2, MEDIO)
    cortar_esquinas(a, 3)
    esquinas_brillantes(a, 1, 1, w - 2, h - 2, 6)
    cortar_esquinas_suave(a)
    for (x, y) in ((5, 5), (w - 7, 5)):
        rect(a, x, y, x + 1, y + 1, MEDIO)
    return a


def cartel_pico():
    """12x8: apunta abajo, al personaje. Se dibuja con sus 2 filas de arriba
    encima de las 2 de abajo del cartel, centrado: así el borde se abre y el
    pico sale del cartel."""
    filas = [
        "ol........lo",
        "ol........lo",
        ".ol......lo.",
        "..ol....lo..",
        "...ol..lo...",
        "....ollo....",
        ".....oo.....",
        "............",
    ]
    a = desde_texto(filas)
    # el relleno del pico, como el del cartel
    for y, fila in enumerate(filas):
        izquierda = fila.find('l')
        derecha = fila.rfind('l')
        for x in range(izquierda + 1, derecha):
            if fila[x] == '.':
                gris(a, x, y, FONDO, 245)
    return a


# ====================================================================== novedades
def novedades_marco():
    """48x48, 9 trozos con margen 12. La pestaña va aparte (encima)."""
    w = h = 48
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, FONDO, 240)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, MEDIO)
    rect(a, 2, 2, w - 3, 2, 60, 240)
    punteado(a, 4, 4, w - 5, h - 5, OSCURO)
    cortar_esquinas(a, 3)
    # corchetes blancos por dentro, encima de los puntos
    esquinas_brillantes(a, 4, 4, w - 5, h - 5, 6, BLANCO, 2)
    return a


def novedades_pestana():
    """24x12, 3 trozos en horizontal: 6, 12 y 6. Se dibuja 10 px por encima
    del marco y 8 px a la derecha de su esquina: sus 2 filas de abajo tapan el
    borde de arriba del marco y la pestaña queda unida a él."""
    w, h = 24, 12
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 1, 40, 245)
    rect(a, 0, 0, w - 1, 0, CONTORNO)
    rect(a, 0, 0, 0, h - 1, CONTORNO)
    rect(a, w - 1, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 1, 1, 1, h - 1, CLARO)
    rect(a, w - 2, 1, w - 2, h - 1, CLARO)
    # las esquinas de arriba, cortadas
    for (cx, sx) in ((0, 1), (w - 1, -1)):
        for i in range(3):
            for j in range(3 - i):
                a[j, cx + sx * i] = 0
        for i in range(4):
            gris(a, cx + sx * i, 3 - i, CONTORNO)
        for i in range(1, 4):
            gris(a, cx + sx * i, 4 - i, CLARO)
    # un punto de luz en cada lado
    gris(a, 4, 6, BLANCO)
    gris(a, w - 5, 6, BLANCO)
    return a


LETRAS = {
    'N': ["x..x", "xx.x", "x.xx", "x..x", "x..x"],
    'U': ["x..x", "x..x", "x..x", "x..x", "xxxx"],
    'E': ["xxxx", "x...", "xxx.", "x...", "xxxx"],
    'V': ["x..x", "x..x", "x..x", ".xx.", ".xx."],
    'O': [".xx.", "x..x", "x..x", "x..x", ".xx."],
}


def nuevo(apagado):
    """32x12, ya de color (amarillo): la insignia «NUEVO» con letras de 4x5.
    0 encendida (fondo amarillo, letras oscuras), 1 al revés: parpadea."""
    w, h = 32, 12
    a = lienzo(w, h)
    for y in range(h):
        for x in range(w):
            borde = x in (0, w - 1) or y in (0, h - 1)
            if borde:
                pintar(a, x, y, AMARILLO, 0.30)
            elif apagado:
                pintar(a, x, y, AMARILLO, 0.18)
            else:
                pintar(a, x, y, AMARILLO, 1.30 if y == 1 else (0.70 if y == h - 2 else 1.0))
    for (x, y) in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    if apagado:
        # el canto, de color
        for x in range(1, w - 1):
            pintar(a, x, 1, AMARILLO, 0.9)
            pintar(a, x, h - 2, AMARILLO, 0.6)
    for i, letra in enumerate('NUEVO'):
        for fy, fila in enumerate(LETRAS[letra]):
            for fx, ch in enumerate(fila):
                if ch == 'x':
                    if apagado:
                        pintar(a, 4 + i * 5 + fx, 3 + fy, AMARILLO, 1.20)
                    else:
                        pintar(a, 4 + i * 5 + fx, 3 + fy, AMARILLO, 0.22)
    return a


def nuevos():
    return np.concatenate([nuevo(False), nuevo(True)], axis=1)


# ====================================================================== aviso con número
def aviso(latido):
    """14x14, ya de color (rojo): redondo, con el centro liso para el número
    (5x7 de la fuente pixel, en blanco). 1, al latir: más grande y más vivo."""
    a = lienzo(14, 14)
    radio = 7.0 if latido else 6.2
    for y in range(14):
        for x in range(14):
            d = math.hypot(x + 0.5 - 7.0, y + 0.5 - 7.0)
            if d > radio:
                continue
            if d > radio - 1.0:
                pintar(a, x, y, ROJO, 0.35)
            elif d > radio - 2.0:
                pintar(a, x, y, ROJO, 1.50 if (latido or y < 7) else 1.0)
            else:
                pintar(a, x, y, ROJO, 1.12 if latido else 0.92)
    return a


def avisos():
    return np.concatenate([aviso(False), aviso(True)], axis=1)


# ====================================================================== barra de la misión
def mision_marco():
    """96x8: el marco de la barra (con las marcas cada 12 px)."""
    w, h = 96, 8
    a = lienzo(w, h)
    rect(a, 2, 2, w - 3, h - 3, 14, 235)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, MEDIO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    for x in range(12, w - 2, 12):
        gris(a, x, 2, OSCURO)
        gris(a, x, h - 3, OSCURO)
    cortar_esquinas(a, 1)
    return a


def mision_relleno():
    """96x8: el relleno, en x 2..93 e y 2..5; se recorta a lo que vaya."""
    w, h = 96, 8
    a = lienzo(w, h)
    for y in range(2, 6):
        for x in range(2, w - 2):
            if y == 2:
                gris(a, x, y, BLANCO)
            elif y == 5:
                gris(a, x, y, MEDIO)
            else:
                gris(a, x, y, MEDIO if (x + y) % 6 < 2 else CLARO)
    return a


# ====================================================================== ventana
def ventana():
    """64x64, 9 trozos con margen 16: el borde de neón con pistas de circuito
    en las esquinas."""
    w = h = 64
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, FONDO, 242)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, CLARO)
    rect(a, 2, 2, w - 3, 2, MEDIO)
    anillo(a, 4, 4, w - 5, h - 5, 40)
    cortar_esquinas(a, 5)
    # el canto de cada corte, claro, como el borde
    # Dos pistas que salen de una vía y acaban en otra, sin tocar el borde.
    pistas = [
        "................",
        "................",
        "................",
        "................",
        "................",
        ".....ww.mmmm....",
        ".....wd.....m...",
        ".............m..",
        ".....m........ww",
        ".....m........wd",
        ".....m..........",
        ".....m..........",
        "......m.........",
        ".......m........",
        "........ww......",
        "........wd......",
    ]
    esquina = desde_texto(pistas)
    for (sx, sy) in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        trozo = esquina[::sy, ::sx]
        ys = slice(0, 16) if sy == 1 else slice(h - 16, h)
        xs = slice(0, 16) if sx == 1 else slice(w - 16, w)
        hay = trozo[:, :, 3] > 0
        a[ys, xs][hay] = trozo[hay]
    # el canto del corte de 45 grados, en claro
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(1, 5):
            gris(a, cx + sx * i, cy + sy * (6 - i), CLARO)
    return a


def ventana_titulo():
    """64x20, 9 trozos con margen 8: la banda del título."""
    w, h = 64, 20
    a = lienzo(w, h)
    rect(a, 1, 1, w - 2, h - 2, 40, 245)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, CLARO)
    rect(a, 2, 2, w - 3, 2, BLANCO)
    rect(a, 2, h - 3, w - 3, h - 3, 26, 245)
    cortar_esquinas(a, 4)
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(1, 4):
            gris(a, cx + sx * i, cy + sy * (5 - i), CLARO)
    # dos rayitas en cada esquina de abajo (no se estiran)
    for x in (4, 6, w - 7, w - 5):
        gris(a, x, h - 5, MEDIO)
    return a


def generar(salida):
    carpeta = os.path.join(salida, 'projecte/medios/interfaz')
    os.makedirs(carpeta, exist_ok=True)
    piezas = (
        ('menu_boton_grande', botones_grandes()),
        ('menu_iconos', iconos()),
        ('menu_tarjeta', tarjetas()),
        ('dificultad_iconos', dificultades()),
        ('menu_cuenta', cuentas()),
        ('peana', peanas()),
        ('cartel', cartel()),
        ('cartel_pico', cartel_pico()),
        ('novedades_marco', novedades_marco()),
        ('novedades_pestana', novedades_pestana()),
        ('novedades_nuevo', nuevos()),
        ('aviso_numero', avisos()),
        ('mision_barra', mision_marco()),
        ('mision_barra_relleno', mision_relleno()),
        ('ventana', ventana()),
        ('ventana_titulo', ventana_titulo()),
    )
    for nombre, a in piezas:
        guardar(a, os.path.join(carpeta, nombre + '.png'))


if __name__ == '__main__':
    generar(sys.argv[1])
