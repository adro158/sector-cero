"""Assets del panel técnico (F3) de SECTOR CERO, en grises para teñirlos con el
verde del panel (o el color que toque). Misma paleta que los del lote 9:
contorno 20, oscuro 95, medio 170, claro 235, blanco 255 y fondo 22 con alfa 242.

Uso:  python3 generar_tecnico.py <carpeta de salida>
Deja los PNG en <salida>/projecte/medios/interfaz/.
"""
import os
import sys

import numpy as np
from PIL import Image

CONTORNO, OSCURO, MEDIO, CLARO, BLANCO = 20, 95, 170, 235, 255


def lienzo(w, h):
    return np.zeros((h, w, 4), np.uint8)


def gris(a, x, y, v, alfa=255):
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        a[y, x] = (v, v, v, alfa)


def rect(a, x0, y0, x1, y1, v, alfa=255):
    """Rectángulo lleno, con los dos extremos incluidos."""
    a[y0:y1 + 1, x0:x1 + 1] = (v, v, v, alfa)


def guardar(a, ruta):
    Image.fromarray(a, 'RGBA').save(ruta)


def desde_texto(filas, valores):
    h, w = len(filas), len(filas[0])
    a = lienzo(w, h)
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch != '.':
                v = valores[ch]
                a[y, x] = (v[0], v[0], v[0], v[1] if len(v) > 1 else 255)
    return a


# ------------------------------------------------------------------ marco
def marco():
    """48x48 de 9 trozos: márgenes izquierda 8, derecha 8, arriba 24 y abajo 8.
    Arriba, la barra de título (filas 2 a 21, 20 px: cabe la tecla F3 de
    20x20) y una raya que la separa del cuerpo. Las esquinas, cortadas; los
    adornos, solo en las esquinas, para que al estirarse no se deformen."""
    w = h = 48
    a = lienzo(w, h)
    # cuerpo: fondo oscuro casi opaco
    rect(a, 2, 2, w - 3, h - 3, 22, 242)
    # barra de título: un poco más clara, con una línea de brillo arriba
    rect(a, 2, 2, w - 3, 21, 48, 250)
    rect(a, 3, 3, w - 4, 3, 110)
    # separación entre la barra y el cuerpo
    rect(a, 2, 22, w - 3, 22, CLARO)
    rect(a, 2, 23, w - 3, 23, OSCURO)
    # contorno de fuera, el borde claro y la sombra de dentro del cuerpo
    rect(a, 0, 0, w - 1, 0, CONTORNO)
    rect(a, 0, h - 1, w - 1, h - 1, CONTORNO)
    rect(a, 0, 0, 0, h - 1, CONTORNO)
    rect(a, w - 1, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 1, h - 2, w - 2, h - 2, MEDIO)
    rect(a, 1, 1, 1, h - 2, CLARO)
    rect(a, w - 2, 1, w - 2, h - 2, MEDIO)
    rect(a, 2, 24, 2, h - 3, OSCURO)
    rect(a, w - 3, 24, w - 3, h - 3, OSCURO)
    # esquinas cortadas a 45 grados (3 píxeles), con su canto
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(3):
            for j in range(3 - i):
                a[cy + sy * j, cx + sx * i] = 0
        for i in range(3):
            gris(a, cx + sx * i, cy + sy * (2 - i), CONTORNO)
            gris(a, cx + sx * (i + 1), cy + sy * (2 - i), CLARO if sy == 1 else MEDIO)
    # adornos: un remache en cada esquina de abajo
    for x, y in ((4, 42), (42, 42)):
        rect(a, x, y, x + 1, y + 1, BLANCO)
        gris(a, x + 1, y + 2, OSCURO)
        gris(a, x + 2, y + 2, OSCURO)
        gris(a, x + 2, y + 1, OSCURO)
    return a


# ------------------------------------------------------------------ cabecera de sección
def seccion():
    """64x18 de 3 trozos en horizontal: 20 px a la izquierda (el hueco del
    icono, de 16x16, en 1,1) y 6 a la derecha (la punta). El centro es igual en
    todas las columnas. El texto, desde x = 24."""
    w, h = 64, 18
    a = lienzo(w, h)
    # banda
    rect(a, 18, 2, w - 7, 15, 40, 225)
    rect(a, 18, 2, w - 7, 2, MEDIO)
    rect(a, 18, 15, w - 7, 15, OSCURO)
    rect(a, 18, 1, w - 7, 1, CONTORNO)
    rect(a, 18, 16, w - 7, 16, CONTORNO)
    # punta en flecha a la derecha
    for y in range(1, 17):
        d = abs(y - 8.5)
        largo = int(round(5 - d * 0.62))
        for x in range(w - 6, w - 6 + max(largo, 0)):
            a[y, x] = (40, 40, 40, 225)
        if largo >= 0:
            gris(a, w - 6 + max(largo, 0), y, MEDIO if y < 9 else OSCURO)
            gris(a, w - 5 + max(largo, 0), y, CONTORNO)
    # hueco del icono: un chip con las esquinas cortadas
    rect(a, 0, 0, 17, 17, CONTORNO)
    rect(a, 1, 1, 16, 16, 22, 242)
    rect(a, 1, 0, 16, 0, MEDIO)
    rect(a, 0, 1, 0, 16, MEDIO)
    rect(a, 17, 1, 17, 16, OSCURO)
    rect(a, 1, 17, 16, 17, OSCURO)
    for x, y in ((0, 0), (17, 0), (0, 17), (17, 17)):
        a[y, x] = 0
    # patitas de chip arriba y abajo del hueco
    for x in (4, 8, 12):
        gris(a, x, 0, CLARO)
        gris(a, x, 17, CLARO)
    return a


# ------------------------------------------------------------------ iconos
V = {'o': (CONTORNO,), 'd': (OSCURO,), 'm': (MEDIO,), 'l': (CLARO,), 'w': (BLANCO,)}

ICONOS = [
    ('sistema', [  # un chip (la CPU)
        "....o.o.o.o.....",
        "...omomomomo....",
        "..oooooooooooo..",
        ".omlllllllllldo.",
        "..olddddddddmo..",
        ".omldwwwwwddmdo.",
        "..oldwmmmwddmo..",
        ".omldwmddwddmdo.",
        "..oldwwwwwddmo..",
        ".omldddddddmmdo.",
        "..olmmmmmmmmmo..",
        ".omddddddddddmo.",
        "..oooooooooooo..",
        "...omomomomo....",
        "....o.o.o.o.....",
        "................",
    ]),
    ('antivirus', [  # escudo con la línea de un latido
        "................",
        "..oooooooooooo..",
        ".olllllllllllmo.",
        ".olmmmmmmmmmmdo.",
        ".olmmmmmmmmmmdo.",
        ".olmmmmwmmmmmdo.",
        ".olwwmwlwmmmmdo.",
        ".olmmwmmwmwwwdo.",
        ".olmmmmmmwmmmdo.",
        "..olmmmmmmmmdo..",
        "..olmmmmmmmmdo..",
        "...olmmmmmmdo...",
        "....olmmmmdo....",
        ".....olmmdo.....",
        "......oddo......",
        ".......oo.......",
    ]),
    ('horda', [  # un bicho de malware con patas
        "................",
        "..o..........o..",
        "...o..oooo..o...",
        "....oollllmo....",
        "...olllllllmo...",
        ".oolwwllllwwmoo.",
        "o..lwoolloowm..o",
        "..olllllllllmo..",
        ".oolmllllllmmoo.",
        "o..olmmllmmmo..o",
        "...oommmmmmoo...",
        "..o..oddddo..o..",
        ".o....oooo....o.",
        "................",
        "................",
        "................",
    ]),
    ('resistencia', [  # escudo con la firma del malware (rayas de código de barras)
        "................",
        "..oooooooooooo..",
        ".olllllllllllmo.",
        ".olwdwddwdwdmdo.",
        ".olwdwddwdwdmdo.",
        ".olwdwddwdwdmdo.",
        ".olwdwddwdwdmdo.",
        ".olmmmmmmmmmmdo.",
        ".olmwmwwmwmmmdo.",
        "..olmmmmmmmmdo..",
        "..olmmmmmmmmdo..",
        "...olmmmmmmdo...",
        "....olmmmmdo....",
        ".....olmmdo.....",
        "......oddo......",
        ".......oo.......",
    ]),
    ('tiempo', None),  # el reloj se dibuja con reloj(): círculo, marcas y agujas
    ('fps', [  # monitor con una onda
        "................",
        ".oooooooooooooo.",
        ".olllllllllllmo.",
        ".oldddddddddddo.",
        ".old.......w.do.",
        ".old......w.wdo.",
        ".oldw....w...do.",
        ".old.w..w....do.",
        ".old..ww.....do.",
        ".oldddddddddddo.",
        ".ommmmmmmmmmmmo.",
        ".oooooooooooooo.",
        "......oddo......",
        ".....odmmdo.....",
        "....oooooooo....",
        "................",
    ]),
    ('vida', [  # corazón
        "................",
        "................",
        "..oooo....oooo..",
        ".owwllo..ollllo.",
        "owlllllooolllldo",
        "owllllllllllllmo",
        "olllllllllllllmo",
        "olllllllllllldmo",
        ".olllllllllldmo.",
        "..ollllllllmmo..",
        "...ollllllmmo...",
        "....ollllmmo....",
        ".....ollmmo.....",
        "......olmo......",
        ".......oo.......",
        "................",
    ]),
    ('nivel', [  # flecha hacia arriba sobre una raya
        "................",
        ".......oo.......",
        "......owlo......",
        ".....owllmo.....",
        "....owllllmo....",
        "...owllllllmo...",
        "..oooollllmooo..",
        ".....ollllmo....",
        ".....ollllmo....",
        ".....ollllmo....",
        ".....ollllmo....",
        ".....ommmmdo....",
        "....oooooooo....",
        "..oooooooooooo..",
        "..ollllllllllo..",
        "..oooooooooooo..",
    ]),
    ('experiencia', [  # fragmento de datos (cristal)
        "................",
        ".......oo.......",
        "......owlo......",
        ".....owwllo.....",
        "....owwlllmo....",
        "...owwllllmmo...",
        "..owwlllllmmmo..",
        "..olllllllmmmo..",
        "..ommmmmmdmmdo..",
        "...ommmmmddmo...",
        "....ommmmddo....",
        ".....ommddo.....",
        "......omdo......",
        ".......oo.......",
        "................",
        "................",
    ]),
    ('golpe', [  # estallido de un golpe recibido
        "................",
        "....o.....o.....",
        "...olo...olo..o.",
        "...olwo.owlo.olo",
        "....olwowlo.owlo",
        ".oo..olwwlooolo.",
        "olwoooowwwwwwo..",
        ".olwwwwwwwwwo...",
        "..oowwwwwwlloo..",
        "...olwwwwwoowlo.",
        "..olwlowlo..oolo",
        ".olwo.olo.....o.",
        ".olo..olo.......",
        "..o...oo........",
        "................",
        "................",
    ]),
    ('en_pantalla', [  # ojo (lo que se ve)
        "................",
        "................",
        "................",
        ".....oooooo.....",
        "...oolllllloo...",
        "..olllooooollmo.",
        ".ollloowwdooollo",
        "olllloowddoollmo",
        ".ollloodddooolmo",
        "..olllooooollmo.",
        "...oommmmmmmoo..",
        ".....oooooo.....",
        "................",
        "................",
        "................",
        "................",
    ]),
    ('eliminados', [  # calavera
        "................",
        ".....oooooo.....",
        "...oollllllmo...",
        "..ollllllllllo..",
        "..olllllllllmo..",
        ".ollooollooolmo.",
        ".olloooloooolmo.",
        ".ollooollooolmo.",
        "..olllloolllmo..",
        "...olllllllmo...",
        "...olmomomomo...",
        "...oomomomomo...",
        "....oooooooo....",
        "................",
        "................",
        "................",
    ]),
]


def reloj():
    """Reloj de 16x16: esfera clara con contorno, marcas de las 12, 3, 6 y 9 y
    dos agujas oscuras (las 3 en punto), y el botón de arriba."""
    a = lienzo(16, 16)
    c = 7.5
    for y in range(16):
        for x in range(16):
            r = ((x - c) ** 2 + (y - c - 0.5) ** 2) ** 0.5
            if r <= 5.6:
                v = CLARO if (x - c) + (y - c) < 3 else MEDIO
                gris(a, x, y, v)
            elif r <= 6.6:
                gris(a, x, y, CONTORNO)
    for x, y in ((7, 3), (8, 3), (12, 8), (3, 8), (7, 13), (8, 13)):
        gris(a, x, y, OSCURO)
    for y in range(5, 9):
        gris(a, 7, y, CONTORNO)
    for x in range(7, 11):
        gris(a, x, 8, CONTORNO)
    gris(a, 7, 8, BLANCO)
    rect(a, 6, 0, 9, 0, CONTORNO)
    rect(a, 7, 1, 8, 1, MEDIO)
    return a


def iconos():
    """12 de 16x16 en una tira, en el orden de ICONOS."""
    a = lienzo(16 * len(ICONOS), 16)
    for i, (_, filas) in enumerate(ICONOS):
        icono = reloj() if filas is None else desde_texto(filas, V)
        a[:, i * 16:(i + 1) * 16] = icono
    return a


# ------------------------------------------------------------------ barra de 10 casillas
def barra():
    """64x8: contorno, borde y diez casillas apagadas de 5x4 (de 2,2 a 61,5).
    Cada casilla mide 6 px con el hueco: la casilla k empieza en x = 2 + 6k."""
    w, h = 64, 8
    a = lienzo(w, h)
    rect(a, 0, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, h - 2, MEDIO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 2, 2, w - 3, h - 3, CONTORNO)
    for k in range(10):
        x = 2 + 6 * k
        rect(a, x, 2, x + 4, 5, 50, 220)
        rect(a, x, 2, x + 4, 2, 70, 220)
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    return a


def barra_relleno():
    """60x4: las diez casillas encendidas, para recortar de 6 en 6 (cada casilla
    es un 10 %). Brillo arriba y sombra abajo."""
    w, h = 60, 4
    a = lienzo(w, h)
    for k in range(10):
        x = 6 * k
        for y, v in enumerate((BLANCO, CLARO, 200, 150)):
            rect(a, x, y, x + 4, y, v)
    return a


# ------------------------------------------------------------------ aviso
def aviso():
    """2 de 12x12: un triángulo con una exclamación, encendido y apagado, para
    que parpadee junto a una resistencia alta."""
    filas = [
        ".....oo.....",
        "....ollo....",
        "....ollo....",
        "...olllmo...",
        "...olooldo..",
        "..ollooldo..",
        "..ollooldmo.",
        ".olllooldmo.",
        ".olllllldmo.",
        "ollllooldmmo",
        "ommmmmmmmmdo",
        "oooooooooooo",
    ]
    encendido = desde_texto(filas, {'o': (CONTORNO,), 'l': (BLANCO,), 'm': (CLARO,), 'd': (MEDIO,)})
    apagado = desde_texto(filas, {'o': (CONTORNO,), 'l': (OSCURO,), 'm': (OSCURO,), 'd': (70,)})
    return np.concatenate([encendido, apagado], axis=1)


# ------------------------------------------------------------------ fondo de la gráfica
def grafica():
    """48x40 de 9 trozos con margen 4 en los cuatro lados. El centro (40x32) se
    repite en horizontal (axis_stretch TILE): cada 8 px una raya vertical de la
    rejilla. El alto es fijo (40). La zona para pintar las líneas: de y = 4 a
    y = 35 (32 px) y de x = 4 al ancho - 5."""
    w, h = 48, 40
    a = lienzo(w, h)
    rect(a, 0, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, h - 2, OSCURO)
    rect(a, 2, 2, w - 3, h - 3, CONTORNO)
    rect(a, 3, 3, w - 4, h - 4, 16, 235)
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    # rejilla: rayas horizontales al 25, 50 y 75 % (punteadas), y la de abajo
    for y in (12, 20, 28):
        for x in range(3, w - 3):
            if x % 2 == 0:
                gris(a, x, y, 62, 235)
    rect(a, 3, 35, w - 4, 35, 70, 235)
    # rayas verticales cada 8 px en el centro (empiezan en x = 4)
    for x in range(4, w - 4, 8):
        for y in range(4, 35):
            if y % 2 == 1 and a[y, x, 0] < 40:
                gris(a, x, y, 44, 235)
    # marcas del eje a la izquierda (en el borde, que no se estira)
    for y in (12, 20, 28):
        gris(a, 2, y, MEDIO)
    gris(a, 2, 4, CLARO)
    return a


# ------------------------------------------------------------------ led
def led():
    """4 de 8x8: el piloto de la barra de título, de apagado a encendido.
    En bucle 0, 1, 2, 3, 2, 1 a 0,15 s (o solo 0 y 3 para que parpadee)."""
    fotos = []
    for nucleo, brillo, halo in ((60, 80, 0), (130, 170, 0), (200, BLANCO, 70), (BLANCO, BLANCO, 130)):
        a = lienzo(8, 8)
        for y in range(8):
            for x in range(8):
                r = ((x - 3.5) ** 2 + (y - 3.5) ** 2) ** 0.5
                if r <= 2.3:
                    gris(a, x, y, nucleo)
                elif r <= 3.1:
                    gris(a, x, y, CONTORNO)
                elif halo and r <= 4.0 and (x + y) % 2 == 0:
                    gris(a, x, y, halo, 160)
        gris(a, 2, 2, brillo)
        gris(a, 3, 2, brillo)
        gris(a, 2, 3, brillo)
        fotos.append(a)
    return np.concatenate(fotos, axis=1)


def generar(salida):
    carpeta = os.path.join(salida, 'projecte/medios/interfaz')
    os.makedirs(carpeta, exist_ok=True)
    for nombre, a in (('tecnico_marco', marco()), ('tecnico_seccion', seccion()), ('tecnico_iconos', iconos()),
                      ('tecnico_barra', barra()), ('tecnico_barra_relleno', barra_relleno()),
                      ('tecnico_aviso', aviso()), ('tecnico_grafica', grafica()), ('tecnico_led', led())):
        guardar(a, os.path.join(carpeta, nombre + '.png'))


if __name__ == '__main__':
    generar(sys.argv[1])
