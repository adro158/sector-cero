Hoy toca el **panel técnico (F3)**: pasarlo de texto a sprites, con dos gráficas. Las piezas las he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

El F3 es lo que enseño en la defensa para que se vea la resistencia del malware, así que tiene que leerse bien y verse del juego. Hoy es una etiqueta de texto con barras hechas de caracteres (█░).

**Antes de programar, dame un plan corto.** Dime los ficheros que vas a tocar, cómo lo repartes para no pasar de ~200 líneas por script y cómo guardas lo de las gráficas. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

El zip está en la rama `zips-lotes` del repo, que solo guarda los zips y no se fusiona con `main`. Bájalo y descomprímelo en la raíz del repo, encima de lo que hay, sin cambiar de rama:

```
git fetch origin zips-lotes
git show origin/zips-lotes:lote_f3_panel_tecnico.zip > /tmp/lote_f3_panel_tecnico.zip
unzip -o /tmp/lote_f3_panel_tecnico.zip -d .
```

Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `vista_f3.png`: las piezas y el panel grabado en Godot 4.7.2.
- `panel_f3.gif` y `captura_f3.png`: el panel en la partida.

Medidas, márgenes y orden de los iconos: `LEEME.txt`.

## Las piezas

En `projecte/medios/interfaz/`. Van en grises y se tiñen con el verde del panel, `Color(0.45, 1.0, 0.65)`. Los rellenos y el aviso, del color que toque.

| Fichero | Tamaño | Para qué |
|---|---|---|
| `tecnico_marco.png` | 48x48, 9 trozos (8, 24, 8, 8) | el marco, con la barra de título arriba (20 px) |
| `tecnico_seccion.png` | 64x18, 3 trozos (20 y 6) | la cabecera de cada sección, con el hueco del icono |
| `tecnico_iconos.png` | 12 x 16x16 | un icono por sección y uno por dato (orden en `LEEME.txt`) |
| `tecnico_barra.png` + `_relleno.png` | 64x8 y 60x4 | barras de 10 casillas (el relleno, de 6 en 6) |
| `tecnico_aviso.png` | 2 x 12x12 | aviso que parpadea con una resistencia alta |
| `tecnico_grafica.png` | 48x40, 9 trozos (4), centro en TILE | el fondo de las dos gráficas |
| `tecnico_led.png` | 4 x 8x8 | el piloto que late en la barra de título |

## Cómo lo quiero

- **El panel.** `panel_depuracion.gd` pasa a ser un `Control` que se dibuja en `_draw`; en `raiz_juego.tscn`, su nodo pasa de `Label` a `Control`. Sigue igual que ahora:
  - abajo a la derecha, con el mismo margen
  - se abre y se cierra con F3
  - se actualiza en pausa
  - mide lo que mide su contenido
- **El marco y la barra de título.** El marco, con `draw_style_box` (`StyleBoxTexture` con sus márgenes). En la barra de título van:
  - el piloto latiendo
  - "PANEL TÉCNICO"
  - la tecla F3, de `teclas.png` (`TeclasDibujadas.region("F3")`)
- **Secciones y filas.** Las cuatro secciones de ahora (SISTEMA, ANTIVIRUS, HORDA y RESISTENCIA MALWARE), cada una con su cabecera y su icono. Cada dato en una fila: su icono, el nombre y el valor.
- **Barras.** La vida y cada resistencia, con la barra de 10 casillas:
  - **Vida:** de rojo a verde, como la barra sobre el personaje.
  - **Resistencias:** llena es el máximo de `resistencia_malware.gd` (`maximo`, el 50 %). Mejor leerlo del nodo que escribirlo a mano.
  - **Herramientas:** cada una con el icono de su mejora (`recursos/mejoras/iconos/arma_*.png`; las evoluciones, el de su base) y el color de su personaje.
- **Aviso.** Cuando una resistencia llega al 80 % del máximo, el triángulo parpadeando a su derecha, en rojo: toca cambiar de personaje.
- **Las dos gráficas.** Sobre el fondo de gráfica, con `draw_polyline`:
  - **Fps:** una muestra cada segundo, las últimas 60, en SISTEMA.
  - **Resistencias:** una línea por herramienta, del color de su personaje, una muestra cada 2 s, las últimas 60 (dos minutos), al final de RESISTENCIA MALWARE. Así se ven los escalones de cada análisis (cada 20 s).
  - Se van llenando aunque el panel esté cerrado, para que al abrirlo ya se vea lo que ha pasado. En pausa no avanzan.
  - Arriba a la derecha de cada una, su escala ("120" y "50%"), en pequeño.
- **Lo de dentro sigue igual:** los mismos datos y las mismas señales que ahora.
- **Tamaño de los scripts.** `referencia/panel_depuracion.gd` es el panel que probé para la grabación, pero tiene unas 260 líneas. Úsalo de guía y repártelo, por ejemplo el dibujo en un script aparte con `preload` y sin `class_name`, como lo que sea más fácil de explicar.

## Al terminar

- **Validación del CLAUDE.md:** import y `--quit-after`, y carga también `escenas/juego.tscn` con un script temporal. En la prueba salió un error de tipos (`var fotograma := [..][..]`) que solo aparece al cargar la partida.
- **Capturas con ventana** del panel abierto:
  - al empezar, sin resistencias ("ninguna todavía")
  - con dos herramientas con resistencia, una cerca del máximo con el aviso
  - las gráficas con un par de minutos de partida (con F1 o una instrumentación temporal)
  - durante una subida de nivel, para ver que se sigue actualizando y que las gráficas no avanzan

  Borra la instrumentación al acabar.
- No cambia el balance: no hace falta el simulador.
- **Documentación:**
  - `creditos.md`: las piezas del F3 las hizo Claude, con IA, como las demás.
  - `documentacion_tecnica.md`: el panel y sus gráficas.
  - `presentacion.md`, si hace falta: el paso del F3 puede enseñar ya la gráfica subiendo.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - las vistas previas (`vista_f3.png`, `panel_f3.gif`, `captura_f3.png`)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat(interfaz)` del panel técnico con sprites y gráficas
  - `docs`
- No publiques ninguna release.
