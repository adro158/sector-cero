extends SceneTree

# Prueba temporal del panel técnico (F3) con los sprites nuevos: partida con la
# horda de verdad, el panel abierto, dos resistencias puestas a mano y las
# gráficas llenas de muestras inventadas (para no esperar dos minutos).
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		_raiz.get_node("Jugador/Salud").invencible = true
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		var panel: Control = _raiz.get_node("CapaDepuracion/PanelDepuracion")
		panel.visible = true
		var ping: DatosArma = load("res://recursos/armas/datos/ping.tres")
		var firewall: DatosArma = load("res://recursos/armas/datos/firewall.tres")
		var resistencia: Node = _raiz.get_tree().get_first_node_in_group("resistencia_malware")
		resistencia._resistencias[firewall] = 0.45
		resistencia._resistencias[ping] = 0.15
		# Dos minutos inventados: el Firewall sube cada 20 s y el Ping sube y baja.
		var h_fire := PackedFloat32Array()
		var h_ping := PackedFloat32Array()
		var fps := PackedFloat32Array()
		for i in 60:
			h_fire.append(minf(floorf(i / 10.0) * 0.1, 0.45) if i > 6 else 0.0)
			h_ping.append([0.0, 0.0, 0.1, 0.2, 0.15, 0.15][int(i / 10)])
			fps.append(60.0 - (18.0 if i in [21, 22, 40] else 0.0) - (i % 3))
		panel._historia[firewall] = h_fire
		panel._historia[ping] = h_ping
		panel._fps = fps
		root.get_node("BusEventos").salud_jugador_cambiada.emit(100.0, 120.0)
	if _frames == 4:
		root.get_node("BusEventos").salud_jugador_cambiada.emit(86.0, 120.0)
		for i in 37:
			root.get_node("BusEventos").enemigo_muerto.emit(Vector2.ZERO, "bit_corrupto")
	return _frames > 80
