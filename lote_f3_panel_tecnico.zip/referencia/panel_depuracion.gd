extends Control

## Panel técnico, no es la interfaz del juego: datos internos para probar y
## enseñar el sistema, sobre todo la resistencia del malware. Se muestra y se
## oculta con F3. Se alimenta de las señales del BusEventos y, para lo que no
## viaja por el bus (enemigos en pantalla, resistencias), de los grupos.
##
## Se dibuja con sprites en grises teñidos de verde (como una terminal): el
## marco, las cabeceras con su icono, barras de 10 casillas y dos gráficas, la
## de los fps del último minuto y la de la resistencia de cada herramienta en
## los dos últimos minutos.

const TeclasDibujadas := preload("res://escenas/interfaz/teclas_dibujadas.gd")
const COLOR := Color(0.45, 1.0, 0.65)
const MARCO := preload("res://medios/interfaz/tecnico_marco.png")
const SECCION := preload("res://medios/interfaz/tecnico_seccion.png")
const ICONOS := preload("res://medios/interfaz/tecnico_iconos.png")
const BARRA := preload("res://medios/interfaz/tecnico_barra.png")
const RELLENO := preload("res://medios/interfaz/tecnico_barra_relleno.png")
const AVISO := preload("res://medios/interfaz/tecnico_aviso.png")
const GRAFICA := preload("res://medios/interfaz/tecnico_grafica.png")
const LED := preload("res://medios/interfaz/tecnico_led.png")
## El orden de la tira de iconos.
enum Icono { SISTEMA, ANTIVIRUS, HORDA, RESISTENCIA, TIEMPO, FPS, VIDA, NIVEL, EXPERIENCIA, GOLPE, EN_PANTALLA, ELIMINADOS }
## Cada herramienta, por su nombre: el icono de su mejora y el color de su
## personaje (las evoluciones, como la de base).
const HERRAMIENTAS := {
	"Ping": [preload("res://recursos/mejoras/iconos/arma_ping.png"), Color(0.75, 0.45, 1.0)],
	"Ping de inundación": [preload("res://recursos/mejoras/iconos/arma_ping.png"), Color(0.75, 0.45, 1.0)],
	"Firewall": [preload("res://recursos/mejoras/iconos/arma_firewall.png"), Color(0.4, 1.0, 0.5)],
	"Firewall perimetral": [preload("res://recursos/mejoras/iconos/arma_firewall.png"), Color(0.4, 1.0, 0.5)],
	"Escáner": [preload("res://recursos/mejoras/iconos/arma_escaner.png"), Color(1.0, 0.35, 0.35)],
	"Análisis heurístico": [preload("res://recursos/mejoras/iconos/arma_escaner.png"), Color(1.0, 0.35, 0.35)],
}
const ANCHO := 264.0
const LINEA := 18.0
const LETRA := 14
## Las gráficas guardan 60 muestras: los fps cada segundo y la resistencia cada 2 s.
const MUESTRAS := 60
## La resistencia llega como mucho al 50 %: la barra y la gráfica llenas son eso.
const RESISTENCIA_MAXIMA := 0.5

var _vida := 0.0
var _vida_maxima := 0.0
var _experiencia := 0
var _nivel := 1
var _muertos := 0
var _tiempo := 0.0
var _ultimo_golpe := 0.0
var _fps := PackedFloat32Array()
## Por herramienta (DatosArma), sus últimas resistencias.
var _historia := {}
var _cuenta_fps := 0.0
var _cuenta_resistencia := 0.0
var _segundos := 0.0
## El alto que ocupó el último dibujo: el panel mide lo que mide su contenido.
var _alto := 400.0
var _fuente: Font
var _marco: StyleBoxTexture
var _seccion: StyleBoxTexture
var _grafica: StyleBoxTexture


func _ready() -> void:
	# Sigue actualizándose con el juego pausado, para poder consultarlo mientras
	# se elige una mejora.
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_fuente = EstiloInterfaz.tema().default_font
	_marco = _estilo(MARCO, 8, 24, 8, 8)
	_seccion = _estilo(SECCION, 20, 0, 6, 0)
	_grafica = _estilo(GRAFICA, 4, 4, 4, 4)
	_grafica.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_TILE
	_fps.resize(MUESTRAS)

	BusEventos.salud_jugador_cambiada.connect(_al_cambiar_vida)
	BusEventos.experiencia_ganada.connect(func(cantidad): _experiencia += cantidad)
	BusEventos.experiencia_cambiada.connect(func(_actual, _necesaria, nivel): _nivel = nivel)
	BusEventos.enemigo_muerto.connect(func(_posicion, _tipo): _muertos += 1)
	# El reloj de la partida, el mismo que el del HUD: se para con el jefe.
	BusEventos.tiempo_partida.connect(func(segundos, _duracion): _tiempo = segundos)


func _estilo(textura: Texture2D, izquierda: int, arriba: int, derecha: int, abajo: int) -> StyleBoxTexture:
	var estilo := StyleBoxTexture.new()
	estilo.texture = textura
	estilo.texture_margin_left = izquierda
	estilo.texture_margin_top = arriba
	estilo.texture_margin_right = derecha
	estilo.texture_margin_bottom = abajo
	estilo.modulate_color = COLOR
	return estilo


func _unhandled_input(evento: InputEvent) -> void:
	if evento is InputEventKey and evento.pressed and evento.keycode == KEY_F3:
		visible = not visible


## Las gráficas se llenan aunque el panel esté cerrado: al abrirlo ya se ve
## lo que ha pasado. En pausa no avanzan.
func _process(delta: float) -> void:
	_segundos += delta
	if not get_tree().paused:
		_cuenta_fps += delta
		_cuenta_resistencia += delta
		if _cuenta_fps >= 1.0:
			_cuenta_fps = 0.0
			_meter(_fps, Engine.get_frames_per_second())
		if _cuenta_resistencia >= 2.0:
			_cuenta_resistencia = 0.0
			_muestrear_resistencias()
	if visible:
		size = Vector2(ANCHO, _alto)
		position = get_viewport_rect().size - size - Vector2(16.0, 16.0)
		queue_redraw()


## Una muestra nueva al final y la más vieja fuera.
func _meter(muestras: PackedFloat32Array, valor: float) -> void:
	muestras.remove_at(0)
	muestras.append(valor)


func _muestrear_resistencias() -> void:
	var actuales := _resistencias()
	for arma in actuales:
		if not _historia.has(arma):
			var nueva := PackedFloat32Array()
			nueva.resize(MUESTRAS)
			_historia[arma] = nueva
	for arma in _historia:
		_meter(_historia[arma], actuales.get(arma, 0.0))


func _resistencias() -> Dictionary:
	var nodo := get_tree().get_first_node_in_group("resistencia_malware")
	return {} if nodo == null else nodo.resistencias()


func _draw() -> void:
	draw_style_box(_marco, Rect2(Vector2.ZERO, size))
	# Barra de título: el piloto que late, el nombre y la tecla.
	var fotograma: int = [0, 1, 2, 3, 2, 1][int(_segundos / 0.15) % 6]
	draw_texture_rect_region(LED, Rect2(8, 8, 8, 8), Rect2(fotograma * 8, 0, 8, 8), COLOR)
	_texto(Vector2(22, 17), "PANEL TÉCNICO", COLOR)
	draw_texture_rect_region(TeclasDibujadas.TIRA, Rect2(ANCHO - 28.0, 2.0, 20, 20), TeclasDibujadas.region("F3"))

	var y := 26.0
	y = _cabecera(y, Icono.SISTEMA, "SISTEMA")
	y = _fila(y, Icono.TIEMPO, "tiempo", "%02d:%02d" % [int(_tiempo) / 60, int(_tiempo) % 60])
	y = _fila(y, Icono.FPS, "fps", str(Engine.get_frames_per_second()))
	y = _dibujar_grafica(y, [[_fps, COLOR]], 120.0, "120")

	y = _cabecera(y, Icono.ANTIVIRUS, "ANTIVIRUS")
	var proporcion := _vida / maxf(_vida_maxima, 1.0)
	y = _fila(y, Icono.VIDA, "vida", "%.0f" % _vida, proporcion, Color(1.0, 0.25, 0.3).lerp(Color(0.3, 1.0, 0.5), proporcion))
	y = _fila(y, Icono.NIVEL, "nivel", str(_nivel))
	y = _fila(y, Icono.EXPERIENCIA, "experiencia", str(_experiencia))
	y = _fila(y, Icono.GOLPE, "último golpe", "-%.0f" % _ultimo_golpe)

	y = _cabecera(y, Icono.HORDA, "HORDA")
	y = _fila(y, Icono.EN_PANTALLA, "en pantalla", str(_enemigos_vivos()))
	y = _fila(y, Icono.ELIMINADOS, "eliminados", str(_muertos))

	y = _cabecera(y, Icono.RESISTENCIA, "RESISTENCIA MALWARE")
	var resistencias := _resistencias()
	if resistencias.is_empty():
		_texto(Vector2(32, y + 13), "ninguna todavía", Color(COLOR, 0.6))
		y += LINEA
	for arma in resistencias:
		var valor: float = resistencias[arma]
		var datos: Array = HERRAMIENTAS.get(arma.nombre, [null, COLOR])
		if datos[0] != null:
			draw_texture(datos[0], Vector2(10, y + 1))
		_texto(Vector2(32, y + 13), arma.nombre.substr(0, 10), COLOR)
		_barra(Vector2(122, y + 5), valor / RESISTENCIA_MAXIMA, datos[1])
		_texto(Vector2(192, y + 13), "%2d%%" % roundi(valor * 100.0), Color.WHITE)
		# Cerca del máximo, un aviso que parpadea: toca cambiar de personaje.
		if valor >= 0.4:
			draw_texture_rect_region(AVISO, Rect2(ANCHO - 26.0, y + 3, 12, 12), Rect2((int(_segundos * 4.0) % 2) * 12, 0, 12, 12), EstiloInterfaz.DERROTA)
		y += LINEA
	var lineas := []
	for arma in _historia:
		lineas.append([_historia[arma], HERRAMIENTAS.get(arma.nombre, [null, COLOR])[1]])
	y = _dibujar_grafica(y, lineas, RESISTENCIA_MAXIMA, "50%")
	_alto = y + 6.0


func _texto(posicion: Vector2, texto: String, color: Color) -> void:
	draw_string(_fuente, posicion, texto, HORIZONTAL_ALIGNMENT_LEFT, -1, LETRA, color)


func _icono(posicion: Vector2, icono: int) -> void:
	draw_texture_rect_region(ICONOS, Rect2(posicion, Vector2(16, 16)), Rect2(icono * 16, 0, 16, 16), COLOR)


func _cabecera(y: float, icono: int, texto: String) -> float:
	y += 4.0
	draw_style_box(_seccion, Rect2(8, y, ANCHO - 16.0, 18))
	_icono(Vector2(9, y + 1), icono)
	_texto(Vector2(32, y + 14), texto, COLOR)
	return y + LINEA + 6.0


## Una fila: icono, nombre y valor; si se da una proporción, también su barra.
func _fila(y: float, icono: int, nombre: String, valor: String, proporcion := -1.0, color := COLOR) -> float:
	_icono(Vector2(10, y + 1), icono)
	_texto(Vector2(32, y + 13), nombre, Color(COLOR, 0.75))
	if proporcion >= 0.0:
		_barra(Vector2(122, y + 5), proporcion, color)
		_texto(Vector2(192, y + 13), valor, Color.WHITE)
	else:
		_texto(Vector2(150, y + 13), valor, Color.WHITE)
	return y + LINEA


## Barra de 10 casillas: el marco y tantas casillas encendidas como décimas.
func _barra(posicion: Vector2, proporcion: float, color: Color) -> void:
	draw_texture(BARRA, posicion, COLOR)
	var casillas := roundi(clampf(proporcion, 0.0, 1.0) * 10.0)
	if casillas > 0:
		var ancho := casillas * 6.0 - 1.0
		draw_texture_rect_region(RELLENO, Rect2(posicion + Vector2(2, 2), Vector2(ancho, 4)), Rect2(0, 0, ancho, 4), color)


## Gráfica de 40 px de alto: el fondo con la rejilla y una línea por serie
## ([muestras, color]); el máximo da la escala y se escribe arriba a la derecha.
func _dibujar_grafica(y: float, series: Array, maximo: float, texto_maximo: String) -> float:
	var caja := Rect2(8, y + 2, ANCHO - 16.0, 40)
	draw_style_box(_grafica, caja)
	var izquierda := caja.position.x + 4.0
	var ancho := caja.size.x - 9.0
	var abajo := caja.position.y + 35.0
	for serie in series:
		var muestras: PackedFloat32Array = serie[0]
		var puntos := PackedVector2Array()
		for i in muestras.size():
			var alto := clampf(muestras[i] / maximo, 0.0, 1.0) * 31.0
			puntos.append(Vector2(izquierda + ancho * i / (MUESTRAS - 1), abajo - alto))
		draw_polyline(puntos, serie[1], 1.0)
	draw_string(_fuente, Vector2(caja.end.x - 34.0, caja.position.y + 13.0), texto_maximo, HORIZONTAL_ALIGNMENT_RIGHT, 28, 10, Color(COLOR, 0.6))
	return y + 46.0


func _enemigos_vivos() -> int:
	var total := 0
	for gestor in get_tree().get_nodes_in_group("gestor_enemigos"):
		total += gestor.vivos()
	return total


func _al_cambiar_vida(actual: float, maxima: float) -> void:
	if _vida_maxima > 0.0 and actual < _vida:
		_ultimo_golpe = _vida - actual
	_vida = actual
	_vida_maxima = maxima
