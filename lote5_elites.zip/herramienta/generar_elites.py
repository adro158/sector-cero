"""Élites de Sector Cero (lote 5).

- rootkit_anim.png          4 x 48x48    el rootkit en reposo; el fotograma 0 es rootkit.png tal cual
- afijo_blindado.png        4 x 80x80    placas de armadura alrededor del élite, EN GRISES
- afijo_replicante.png      4 x 96x64    dos copias fantasma con glitch, EN GRISES
- afijo_aura_lenta.png      4 x 320x320  anillo helado de 150 px (RADIO_AURA), EN GRISES

Los tres afijos van en grises para teñirlos con el color del afijo
(DatosAfijoElite.color), como los anillos de ahora.

Uso: python3 generar_elites.py <rootkit.png>  (numpy y Pillow; usa pixel.py)
"""
import math
import os
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixel import Capa, bayer

OUT = './'
GRIS = [(40, 40, 40), (90, 90, 90), (140, 140, 140), (190, 190, 190), (228, 228, 228), (255, 255, 255)]
# colores del rootkit
MARCO = {(255, 238, 150), (250, 206, 80), (222, 164, 40), (170, 112, 20), (110, 70, 10), (120, 76, 12)}
BRILLO = (255, 248, 210)
CURSOR = {(255, 90, 60), (160, 40, 20)}
CARA = (40, 26, 10)
OJO = {(255, 80, 60): (200, 30, 30), (255, 200, 170): (255, 80, 60)}


def guardar(fotogramas, nombre):
    alto, ancho = fotogramas[0].shape[:2]
    hoja = np.zeros((alto, ancho * len(fotogramas), 4), np.uint8)
    for i, f in enumerate(fotogramas):
        hoja[:, i * ancho:(i + 1) * ancho] = f
    Image.fromarray(hoja, 'RGBA').save(OUT + nombre)


def mascara(a, colores):
    m = np.zeros(a.shape[:2], bool)
    for c in colores:
        m |= (a[..., 0] == c[0]) & (a[..., 1] == c[1]) & (a[..., 2] == c[2]) & (a[..., 3] == 255)
    return m


# ====================================================================== rootkit en reposo
def rootkit_anim(base):
    yy, xx = np.mgrid[0:48, 0:48]
    marco = mascara(base, MARCO)
    cursor = mascara(base, CURSOR)
    fotos = [base.copy()]
    for f in (1, 2, 3):
        a = base.copy()
        # un reflejo que recorre el marco en diagonal
        centro = [0, 22, 46, 70][f]
        banda = marco & (np.abs((xx + yy) - centro) <= 2)
        a[banda, :3] = BRILLO
        a[marco & (np.abs((xx + yy) - centro) == 3), :3] = (255, 238, 150)
        # el cursor parpadea (como en una terminal) y los ojos se entornan
        if f == 2:
            a[cursor, :3] = CARA
            for viejo, nuevo in OJO.items():
                a[mascara(base, {viejo}), :3] = nuevo
        # datos que pasan por los conectores de las puntas
        if f == 1:
            for x, y in ((24, 1), (24, 2), (24, 45), (24, 46)):
                a[y, x] = (*BRILLO, 255)
        if f == 3:
            for x, y in ((1, 24), (2, 24), (45, 24), (46, 24)):
                a[y, x] = (*BRILLO, 255)
        fotos.append(a)
    guardar(fotos, 'rootkit_anim.png')


# ====================================================================== blindado
def blindado():
    n = 80
    c = (n - 1) / 2
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    fotos = []
    for f in range(4):
        capa = Capa(n)
        # una placa en cada lado del rombo (el rootkit mide 48: lados a 45 grados)
        for k in range(4):
            ang = math.pi / 4 + k * math.pi / 2               # hacia fuera del lado
            nx, ny = math.cos(ang), math.sin(ang)
            tx, ty = -ny, nx                                   # a lo largo del lado
            px_, py_ = c + nx * 19, c + ny * 19                # el centro de la placa, por fuera del marco
            u = (xx - px_) * tx + (yy - py_) * ty              # a lo largo
            v = (xx - px_) * nx + (yy - py_) * ny              # hacia fuera
            placa = (np.abs(u) <= 11) & (v >= -2.5) & (v <= 3.5) & (np.abs(u) <= 11 - np.maximum(v - 1.5, 0) * 1.5)
            capa.rellenar(placa, GRIS[2])
            capa.rellenar(placa & (v >= 1.5), GRIS[4])        # el canto de fuera, con luz
            capa.rellenar(placa & (v <= -1.5), GRIS[1])       # el de dentro, en sombra
            # el brillo que recorre la placa
            brillo = placa & (np.abs(u - (-12 + f * 8)) <= 1.5)
            capa.rellenar(brillo, GRIS[5])
            # remaches
            for s in (-7, 7):
                rx, ry = px_ + tx * s + nx * 0.5, py_ + ty * s + ny * 0.5
                capa.px(rx, ry, GRIS[5] if (f + k + (s > 0)) % 2 == 0 else GRIS[3])
        capa.contorno((20, 20, 20))
        fotos.append(capa.uint8())
    guardar(fotos, 'afijo_blindado.png')


# ====================================================================== replicante
def replicante(base):
    w, h = 96, 64
    gris = base.astype(np.float64)
    lum = (gris[..., 0] * 0.3 + gris[..., 1] * 0.55 + gris[..., 2] * 0.15)
    lum = np.clip(80 + lum * 0.75, 0, 255)
    fantasma = np.zeros((48, 48, 4), np.float64)
    fantasma[..., 0] = fantasma[..., 1] = fantasma[..., 2] = lum
    fantasma[..., 3] = np.where(base[..., 3] > 0, 150, 0)
    # líneas de barrido: una fila de cada dos más transparente (holograma)
    fantasma[1::2, :, 3] *= 0.45
    desplazamientos = [(9, 0), (13, -1), (11, 1), (7, 0)]
    cortes = {1: [(14, 4, 3), (30, 3, -4)], 2: [(22, 3, -3)], 3: []}
    fotos = []
    for f in range(4):
        lienzo = np.zeros((h, w, 4), np.float64)
        dx, dy = desplazamientos[f]
        for lado in (-1, 1):
            copia = fantasma.copy()
            # franjas desplazadas a un lado (glitch)
            for y0, alto, d in cortes.get(f, []):
                copia[y0:y0 + alto] = np.roll(copia[y0:y0 + alto], d * lado, axis=1)
            x0 = int(w / 2 - 24 + lado * dx)
            y0 = int(h / 2 - 24 + dy * lado)
            zona = lienzo[y0:y0 + 48, x0:x0 + 48]
            sa = copia[..., 3:4] / 255.0
            da = zona[..., 3:4] / 255.0
            oa = sa + da * (1 - sa)
            rgb = np.where(oa > 0, (copia[..., :3] * sa + zona[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6), 0)
            lienzo[y0:y0 + 48, x0:x0 + 48] = np.concatenate([rgb, oa * 255], axis=-1)
        fotos.append(np.clip(np.round(lienzo), 0, 255).astype(np.uint8))
    guardar(fotos, 'afijo_replicante.png')


# ====================================================================== aura lenta
def aura_lenta():
    n = 320
    radio = 150
    c = (n - 1) / 2
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    dx, dy = xx - c, yy - c
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    b = bayer(n, n)
    cristales = 24
    fotos = []
    for f in range(4):
        capa = Capa(n)
        # escarcha en el suelo, más densa junto al borde
        banda = (r < radio - 2) & (r > radio - 28)
        capa.rellenar(banda & (b < 0.32 * (1 - (radio - 2 - r) / 26)), GRIS[3], 140)
        # el borde
        capa.rellenar(np.abs(r - radio) <= 1.1, GRIS[4])
        capa.rellenar(np.abs(r - (radio - 3)) <= 0.5, GRIS[2])
        # cristales de hielo que giran: racimos de tres esquirlas hacia dentro,
        # grandes y pequeños alternos (avanzan 2 huecos cada 4 fotogramas)
        giro = f * (2 * 2 * math.pi / cristales) / 4
        hielo = Capa(n)
        for k in range(cristales):
            ang = k * 2 * math.pi / cristales + giro
            grande = k % 2 == 0
            ux, uy = math.cos(ang), math.sin(ang)        # hacia fuera
            tx, ty = -uy, ux
            esquirlas = [(0.0, 0.0, 18 if grande else 10, 4.0 if grande else 2.6)]
            if grande:
                esquirlas += [(-4.5, -0.45, 11, 2.6), (4.5, 0.45, 11, 2.6)]
            for lado, giro_e, largo, ancho in esquirlas:
                bx, by = c + ux * (radio + 1) + tx * lado, c + uy * (radio + 1) + ty * lado
                ca, sa = math.cos(giro_e), math.sin(giro_e)
                dx_, dy_ = -(ux * ca - uy * sa), -(uy * ca + ux * sa)   # hacia dentro, algo girada
                punta = (bx + dx_ * largo, by + dy_ * largo)
                b1 = (bx - dy_ * ancho, by + dx_ * ancho)
                b2 = (bx + dy_ * ancho, by - dx_ * ancho)
                m = hielo.mascara_poligono([punta, b1, b2])
                hielo.rellenar(m, GRIS[3])
                hielo.linea((bx, by), (bx + dx_ * (largo - 2), by + dy_ * (largo - 2)), GRIS[5])
            if not grande:
                # una púa pequeña hacia fuera
                hielo.linea((c + ux * (radio + 1), c + uy * (radio + 1)), (c + ux * (radio + 5), c + uy * (radio + 5)), GRIS[4])
        hielo.contorno((30, 30, 30))
        capa.pegar(hielo)
        # copos de nieve fijos que brillan por turnos
        for k in range(6):
            ang = k * math.pi / 3 + math.pi / 6
            sx, sy = c + math.cos(ang) * (radio - 16), c + math.sin(ang) * (radio - 16)
            col = GRIS[5] if (k + f) % 2 == 0 else GRIS[3]
            for brazo in range(3):
                a = brazo * math.pi / 3
                for t in range(-4, 5):
                    capa.px(sx + math.cos(a) * t, sy + math.sin(a) * t, col)
            capa.px(sx, sy, GRIS[5])
        # destellos sueltos
        rng = np.random.default_rng(f)
        for _ in range(26):
            ang = rng.uniform(0, 2 * math.pi)
            d = rng.uniform(radio - 26, radio - 4)
            capa.px(c + math.cos(ang) * d, c + math.sin(ang) * d, GRIS[5])
        fotos.append(capa.uint8())
    guardar(fotos, 'afijo_aura_lenta.png')


if __name__ == '__main__':
    base = np.array(Image.open(sys.argv[1]).convert('RGBA'))
    rootkit_anim(base)
    blindado()
    replicante(base)
    aura_lenta()
    print('ok')
