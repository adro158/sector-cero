Hoy toca darles vida a los **élites**: el rootkit animado en reposo y un efecto para cada afijo que no lo tenía (Blindado, Replicante y Aura lenta), con unos sprites que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y qué pasa con los anillos de colores de los afijos que se dibujan ahora. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 5 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `elites_en_juego.gif`: grabado en Godot 4.7.2 con los cambios de `referencia/enemigo_elite.diff`
- `vista_lote5.png`: todo el lote

Tamaños, tiempos, centro y capa de cada uno: `LEEME.txt`.

## Los sprites

En `projecte/recursos/enemigos/sprites/`:

| Fichero | Fotogramas | Tiempo | Capa | Color |
|---|---|---|---|---|
| `rootkit_anim.png` | 4 x 48x48 | ver abajo | el sprite del élite | ya pintado; el fotograma 0 es `rootkit.png` |
| `afijo_blindado.png` | 4 x 80x80 | 0,15 s en bucle | **encima** del élite | **grises**, teñido con el color del afijo |
| `afijo_replicante.png` | 4 x 96x64 | 0,1 s en bucle | **detrás** del élite | **grises**, teñido con el color del afijo |
| `afijo_aura_lenta.png` | 4 x 320x320 | 0,15 s en bucle | detrás del élite | **grises**, teñido con el color del afijo |

## Cómo lo quiero

- **Rootkit en reposo:**
  - El fotograma 0 casi todo el rato (por ejemplo 1,2 s) y luego 1, 2 y 3 a 0,1 s cada uno, en bucle.
  - Desfasado entre élites para que no brillen todos a la vez (por ejemplo, con un tiempo inicial al azar al aparecer, pero sin gastar el azar de la partida, para que el simulador repita las mismas partidas).
  - `rootkit.png` sigue siendo la textura de los datos, para la ficha y las reglas. Lo de la explosión no cambia.
- **Afijos:**
  - Cada efecto se dibuja si el élite tiene ese afijo, teñido con `afijo.color` y centrado en el élite.
  - El Blindado va encima del sprite (en la prueba, un hijo `Node2D` creado en `_ready` que dibuja conectándose a su señal `draw`, como el `Fuego` de las explosiones).
  - El Replicante y el Aura lenta van en el `_draw` del élite, que va antes del sprite.
  - El aura sustituye al círculo morado de ahora (mismo radio, `RADIO_AURA` = 150).
  - Ahora el élite solo se redibuja con algunos eventos: para animar, hace falta redibujarlo en cada fotograma mientras está activo.
- **Los anillos finos de colores** de cada afijo alrededor del élite: propónme si se quedan (sirven para ver de un vistazo cuántos afijos tiene) o si se quitan para los afijos que ya tienen su efecto.
- **Aura lenta, ahora azul hielo** (decidido): en `recursos/enemigos/afijos/aura_lenta.tres`, `color = Color(0.6, 0.85, 1, 1)` y en la descripción "aura helada" en vez de "aura morada". Busca si el color o el texto salen en otros sitios (reglas, manual, la ficha) y cámbialos también.

`referencia/enemigo_elite.diff` es el cambio probado. Úsalo de guía y hazlo como sea más fácil de explicar: `enemigo_elite.gd` ya tiene 201 líneas, así que saca el dibujo a un script aparte (con `preload` y sin `class_name`) si hace falta.

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`.
- Con ventana, haz que salgan élites con cada afijo y con dos a la vez (menú de desarrollador, F1, o una instrumentación temporal). Haz capturas de:
  - el rootkit en reposo
  - cada afijo
  - dos afijos juntos
  - el aura con el jugador dentro
  - que la explosión del Explosivo sigue igual

  Borra la instrumentación al acabar.
- No cambia el balance: no hace falta el simulador, pero pasa una partida para comprobar que no salen errores.
- **Documentación:**
  - `creditos.md`: los sprites del lote 5 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md` y el panel de reglas si enseña los afijos.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/` y la documentación. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- **Commits pequeños** con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat` del rootkit animado
  - `feat` de los afijos
  - `docs`
- No publiques ninguna release.
