extends SceneTree

# Prueba temporal: tres élites quietos cerca del jugador, uno con cada afijo
# nuevo (blindado, replicante y aura lenta), con el rootkit animado.
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		var jugador: Node2D = _raiz.get_node("Jugador")
		jugador.get_node("Salud").invencible = true
		jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		var afijos := ["blindado", "replicante", "aura_lenta"]
		var sitios := [Vector2(-170, -60), Vector2(170, -60), Vector2(0, 120)]
		for i in 3:
			var elite: Node2D = _raiz.get_node("Elite%d" % (i + 1))
			elite.datos = elite.datos.duplicate()
			elite.datos.velocidad = 0.0
			var lista: Array[DatosAfijoElite] = [load("res://recursos/enemigos/afijos/%s.tres" % afijos[i])]
			elite.aparecer(jugador.global_position + sitios[i], lista)
	return _frames > 92
