Hoy toca darle al **jefe del minuto 10** los movimientos nuevos que apuntamos en el punto 3.4 de `requisitos_y_estado.md` (pisotón que encierra, ráfaga de datos y rabia), con unos sprites que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a crear y tocar, las señales nuevas del bus si hacen falta y los números que propones. Espera a que te diga que sí. Si algo de lo de abajo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 1 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `jefe_ataques_en_juego.gif`: grabado en Godot 4.7.2 con el suelo y el jefe de verdad
- `vista_lote1.png`: todo el lote a x2

Cada sprite, con su tamaño, fotogramas, tiempos, centro y capa, está en `LEEME.txt`.

## Los sprites

En `projecte/medios/sprites/jefe/`, tiras horizontales que van ya con su color:

| Fichero | Fotogramas | Tiempo | Para qué |
|---|---|---|---|
| `jefe_jaula_aviso.png` | 6 x 384x384 | 0,133 s (0,8 s), una vez | El aviso del pisotón: anillo rojo de 180 px que se cierra |
| `jefe_pisoton_onda.png` | 6 x 384x384 | 0,06 s, una vez | El golpe contra el suelo |
| `jefe_jaula.png` | 4 x 384x384 | 0,12 s, en bucle | La jaula: muro de datos de 174 a 186 px del centro |
| `jefe_jaula_rotura.png` | 5 x 384x384 | 0,08 s, una vez | La jaula se rompe al acabar |
| `jefe_rabia.png` | 4 x 192x192 | 0,1 s, en bucle | Aura detrás del jefe por debajo del 25 % de vida |
| `jefe_rafaga.png` | 4 x 16x16 | 0,08 s, en bucle | Proyectil de la ráfaga, mirando a la derecha |

## Cómo quiero los movimientos

Lo decidido está en el punto 3.4 de `requisitos_y_estado.md`. Resumen:

- **Pisotón que encierra.** Se para y sale el aviso (0,8 s). Al acabar da el golpe:
  - sale la onda
  - aparece la jaula donde estaba él
  - durante unos segundos ni el jugador ni el jefe pueden salir del círculo (el borde de dentro del muro está a 174 px)
  - después sale la rotura

  Propónme cuánto dura la jaula y cada cuánto la hace. La horda que esté dentro se queda dentro; propónme qué hacer con la que esté fuera.
- **Ráfaga de datos.** 12 proyectiles en círculo que se esquivan por los huecos; en la segunda mitad de su vida, dos ráfagas giradas. El sprite mira a la derecha: se gira con el ángulo de su dirección. Propón velocidad, daño y radio de impacto.
- **Rabia** (por debajo del 25 %). Va un 30 % más rápido y ataca más seguido. Mientras dura, se ve el aura detrás de él.

## Capas (lo probado en la grabación)

`referencia/demo_ataques_jefe.gd` dibuja cada sprite con sus tiempos con `draw_texture_rect_region`. Sirve de guía, no hace falta copiarlo así.

- **Aviso, onda, jaula y rotura van en el suelo:** debajo del jugador y de la horda, pero encima del suelo. Ojo: con `z_index` negativo quedan por debajo del suelo y no se ven. En la grabación van en un nodo que es el primer hijo de `RaizJuego`, como `Explosiones`. El centro de la jaula es donde dio el pisotón: no se mueve con el jefe.
- **El aura de la rabia va detrás del jefe.** En la grabación es un hijo del `Jefe` con `show_behind_parent = true` y `position = (0, -42)`, que es el offset de su `Sprite`. Si lo pones como primer hijo, antes del `Sprite`, también vale.
- **Los proyectiles van encima** del jugador y de la horda (`z_index = 4`, como el fuego de las explosiones).
- `texture_filter` en nearest en todo.

## Código

- `jefe.gd` ya tiene 216 líneas. Saca los ataques nuevos a scripts aparte, como se hizo con el jefe final (`ataques_jefe_final.gd`, `dibujo_jefe_final.gd`). Si son scripts auxiliares, cárgalos con `preload` y sin `class_name`.
- Si añades señales al bus (por ejemplo para el sonido), actualiza la lista de `GEMINI.md`.
- Que todo se pueda explicar en la defensa: lo más simple que funcione.

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`.
- Con ventana, haz que salga el jefe (menú de desarrollador, F1) y fuerza cada ataque con una instrumentación temporal. Haz capturas de:
  - el aviso
  - la onda y la jaula, con el jugador chocando contra el muro por dentro
  - la ráfaga simple y la doble
  - la rotura
  - la rabia por debajo del 25 %

  Comprueba también que, si la partida se pausa a mitad (subida de nivel), todo se para y luego sigue. Borra la instrumentación al acabar.
- **Simulador:** el jefe se vuelve más difícil. Pasa 10 partidas por dificultad y dame las victorias y dónde muere el bot. Antes de cambiar números, compáralo con las victorias que queremos en cada dificultad (están apuntadas en `requisitos_y_estado.md`).
- **Documentación:**
  - `creditos.md`: los sprites del lote 1 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md` y el panel de reglas (los movimientos del jefe).
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/` y la documentación. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- **Commits pequeños** con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - un `feat` por movimiento (pisotón con jaula, ráfaga, rabia)
  - `docs`
- No publiques ninguna release.
