"""Ataques nuevos del jefe del minuto 10 de Sector Cero (lote 1).

Todo en el morado del jefe, con rojo para el peligro y la rabia, y con los
bits verdes y rojos de su corona y sus chips. Tiras horizontales:

- jefe_jaula_aviso.png    6 x 384x384  anillo de peligro de 180 px que se va cerrando
- jefe_jaula.png          4 x 384x384  muro de datos de 180 px en bucle
- jefe_jaula_rotura.png   5 x 384x384  el muro se agrieta y salta en pedazos
- jefe_pisoton_onda.png   6 x 384x384  onda del pisotón con grietas en el suelo
- jefe_rafaga.png         4 x 16x16    proyectil de datos, mirando a la derecha
- jefe_rabia.png          4 x 192x192  aura de fuego rojo y morado, en bucle

Uso: python3 generar_jefe_ataques.py  (numpy y Pillow; usa pixel.py)
"""
import math
import os
import random
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixel import Capa, bayer

OUT = './'
MORADO = [(24, 12, 44), (40, 22, 74), (56, 32, 98), (76, 44, 132), (109, 57, 158), (176, 92, 255),
          (192, 125, 255), (225, 190, 255), (248, 240, 255)]
ROJO = [(60, 6, 16), (110, 14, 30), (170, 26, 44), (255, 62, 72), (255, 140, 140), (255, 222, 222)]
VERDE = (80, 240, 120)
BLANCO = (255, 255, 255)
RADIO = 180
N = 384


def rejilla(n):
    c = (n - 1) / 2
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    return xx - c, yy - c, c


def guardar(frames, nombre):
    alto, ancho = frames[0].shape[:2]
    hoja = np.zeros((alto, ancho * len(frames), 4), np.uint8)
    for i, f in enumerate(frames):
        hoja[:, i * ancho:(i + 1) * ancho] = f
    Image.fromarray(hoja, 'RGBA').save(OUT + nombre)


def flecha_dentro(capa, c, ang, r, col, sombra):
    """Chevron (forma de V) con la punta hacia el centro, a r píxeles del centro."""
    ux, uy = math.cos(ang), math.sin(ang)        # hacia fuera
    px_, py_ = -uy, ux                           # de lado
    for t in range(11):                          # t = 0 es la punta
        for s in (-1, 1):
            for g in (0, 1, 2):                  # tres píxeles de grueso
                d = t + g
                x = c + ux * (r + d) + px_ * s * t * 0.85
                y = c + uy * (r + d) + py_ * s * t * 0.85
                capa.px(x, y, sombra if g == 2 else (ROJO[4] if t < 3 else col))


# ====================================================================== aviso
def aviso():
    dx, dy, c = rejilla(N)
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    b = bayer(N, N)
    trozos = 36
    frames = []
    for f in range(6):
        p = (f + 1) / 6
        capa = Capa(N)
        # banda de peligro tramada por dentro del anillo, más densa al cerrarse
        banda = (r < RADIO - 3) & (r > RADIO - 26)
        dens = (1 - (RADIO - 3 - r) / 23) * (0.25 + 0.5 * p)
        capa.rellenar(banda & (b < dens), ROJO[1], 150)
        dentro = r < RADIO - 3
        capa.rellenar(dentro & (b < 0.06 + 0.06 * p), ROJO[1], 110)
        # anillo a trazos: cada trazo crece desde su centro hasta cerrar el círculo
        hueco = (th / (2 * math.pi) * trozos) % 1.0
        q = 0.35 + 0.65 * p if f < 5 else 1.0
        trazo = np.abs(hueco - 0.5) <= q / 2
        anillo = (np.abs(r - RADIO) <= 2.2) & trazo
        capa.rellenar(anillo, ROJO[3] if f < 5 else ROJO[4])
        capa.rellenar((np.abs(r - RADIO) <= 0.7) & trazo, ROJO[4] if f < 5 else BLANCO)
        capa.rellenar((np.abs(r - RADIO - 3.2) <= 0.6) & trazo, ROJO[1])
        # flechas hacia dentro que se van acercando
        for k in range(8):
            ang = k * math.pi / 4 + math.pi / 8
            flecha_dentro(capa, c, ang, RADIO - 22 - f * 3, ROJO[3], ROJO[1])
        # al cerrarse, un destello morado (es la jaula del jefe)
        if f == 5:
            capa.rellenar((np.abs(r - RADIO) <= 5) & (np.abs(r - RADIO) > 2.2) & (b < 0.6), MORADO[6], 200)
        capa.contorno((10, 4, 10))
        frames.append(capa.uint8())
    guardar(frames, 'jefe_jaula_aviso.png')


# ====================================================================== jaula
CELDAS = 60
POSTES = 12


def muro(f, rotura=None, rng=None):
    """El muro de datos. Devuelve la capa y, para la rotura, cada ladrillo."""
    dx, dy, c = rejilla(N)
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    b = bayer(N, N)
    capa = Capa(N)
    paso = 2 * math.pi / CELDAS
    # brillo hacia fuera y hacia dentro
    for d, a in ((1, 120), (2, 80), (3, 50), (4, 26)):
        capa.rellenar((np.abs(r - RADIO) > 7) & (np.abs(r - RADIO) <= 7 + d) & (b < 1 - d / 6), MORADO[5], a)
    # zona encerrada: un velo muy suave por dentro
    capa.rellenar((r < RADIO - 7) & (r > RADIO - 40) & (b < 0.10 * (1 - (RADIO - 7 - r) / 33)), MORADO[4], 120)
    # ladrillos: dos hileras desplazadas media celda, como un muro
    muro = np.abs(r - RADIO) <= 6
    hilera = r >= RADIO
    celda = np.where(hilera, th / paso, th / paso + 0.5)
    idx = np.floor(celda).astype(int) % CELDAS
    junta = ((celda % 1.0) < 1.6 / (RADIO * paso)) | (np.abs(r - RADIO) < 0.6)
    capa.rellenar(muro, MORADO[2])
    capa.rellenar(muro & (r < RADIO - 2.5) | muro & (r > RADIO + 3.5), MORADO[3])
    # algunos ladrillos se encienden en cada fotograma, como datos pasando
    for i in range(CELDAS):
        for h in (0, 1):
            if ((i * 37 + h * 11 + (f % 4) * 13) % 9) == 0:
                capa.rellenar(muro & (idx == i) & (hilera == bool(h)) & (np.abs(r - RADIO) > 0.6), MORADO[4])
    capa.rellenar(muro & junta, MORADO[0])
    # bits de cada ladrillo: tres puntos que cambian en cada fotograma
    for h in (0, 1):
        rr = RADIO + (3 if h else -3)
        for i in range(CELDAS):
            semilla = (i * 7 + h * 131) * 97
            for k in range(3):
                ang = (i + (0.5 if h == 0 else 0) + 0.25 + k * 0.25) * paso
                codigo = (semilla >> ((f + k) % 4)) ^ (i * 3 + k + f)
                encendido = (codigo % 3) != 0
                col = MORADO[7] if encendido else MORADO[4]
                if encendido and (i * 5 + k + h) % 17 == 0:
                    col = VERDE
                elif encendido and (i * 3 + k + h) % 23 == 0:
                    col = ROJO[3]
                x, y = c + math.cos(ang) * rr, c + math.sin(ang) * rr
                capa.px(x, y, col)
    # bordes de luz y pulsos de datos que dan la vuelta (4 fotogramas = 1 hueco)
    capa.rellenar(np.abs(r - (RADIO + 6.5)) <= 0.6, MORADO[5])
    capa.rellenar(np.abs(r - (RADIO - 6.5)) <= 0.6, MORADO[6])
    pulsos = 8
    for sentido, radio_borde in ((1, RADIO + 6.5), (-1, RADIO - 6.5)):
        fase = (th / (2 * math.pi) * pulsos - sentido * f / 4) % 1.0
        cola = (np.abs(r - radio_borde) <= 0.8)
        capa.rellenar(cola & (fase < 0.10), BLANCO)
        capa.rellenar(cola & (fase >= 0.10) & (fase < 0.22), MORADO[7])
    # postes de la jaula, con el núcleo que late
    for k in range(POSTES):
        ang = k * 2 * math.pi / POSTES
        x, y = c + math.cos(ang) * RADIO, c + math.sin(ang) * RADIO
        late = [MORADO[6], MORADO[7], BLANCO, MORADO[7]][(f + k) % 4]
        for oy in range(-4, 5):
            for ox in range(-4, 5):
                d = abs(ox) + abs(oy)
                if d == 5:
                    capa.px(x + ox, y + oy, MORADO[1])
                elif d >= 3 and d < 5:
                    capa.px(x + ox, y + oy, MORADO[4])
                elif d >= 1 and d < 3:
                    capa.px(x + ox, y + oy, MORADO[6])
                elif d == 0:
                    capa.px(x + ox, y + oy, late)
    capa.contorno((10, 4, 16))
    return capa, idx, muro, hilera


def jaula():
    guardar([muro(f)[0].uint8() for f in range(4)], 'jefe_jaula.png')


def rotura():
    from scipy import ndimage as ndi
    dx, dy, c = rejilla(N)
    r = np.hypot(dx, dy)
    base, idx, en_muro, hilera = muro(0)
    rng = random.Random(3)
    # cada ladrillo se parte en dos trozos: los de fuera apenas se mueven (el
    # fotograma acaba a 12 px del muro) y los de dentro caen hacia el centro
    paso = 2 * math.pi / CELDAS
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    trozos = []
    for h in (0, 1):
        for i in range(CELDAS):
            ladrillo = en_muro & (idx == i) & (hilera == bool(h))
            medio = ((th / paso + (0 if h else 0.5)) % 1.0) < 0.5
            for mitad in (ladrillo & medio, ladrillo & ~medio):
                ys, xs = np.nonzero(mitad)
                if len(ys) < 3:
                    continue
                ang = math.atan2(ys.mean() - c, xs.mean() - c)
                trozos.append((ys, xs, ang, rng.uniform(0.6, 1.5), h))
    # grietas en zigzag que cruzan el muro
    grietas = []
    for k in range(22):
        ang = (k + rng.uniform(-0.3, 0.3)) * 2 * math.pi / 22
        pts = []
        for j, rr in enumerate(range(RADIO - 8, RADIO + 9, 3)):
            pts.append((c + math.cos(ang) * rr + rng.uniform(-1.5, 1.5), c + math.sin(ang) * rr + rng.uniform(-1.5, 1.5)))
            ang += rng.uniform(-0.012, 0.012)
        grietas.append(pts)
    frames = []
    for f in range(5):
        capa = Capa(N)
        if f == 0:
            capa.pegar(base)
            for pts in grietas:
                capa.polilinea(pts, MORADO[8])
                capa.polilinea([(x + 1, y) for x, y in pts], MORADO[6])
        else:
            for ys, xs, ang, vel, h in trozos:
                dist = [0, 1, 2, 3, 3][f] if h else [0, -4, -12, -20, -28][f]
                m = np.zeros((26, 26), bool)
                y0, x0 = ys.min(), xs.min()
                if ys.max() - y0 >= 25 or xs.max() - x0 >= 25:
                    continue
                m[ys - y0, xs - x0] = True
                # cada vez más pequeños
                gastado = ndi.binary_erosion(m, iterations=max(0, f - 2)) if f >= 3 else m
                if f == 4 and vel < 0.9:
                    gastado = np.zeros_like(m)
                ox = math.cos(ang) * dist * vel
                oy = math.sin(ang) * dist * vel
                for yy_, xx_ in zip(*np.nonzero(gastado)):
                    y, x = yy_ + y0, xx_ + x0
                    col = base.a[y, x, :3]
                    if f == 1:
                        col = col * 0.5 + np.array(MORADO[7]) * 0.5
                    elif f >= 3:
                        col = col * 0.7 + np.array(MORADO[4]) * 0.3
                    capa.px(x + ox, y + oy, tuple(int(v) for v in col))
                # un punto que queda al final de los trozos que se gastan
                if f >= 3 and not gastado.any() and vel > 0.9:
                    capa.px(xs.mean() + ox, ys.mean() + oy, MORADO[5])
            # chispas de bits, hacia dentro
            for k in range(48):
                ang = (k * 2.399) % (2 * math.pi)
                d = RADIO - 8 - 50 * (f / 4) * (0.5 + (k % 5) * 0.15)
                col = [MORADO[7], VERDE, ROJO[3], BLANCO][k % 4] if f < 4 else MORADO[5]
                capa.px(c + math.cos(ang) * d, c + math.sin(ang) * d, col)
            capa.contorno((10, 4, 16))
        frames.append(capa.uint8())
    guardar(frames, 'jefe_jaula_rotura.png')


# ====================================================================== onda del pisotón
def onda():
    dx, dy, c = rejilla(N)
    r = np.hypot(dx, dy)
    th = np.arctan2(dy, dx)
    b = bayer(N, N)
    rng = random.Random(11)
    # grietas del suelo: caminos quebrados desde el centro
    grietas = []
    for k in range(9):
        ang = k * 2 * math.pi / 9 + rng.uniform(-0.2, 0.2)
        pts = [(c, c)]
        x, y = c, c
        largo = rng.uniform(70, 120)
        paso = 7
        for s in range(int(largo / paso)):
            ang += rng.uniform(-0.45, 0.45)
            x += math.cos(ang) * paso
            y += math.sin(ang) * paso
            pts.append((x, y))
        grietas.append(pts)
    polvo = [(rng.uniform(0, 2 * math.pi), rng.uniform(0.6, 1.0), rng.choice([MORADO[6], MORADO[5], MORADO[7]])) for _ in range(70)]
    frames = []
    for f in range(6):
        capa = Capa(N)
        t = f / 5
        # anillo de la onda: sale rápido y frena hasta los 180 px
        radio = 30 + (RADIO - 30) * (1 - (1 - t) ** 2.2)
        grosor = 9 - f * 1.3
        anillo = np.abs(r - radio) <= grosor / 2
        if f < 5:
            capa.rellenar(anillo & (b < 1 - t * 0.5), MORADO[5])
            capa.rellenar(np.abs(r - radio) <= max(0.7, grosor / 4), MORADO[7] if f < 3 else MORADO[6])
            # estela tramada por dentro del anillo
            capa.rellenar((r < radio - grosor / 2) & (r > radio - 30) & (b < 0.35 * (1 - t)), MORADO[4], 160)
        else:
            capa.rellenar(anillo & (b < 0.35), MORADO[5], 160)
        # grietas: se abren de golpe y se apagan
        largo_vis = min(1.0, 0.45 + f * 0.25)
        col = [BLANCO, MORADO[8], MORADO[7], MORADO[6], MORADO[5], MORADO[4]][f]
        for pts in grietas:
            n = max(2, int(len(pts) * largo_vis))
            for (x0, y0), (x1, y1) in zip(pts[:n - 1], pts[1:n]):
                capa.linea((x0 + 1, y0 + 1), (x1 + 1, y1 + 1), MORADO[1])
            capa.polilinea(pts[:n], col, 2 if f < 3 else 1)
        # golpe en el centro: una estrella blanca que se apaga
        if f <= 1:
            puntas = 1 + 0.45 * np.cos(th * 8) ** 8
            estrella = r <= (26 - f * 8) * puntas
            capa.rellenar(estrella, MORADO[6])
            capa.rellenar(r <= (20 - f * 7) * puntas, MORADO[7] if f else BLANCO)
            capa.rellenar(r <= 12 - f * 6, BLANCO)
        # polvo de datos que sale despedido
        for ang, vel, col in polvo:
            dist = 24 + (radio - 10) * vel
            if f == 5 and vel < 0.8:
                continue
            x, y = c + math.cos(ang) * dist, c + math.sin(ang) * dist
            capa.px(x, y, col)
            if f < 3:
                capa.px(x + 1, y, col)
        capa.contorno((10, 4, 16))
        frames.append(capa.uint8())
    guardar(frames, 'jefe_pisoton_onda.png')


# ====================================================================== ráfaga
def rafaga():
    frames = []
    # rombo de datos con la punta a la derecha y una estela de bits
    cuerpo = [
        "................",
        "................",
        "................",
        "................",
        "..........oo....",
        ".........oMMo...",
        "......ooo:MWMo..",
        ".....oMMMMWWWMo.",
        ".....oMMMMWWWMo.",
        "......ooo:MWMo..",
        ".........oMMo...",
        "..........oo....",
        "................",
        "................",
        "................",
        "................",
    ]
    col = {'o': MORADO[1], 'M': MORADO[5], 'W': MORADO[8], ':': MORADO[3]}
    estelas = [[(3, 7), (1, 8), (2, 6)], [(2, 8), (3, 6), (0, 7)], [(1, 7), (3, 8), (2, 6)], [(3, 7), (0, 8), (2, 9)]]
    for f in range(4):
        capa = Capa(16)
        # brillo alrededor
        for y, fila in enumerate(cuerpo):
            for x, ch in enumerate(fila):
                if ch != '.':
                    capa.px(x, y, col[ch])
        brillo = Capa(16)
        brillo.a = capa.a.copy()
        brillo.brillo(MORADO[5], 110, 1)
        brillo.a[capa.a[..., 3] > 0] = 0
        capa.pegar(brillo)
        # el centro parpadea
        capa.px(11, 7, BLANCO if f % 2 == 0 else MORADO[7])
        capa.px(11, 8, MORADO[7] if f % 2 == 0 else BLANCO)
        # bits de la estela
        for i, (x, y) in enumerate(estelas[f]):
            capa.px(x, y, [MORADO[6], VERDE, MORADO[7]][i] if (f + i) % 3 else ROJO[3])
        frames.append(capa.uint8())
    guardar(frames, 'jefe_rafaga.png')


# ====================================================================== rabia
def ruido_llamas(n, semilla):
    """Ruido de vetas verticales que se repite cada n/2 píxeles en vertical,
    para que al subir 1/8 de n por fotograma el bucle de 4 encaje."""
    rng = np.random.default_rng(semilla)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    v = np.zeros((n, n))
    for kx, ky, amp in ((3, 2, 1.0), (5, 2, 0.8), (8, 4, 0.5), (13, 4, 0.35), (21, 6, 0.2)):
        fase = rng.uniform(0, 2 * math.pi)
        v += amp * np.sin(2 * math.pi * (kx * xx / n + ky * yy / n) + fase)
        fase = rng.uniform(0, 2 * math.pi)
        v += amp * 0.6 * np.sin(2 * math.pi * (-kx * xx / n + ky * yy / n) + fase)
    return (v - v.min()) / (v.max() - v.min())


def rabia():
    from scipy import ndimage as ndi
    n = 192
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    c = (n - 1) / 2
    b = bayer(n, n)
    ruido = ruido_llamas(n, 5)
    # la silueta del jefe (cabeza estrecha, cuerpo y capa anchos), con el
    # centro del fotograma del jefe en el centro: 128x144 dentro de 192x192
    perfil = [(34, 0), (38, 16), (52, 22), (70, 28), (88, 44), (112, 48), (140, 44), (160, 30), (166, 0)]
    izq = [(c - w, y) for y, w in perfil]
    der = [(c + w, y) for y, w in reversed(perfil)]
    capa0 = Capa(n)
    cuerpo = capa0.mascara_poligono(izq + der)
    fuera = ndi.distance_transform_edt(~cuerpo)
    dentro_d = ndi.distance_transform_edt(cuerpo)
    frames = []
    for f in range(4):
        capa = Capa(n)
        # el ruido sube 24 px por fotograma (se repite cada 96 en vertical)
        ru = np.roll(ruido, -f * 24, axis=0)
        arriba = np.clip((c + 10 - yy) / c, 0, 1)
        alto = np.minimum((4 + 24 * ru ** 1.6) * (0.55 + 1.2 * arriba), 29)
        llama = (~cuerpo) & (fuera < alto)
        k = np.clip(fuera / np.maximum(alto, 1e-6), 0, 1)
        # por dentro, un resplandor rojo translúcido (queda casi todo detrás del jefe)
        capa.rellenar(cuerpo, ROJO[2], 90)
        capa.rellenar(cuerpo & (dentro_d < 6), ROJO[3], 150)
        capa.rellenar(cuerpo & (dentro_d < 2.5), ROJO[4], 200)
        capa.rellenar(llama, ROJO[1])
        capa.rellenar(llama & (k < 0.72), ROJO[2])
        capa.rellenar(llama & (k < 0.42), ROJO[3])
        capa.rellenar(llama & (k < 0.16), ROJO[4])
        # puntas de las llamas en morado oscuro, tramadas
        capa.rellenar(llama & (k > 0.86), (96, 16, 74))
        capa.a[llama & (k > 0.93) & (b < 0.5)] = 0
        # brasas que suben, rojas y moradas
        for j in range(14):
            fase = (f / 4 + j / 14) % 1.0
            lado = -1 if j % 2 else 1
            x = c + lado * (30 + 18 * ((j * 7) % 5) / 4) + math.sin(fase * 6.28 + j) * 2
            y = c + 50 - fase * 140
            col = [ROJO[4], MORADO[6], ROJO[3]][j % 3] if fase < 0.75 else ROJO[2]
            capa.px(x, y, col)
            if fase < 0.5:
                capa.px(x, y + 1, ROJO[2] if j % 3 != 1 else MORADO[4])
        frames.append(capa.uint8())
    guardar(frames, 'jefe_rabia.png')


if __name__ == '__main__':
    aviso()
    jaula()
    rotura()
    onda()
    rafaga()
    rabia()
    print('ok')
