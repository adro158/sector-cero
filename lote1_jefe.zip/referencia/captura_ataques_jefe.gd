extends SceneTree

# Prueba temporal: partida real sin horda. El jefe aparece cerca del jugador,
# quieto y con la rabia, avisa, da el pisotón, sale la jaula, dispara dos
# ráfagas y la jaula se rompe.
const Demo := preload("res://prueba/demo_ataques_jefe.gd")
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		var jugador: Node2D = _raiz.get_node("Jugador")
		jugador.get_node("Salud").invencible = true
		jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		var jefe: Node2D = _raiz.get_node("Jefe")
		var centro := jugador.global_position + Vector2(-70, -40)
		jefe.aparecer(centro)
		jefe.process_mode = Node.PROCESS_MODE_DISABLED
		var suelo := Demo.new()
		suelo.capa = "suelo"
		suelo.centro = centro
		suelo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		_raiz.add_child(suelo)
		_raiz.move_child(suelo, 0)
		var aura := Demo.new()
		aura.capa = "aura"
		aura.position = Vector2(0, -42)
		aura.show_behind_parent = true
		aura.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		jefe.add_child(aura)
		aura.process_mode = Node.PROCESS_MODE_ALWAYS
		var encima := Demo.new()
		encima.capa = "encima"
		encima.centro = centro
		encima.z_index = 4
		encima.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		_raiz.add_child(encima)
		print("jefe en ", centro, " jugador en ", jugador.global_position)
	return _frames > 2 + 160
