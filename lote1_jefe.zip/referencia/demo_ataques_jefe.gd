extends Node2D

## Prueba temporal: dibuja los sprites de los ataques nuevos del jefe con sus
## tiempos. Hay tres capas: "suelo" (primer hijo de RaizJuego, debajo de todo),
## "aura" (hija del jefe, detrás de él) y "encima" (los proyectiles).

const AVISO := preload("res://medios/sprites/jefe/jefe_jaula_aviso.png")
const JAULA := preload("res://medios/sprites/jefe/jefe_jaula.png")
const ROTURA := preload("res://medios/sprites/jefe/jefe_jaula_rotura.png")
const ONDA := preload("res://medios/sprites/jefe/jefe_pisoton_onda.png")
const RAFAGA := preload("res://medios/sprites/jefe/jefe_rafaga.png")
const RABIA := preload("res://medios/sprites/jefe/jefe_rabia.png")

const INICIO_AVISO := 0.6
const GOLPE := 1.4                # 0,8 s de aviso
const FIN_JAULA := 4.4            # 3 s de jaula
const RAFAGAS := [2.0, 3.0]
const VELOCIDAD_RAFAGA := 220.0

var capa := "suelo"
var centro := Vector2.ZERO
var t := 0.0


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _tira(textura: Texture2D, fotogramas: int, fotograma: int, en: Vector2) -> void:
	var lado := Vector2(textura.get_width() / fotogramas, textura.get_height())
	draw_texture_rect_region(textura, Rect2(en - lado / 2, lado), Rect2(Vector2(fotograma * lado.x, 0), lado))


func _draw() -> void:
	match capa:
		"aura":
			_tira(RABIA, 4, int(t / 0.1) % 4, Vector2.ZERO)
		"suelo":
			if t >= INICIO_AVISO and t < GOLPE:
				_tira(AVISO, 6, mini(int((t - INICIO_AVISO) / (0.8 / 6.0)), 5), centro)
			if t >= GOLPE and t < FIN_JAULA:
				_tira(JAULA, 4, int((t - GOLPE) / 0.12) % 4, centro)
			if t >= GOLPE and t < GOLPE + 0.36:
				_tira(ONDA, 6, mini(int((t - GOLPE) / 0.06), 5), centro)
			if t >= FIN_JAULA and t < FIN_JAULA + 0.4:
				_tira(ROTURA, 5, mini(int((t - FIN_JAULA) / 0.08), 4), centro)
		"encima":
			for k in RAFAGAS.size():
				var vida: float = t - RAFAGAS[k]
				if vida < 0.0 or vida > 1.6:
					continue
				for i in 12:
					var angulo := TAU * i / 12.0 + k * TAU / 24.0
					var pos := centro + Vector2.from_angle(angulo) * (30.0 + VELOCIDAD_RAFAGA * vida)
					draw_set_transform(pos, angulo)
					_tira(RAFAGA, 4, int(vida / 0.08) % 4, Vector2.ZERO)
					draw_set_transform(Vector2.ZERO)
