"""Efectos de respuesta en la partida de Sector Cero (lote 4).

- subir_nivel.png        8 x 128x128  columna de luz cian con anillos que suben
- cambio_personaje.png   6 x 96x96    entrada con glitch, EN GRISES (se tiñe del personaje)
- curar.png              6 x 96x96    destello verde con cruces que suben
- muerte_horda.png       6 x 48x48    el enemigo se deshace en píxeles, EN GRISES (se tiñe del tipo)

Los tres primeros van centrados en el centro del sprite del jugador
(position + (0, -22)): los pies quedan 32 px por debajo del centro del
fotograma. El último, en la posición del enemigo.

Uso: python3 generar_efectos.py  (numpy y Pillow; usa pixel.py)
"""
import math
import os
import random
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixel import Capa, bayer

OUT = './'
CIAN = [(0, 60, 80), (0, 120, 150), (0, 217, 242), (150, 240, 255), (235, 252, 255)]
VERDE = [(10, 60, 30), (30, 140, 80), (77, 255, 153), (170, 255, 205), (235, 255, 240)]
GRIS = [(70, 70, 70), (120, 120, 120), (180, 180, 180), (225, 225, 225), (255, 255, 255)]
BLANCO = (255, 255, 255)
PIES = 32          # los pies, por debajo del centro del fotograma


def guardar(capas, nombre):
    alto, ancho = capas[0].h, capas[0].w
    hoja = np.zeros((alto, ancho * len(capas), 4), np.uint8)
    for i, c in enumerate(capas):
        hoja[:, i * ancho:(i + 1) * ancho] = c.uint8()
    Image.fromarray(hoja, 'RGBA').save(OUT + nombre)


def elipse_anillo(capa, cx, cy, rx, ry, col, grosor=1.0, filtro=None):
    yy, xx = np.mgrid[0:capa.h, 0:capa.w].astype(np.float64)
    d = np.hypot((xx - cx) / rx, (yy - cy) / ry)
    m = np.abs(d - 1) * min(rx, ry) <= grosor / 2 + 0.25
    if filtro is not None:
        m &= filtro
    capa.rellenar(m, col)
    return m


def cruz(capa, x, y, col, centro, tam=2):
    for k in range(-tam, tam + 1):
        capa.px(x + k, y, col)
        capa.px(x, y + k, col)
    capa.px(x, y, centro)


# ====================================================================== subir de nivel
def subir_nivel():
    n = 128
    c = (n - 1) / 2
    suelo = c + PIES
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    b = bayer(n, n)
    rng = random.Random(4)
    chispas = [(rng.uniform(-20, 20), rng.uniform(0, 1), rng.choice([0, 1, 2])) for _ in range(14)]
    luz = [0.5, 0.9, 1.0, 1.0, 0.85, 0.65, 0.4, 0.2]
    capas = []
    for f in range(8):
        capa = Capa(n)
        L = luz[f]
        # columna de luz: sube desde el suelo, más clara en el centro
        alto = min(1.0, (f + 1) / 3) * (suelo + 2)
        dentro = (yy <= suelo) & (yy >= suelo - alto)
        ancho = 17 if f < 6 else 17 - (f - 5) * 4
        perfil = 1 - np.abs(xx - c) / ancho
        columna = dentro & (perfil > 0)
        capa.rellenar(columna & (b < perfil * 0.45 * L), CIAN[1], 170)
        capa.rellenar(columna & (perfil > 0.55) & (b < perfil * 0.6 * L), CIAN[2], 200)
        capa.rellenar(columna & (perfil > 0.85) & (b < L * 0.8), CIAN[3], 220)
        # destello en el suelo al empezar
        if f <= 2:
            rx = 18 + f * 8
            elipse_anillo(capa, c, suelo, rx, rx * 0.3, CIAN[3] if f < 2 else CIAN[2], 2)
            if f == 0:
                capa.rellenar(np.hypot((xx - c) / 14, (yy - suelo) / 4.5) <= 1, CIAN[4])
        # anillos que suben por el cuerpo (dos, uno detrás de otro)
        for inicio in (0, 2):
            k = f - inicio
            if 0 <= k <= 5:
                y = suelo - k * 13
                rx = 24 - k * 1.2
                col = CIAN[4] if k < 3 else (CIAN[3] if k < 5 else CIAN[2])
                elipse_anillo(capa, c, y, rx, rx * 0.28, CIAN[2], 2.4)
                elipse_anillo(capa, c, y, rx, rx * 0.28, col, 1.0, filtro=yy >= y)   # la mitad de delante, más clara
        # chispas que suben
        for x, fase, tipo in chispas:
            t = (fase + f / 8) % 1.0
            if f >= 1 and t * 8 < f + 3:
                y = suelo - 6 - t * (suelo - 4)
                if tipo == 0:
                    cruz(capa, c + x, y, CIAN[3], BLANCO, 1)
                else:
                    capa.px(c + x, y, CIAN[3] if tipo == 1 else CIAN[2])
        # flecha hacia arriba encima de la cabeza
        if 3 <= f <= 6:
            ya = c - 40 - (f - 3) * 4
            for k in range(6):
                for g in (0, 1):
                    capa.px(c - k, ya + k + g, CIAN[4] if g == 0 else CIAN[2])
                    capa.px(c + k, ya + k + g, CIAN[4] if g == 0 else CIAN[2])
        capas.append(capa)
    guardar(capas, 'subir_nivel.png')


# ====================================================================== cambio de personaje (grises)
def cambio_personaje():
    n = 96
    c = (n - 1) / 2
    suelo = c + PIES
    arriba = c - 38
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    b = bayer(n, n)
    rng = random.Random(8)
    cortes = [(rng.uniform(arriba, suelo), rng.randint(2, 5), rng.choice([-1, 1]) * rng.uniform(3, 9)) for _ in range(9)]
    bloques = [(rng.uniform(-22, 22), rng.uniform(arriba - 4, suelo), rng.uniform(0.6, 1.4)) for _ in range(26)]
    capas = []
    for f in range(6):
        capa = Capa(n)
        if f == 0:
            # rayo vertical fino de arriba al suelo
            capa.rellenar((np.abs(xx - c) <= 1.5) & (yy <= suelo), GRIS[4])
            capa.rellenar((np.abs(xx - c) <= 3.5) & (np.abs(xx - c) > 1.5) & (yy <= suelo) & (b < 0.5), GRIS[3], 200)
            capa.rellenar(np.hypot((xx - c) / 10, (yy - suelo) / 3) <= 1, GRIS[4])
            for y, alto, _ in cortes[:3]:
                capa.rellenar((np.abs(yy - y) <= 0.6) & (np.abs(xx - c) <= 16), GRIS[3])
        else:
            ancho = [0, 10, 19, 19, 16, 10][f]
            densidad = [0, 0.8, 0.7, 0.45, 0.22, 0.08][f]
            # la caja de líneas de barrido (una sí y una no)
            caja = (np.abs(xx - c) <= ancho) & (yy >= arriba) & (yy <= suelo)
            barrido = caja & (yy.astype(int) % 2 == 0)
            capa.rellenar(barrido & (b < densidad), GRIS[2], 190)
            capa.rellenar(caja & (yy.astype(int) % 2 == 1) & (b < densidad * 0.4), GRIS[1], 150)
            # bordes claros
            if f <= 3:
                borde = caja & ((np.abs(np.abs(xx - c) - ancho) < 0.6) | (np.abs(yy - arriba) < 0.6))
                capa.rellenar(borde & (b < 0.9 - f * 0.15), GRIS[4])
            # cortes: franjas desplazadas a un lado (el glitch)
            for y, alto, desp in cortes:
                if f >= 2:
                    d = desp * (1 + (f - 2) * 0.6)
                    franja = (yy >= y) & (yy < y + alto) & (np.abs(xx - c - d) <= ancho) & (b < densidad + 0.15)
                    capa.rellenar(franja, GRIS[3] if f < 4 else GRIS[2])
                    capa.rellenar(franja & (np.abs(np.abs(xx - c - d) - ancho) < 0.6), GRIS[4])
            # bloques de ruido que salen despedidos
            for x, y, vel in bloques:
                if f >= 2:
                    dx = x * (1 + (f - 2) * 0.35 * vel)
                    lado = 2 if f < 5 else 1
                    if f >= 4 and vel < 0.9:
                        continue
                    for oy in range(lado):
                        for ox in range(lado):
                            capa.px(c + dx + ox, y + oy, GRIS[4] if f < 4 else GRIS[2])
        capas.append(capa)
    guardar(capas, 'cambio_personaje.png')


# ====================================================================== curarse
def curar():
    n = 96
    c = (n - 1) / 2
    suelo = c + PIES
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    b = bayer(n, n)
    rng = random.Random(12)
    cruces = [(rng.uniform(-20, 20), rng.uniform(0, 30), rng.choice([1, 2])) for _ in range(8)]
    capas = []
    for f in range(6):
        capa = Capa(n)
        # brillo verde sobre el cuerpo, que se apaga
        cuerpo = np.hypot((xx - c) / 22, (yy - c) / 38) <= 1
        capa.rellenar(cuerpo & (b < [0.45, 0.35, 0.22, 0.12, 0.05, 0][f]), VERDE[2], 150)
        # anillo en el suelo que se abre
        rx = 12 + f * 4.5
        if f < 5:
            elipse_anillo(capa, c, suelo, rx, rx * 0.3, VERDE[2], 2.4)
            elipse_anillo(capa, c, suelo, rx, rx * 0.3, VERDE[4] if f < 3 else VERDE[3], 1.0, filtro=yy >= suelo)
        if f == 0:
            capa.rellenar(np.hypot((xx - c) / 10, (yy - suelo) / 3.2) <= 1, VERDE[4])
        # cruces que suben
        for x, y0, tam in cruces:
            y = suelo - 12 - y0 - f * 7
            if y < 4:
                continue
            if f == 5 and tam == 1:
                continue
            cruz(capa, c + x, y, VERDE[3] if f < 4 else VERDE[2], BLANCO if f < 4 else VERDE[3], tam)
        capas.append(capa)
    guardar(capas, 'curar.png')


# ====================================================================== muerte de la horda (grises)
def muerte_horda():
    n = 48
    c = (n - 1) / 2
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    b = bayer(n, n)
    rng = random.Random(30)
    # trocitos de 3x3 de un enemigo de unos 21 px
    trozos = []
    for gy in range(-3, 4):
        for gx in range(-3, 4):
            if gx * gx + gy * gy > 12:
                continue
            ang = math.atan2(gy + rng.uniform(-0.5, 0.5), gx + rng.uniform(-0.5, 0.5))
            trozos.append((gx * 3, gy * 3, ang, rng.uniform(0.6, 1.4), rng.random()))
    capas = []
    for f in range(6):
        capa = Capa(n)
        if f == 0:
            # destello: el enemigo se pone blanco
            cuadro = (np.abs(xx - c) <= 10) & (np.abs(yy - c) <= 10) & (np.abs(xx - c) + np.abs(yy - c) <= 18)
            capa.rellenar(cuadro, GRIS[3])
            capa.rellenar(cuadro & (np.abs(xx - c) <= 7) & (np.abs(yy - c) <= 7) & (np.abs(xx - c) + np.abs(yy - c) <= 12), GRIS[4])
        else:
            for x, y, ang, vel, azar in trozos:
                d = [0, 1.5, 5, 9, 13, 16][f] * vel
                px_ = c + x + math.cos(ang) * d
                py_ = c + y + math.sin(ang) * d - [0, 0, 1, 2, 4, 6][f] * vel
                if azar < (f - 1) * 0.2:
                    continue
                lado = [0, 3, 2, 2, 1, 1][f]
                col = [None, GRIS[4], GRIS[3], GRIS[2], GRIS[2], GRIS[1]][f]
                for oy in range(lado):
                    for ox in range(lado):
                        capa.px(px_ + ox, py_ + oy, col)
        capas.append(capa)
    guardar(capas, 'muerte_horda.png')


if __name__ == '__main__':
    subir_nivel()
    cambio_personaje()
    curar()
    muerte_horda()
    print('ok')
