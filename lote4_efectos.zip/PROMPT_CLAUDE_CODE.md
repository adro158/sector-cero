Hoy toca que **la partida responda con efectos**: subir de nivel, cambiar de personaje, curarse y la muerte de la horda, con unos sprites que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a crear y tocar, y qué haces con las partículas que ya salen al morir y al subir de nivel (`pool_particulas.gd`). Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 4 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `efectos_en_juego.gif`: grabado en Godot 4.7.2 en una partida con `referencia/efectos_partida.gd`
- `vista_lote4.png`: todo el lote a x2

Tamaños, tiempos, centro y capa de cada uno: `LEEME.txt`.

## Los sprites

En `projecte/medios/sprites/efectos/`:

| Fichero | Fotogramas | Tiempo | Cuándo | Color |
|---|---|---|---|---|
| `subir_nivel.png` | 8 x 128x128 | 0,08 s | Al subir de nivel | Cian, ya pintado |
| `cambio_personaje.png` | 6 x 96x96 | 0,05 s | Al entrar un personaje | **Grises**: se tiñe con `DatosPersonaje.color` |
| `curar.png` | 6 x 96x96 | 0,07 s | Al coger el corazón de los élites | Verde, ya pintado |
| `muerte_horda.png` | 6 x 48x48 | 0,05 s | Al morir un enemigo de la horda | **Grises**: se tiñe con `DatosTipoEnemigo.color` |

## Cómo lo quiero

- **Los tres del jugador** (subir de nivel, cambio y curar) van centrados en el centro de su sprite, `position + (0, -22)`. Le siguen si se mueve y van encima de él. Son tramados, así que el personaje se ve a través.
- **Subir de nivel.** Al subir, el juego se pausa para elegir mejora. Que el efecto salga al volver de la pausa (con la mejora elegida), para que se vea. Si suben varios niveles seguidos, uno basta.
- **Cambio de personaje.** Con el color del que entra: con E/Q y cuando cae uno y se elige otro. Al empezar la partida no hace falta.
- **Curar.** Solo con el corazón de los élites. No con el robo de vida del Firewall, que cura en cada golpe.
- **Muerte de la horda.**
  - Teñida del color de su tipo y escalada con su tamaño (`tamano / 24`), donde murió, encima de la horda.
  - Pueden morir muchos a la vez: mira el rendimiento (con un solo nodo que lo dibuje todo, como en la prueba, o con un MultiMesh como las partículas).
  - Propónme si sustituye al estallido de partículas al morir o va con él con menos partículas.
  - Jefes y élites: se quedan como están.

`referencia/efectos_partida.gd` es el nodo de la prueba: escucha `enemigo_muerto` y `personaje_cambiado` y dibuja cada efecto con `draw_texture_rect_region` y su color. Úsalo de guía y hazlo como sea más fácil de explicar, con los scripts por debajo de ~200 líneas.

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`.
- Con ventana, haz capturas de:
  - cada efecto
  - la muerte de cada tipo de la horda con su color
  - el cambio con cada personaje
  - subir de nivel al cerrar el panel
  - el corazón
- Comprueba que al pausar se paran.
- **Rendimiento:** mídelo en casa con `herramientas/medir_rendimiento.gd` en un momento con mucha horda muriendo (minuto 9-10).
- No cambia el balance: no hace falta el simulador, pero pasa una partida para comprobar que no salen errores.
- **Documentación:**
  - `creditos.md`: los sprites del lote 4 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md`.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/` y la documentación. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- **Commits pequeños** con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat` de los efectos del jugador
  - `feat` de la muerte de la horda
  - `docs`
- No publiques ninguna release.
