extends SceneTree

# Prueba temporal: partida real con horda alrededor del Espadachín; mueren
# enemigos de varios tipos, sube de nivel (solo el efecto), cambia al Mago y
# al Segador y se cura.
const Efectos := preload("res://prueba/efectos_partida.gd")
const TIPOS := ["BitCorrupto", "PaquetePerdido", "ProcesoColgado", "Troyano", "Ransomware"]
var _raiz: Node
var _frames := 0
var _efectos: Node2D
var _jugador: Node2D
var _cambio: Node


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _horda(cuantos: int) -> void:
	for k in cuantos:
		_raiz.get_node(TIPOS[k % 5]).aparecer(_jugador.global_position + Vector2.from_angle(randf() * TAU) * randf_range(110, 190))


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		seed(3)
		_jugador = _raiz.get_node("Jugador")
		_jugador.get_node("Salud").invencible = true
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("PoolGemas").visible = false
		_raiz.get_node("PoolNumeros").visible = false
		_cambio = _jugador.get_node("CambioPersonaje")
		_efectos = Efectos.new()
		_efectos.z_index = 5
		_efectos.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		_raiz.add_child(_efectos)
	match _frames:
		4, 44, 124, 204:
			_horda(12)
		30:
			_efectos.subir()
		90:
			_cambio._entrar(1)
			_cambio._aplicar()
		140:
			_efectos.curar()
		180:
			_cambio._entrar(2)
			_cambio._aplicar()
	if _frames % 20 == 16:
		for t in TIPOS:
			_raiz.get_node(t).danar_en_area(_jugador.global_position, 400.0, 99999.0)
	return _frames > 240
