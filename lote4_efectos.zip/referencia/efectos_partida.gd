extends Node2D

## Prueba temporal: dibuja los efectos del lote 4. Los del jugador le siguen
## (centrados en el centro de su sprite, position + (0, -22)); las muertes de
## la horda se quedan donde murió cada enemigo, teñidas de su color y
## escaladas a su tamaño.

const RUTA := "res://medios/sprites/efectos/"
const SUBIR := preload(RUTA + "subir_nivel.png")
const CAMBIO := preload(RUTA + "cambio_personaje.png")
const CURAR := preload(RUTA + "curar.png")
const MUERTE := preload(RUTA + "muerte_horda.png")

var _jugador: Node2D
## [hoja, fotogramas, segundos por fotograma, segundos, color, posición o null (sigue al jugador), escala]
var _efectos: Array = []
var _colores := {}
var _tamanos := {}


func _ready() -> void:
	_jugador = get_tree().get_first_node_in_group("jugador")
	for gestor in get_tree().get_nodes_in_group("gestor_enemigos"):
		_colores[gestor.datos.tipo] = gestor.datos.color
		_tamanos[gestor.datos.tipo] = gestor.datos.tamano
	var bus := get_node("/root/BusEventos")
	bus.enemigo_muerto.connect(func(posicion, tipo):
		if _colores.has(tipo):
			_efectos.append([MUERTE, 6, 0.05, 0.0, _colores[tipo], posicion, _tamanos[tipo] / 24.0]))
	bus.personaje_cambiado.connect(func(actual, _arma, _siguiente, _espera):
		_efectos.append([CAMBIO, 6, 0.05, 0.0, actual.color, null, 1.0]))


func subir() -> void:
	_efectos.append([SUBIR, 8, 0.08, 0.0, Color.WHITE, null, 1.0])


func curar() -> void:
	_efectos.append([CURAR, 6, 0.07, 0.0, Color.WHITE, null, 1.0])


func _process(delta: float) -> void:
	for efecto in _efectos:
		efecto[3] += delta
	_efectos = _efectos.filter(func(efecto): return efecto[3] < efecto[1] * efecto[2])
	queue_redraw()


func _draw() -> void:
	for efecto in _efectos:
		var hoja: Texture2D = efecto[0]
		var lado := Vector2(hoja.get_width() / efecto[1], hoja.get_height())
		var centro: Vector2 = efecto[5] if efecto[5] != null else _jugador.global_position + Vector2(0, -22)
		var tam: Vector2 = lado * efecto[6]
		var n := mini(int(efecto[3] / efecto[2]), efecto[1] - 1)
		draw_texture_rect_region(hoja, Rect2(centro - tam / 2.0, tam), Rect2(Vector2(n * lado.x, 0.0), lado), efecto[4])
