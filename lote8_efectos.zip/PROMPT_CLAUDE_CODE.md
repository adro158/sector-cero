Hoy toca el **lote 8: efectos de la partida**. Son sprites para lo que todavía se dibuja por código (anillos, rectángulos, la "R" de la ulti, el texto "CLICK") o no tiene efecto (la caída, el golpe, el escudo, la muerte del élite, la evolución). Los he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto.** Dime los ficheros que vas a tocar y, sobre todo, cómo encaja la caída del personaje con la pausa. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 8 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `vista_lote8.png`: todo el lote.
- `gifs/`: cada efecto con sus tiempos.
- `efectos_en_juego.gif`: grabado en Godot 4.7.2.

Tamaños, tiempos, centro, capa y si se tiñe: `LEEME.txt`.

## Los sprites

Tiras horizontales. "Grises" quiere decir que se tiñen con `modulate` o con el color de `draw_texture_rect_region`.

En `projecte/medios/sprites/efectos/`:

| Fichero | Fotogramas | Tiempo | Capa | Color |
|---|---|---|---|---|
| `caida_personaje.png` | 8 x 96x96 | 0,08 s, una vez | encima, centro del sprite | grises: color del personaje |
| `derrota_personaje.png` | 12 x 96x96 | 0,08 s, una vez | igual | grises: color del personaje |
| `golpe_recibido.png` | 4 x 64x64 | 0,05 s, una vez | encima, centro del sprite | grises: rojo |
| `escudo_proteccion.png` | 4 x 80x80 | 0,1 s, en bucle | encima, centro del sprite | grises: color del personaje |
| `particula.png` | 8x8 | — | textura del MultiMesh | grises: color de cada partícula |
| `muerte_elite.png` | 8 x 96x96 | 0,06 s, una vez | encima de la horda (z 4) | ya pintada |
| `afijo_explosivo.png` | 4 x 64x64 | 0,12 s, en bucle | **detrás** del élite | grises: `afijo.color` |
| `evolucion_herramienta.png` | 10 x 128x128 | 0,07 s, una vez | encima, centro del sprite | grises: color del personaje |
| `invocacion_kernel_panic.png` | 8 x 320x320 | 0,125 s, una vez | **debajo** del jefe, en el suelo | ya pintada |
| `barra_enemigo_marco.png` + `_relleno.png` | 48x9 y 44x5 | — | donde las barras de ahora | grises |
| `barra_personaje_marco.png` + `_vida.png` + `_ulti.png` | 44x12, 40x5 y 40x2 | — | sobre el personaje | grises |
| `ulti_lista.png` | 2 x 8x8 | 0,25 s, en bucle | a la derecha de la barra | ya pintada |
| `fragmento_datos_anim.png` | 4 x 12x12 | 0,12 s, en bucle | como el de ahora | grises, como el de ahora |
| `fragmento_recogida.png` | 4 x 24x24 | 0,06 s, una vez | encima, donde se recoge | grises: color del fragmento |
| `mira_rayo_tramo.png` | 4 x 32x16 | 0,08 s, en bucle | la mira del Mago | ya pintada |
| `mira_rayo_diana.png` | 4 x 32x32 | 0,1 s, en bucle | al final de la mira | ya pintada |
| `click_izquierdo.png` | 16x16 | — | donde el texto "CLICK" | ya pintado |

En `projecte/medios/sprites/herramientas/`:

| Fichero | Fotogramas | Tiempo | Para qué |
|---|---|---|---|
| `proyectil_ping_anim.png` | 4 x 24x12 | 0,06 s, en bucle | el Ping; el fotograma 0 es `proyectil_ping.png` |
| `proyectil_ping_inundacion.png` | 4 x 32x14 | 0,06 s, en bucle | el Ping de inundación (la evolución) |

## Cómo lo quiero

### Personaje

- **Caída.** Cuando cae el personaje activo, su sprite se esconde y sale `caida_personaje.png`, teñida de su color. El panel para elegir quién sigue sale al acabar (0,64 s).
  - Propónme cómo encaja con la pausa. Lo más fácil sería pausar como ahora y que el efecto se anime en pausa (`PROCESS_MODE_ALWAYS`); así no cambia nada del juego.
  - Si propones retrasar la pausa, pasa el simulador antes y después.
- **Derrota.** Cuando cae el último, `derrota_personaje.png` (0,96 s) antes de la pantalla final.
- **Golpe.** Con `Salud.danado`, encima del personaje y teñido de rojo, además del parpadeo de ahora.
- **Escudo.** Mientras dura la protección de 2 s al entrar tras una caída, en bucle y teñido del color del que entra.
- **Evolución.** Con `arma_evolucionada`, si la evoluciona el activo. Teñida de su color, en `efectos_jugador.gd`, como el de subir de nivel. Propónme qué hacer si evoluciona uno del banquillo.

### Partículas y élite

- **Partícula.** Textura del `MultiMeshInstance2D` de `pool_particulas.gd`, con el `QuadMesh` a 8x8.
- **Muerte del élite.** Al morir, el sprite se esconde y sale el efecto en su sitio. Si tenía Explosivo, la explosión sigue como ahora.
- **Mecha del Explosivo.** En `dibujo_elite.gd`, en vez del anillo fino del Explosivo, con los demás afijos que van detrás.

### Kernel Panic

- **Invocación.** Sustituye al anillo que crece en `jefe.gd`, centrada donde está quieto invocando y debajo de él. Los 8 fotogramas duran 1 s, lo que vale `duracion_invocacion`. Si ese número cambia, que la tira se ajuste a lo que dure.

### Barras de vida

- **Enemigos.** En `barra_vida_enemigo.gd`, el marco en 3 trozos (5 px a cada lado tal cual y el centro estirado) y el relleno recortado a la vida que quede, teñido de `datos.color`. Así vale para todos los anchos (el élite, 70 px).
- **Personaje.** En `barra_vida.gd`, el marco y los dos rellenos.
- **Ulti lista.** El icono parpadeando a la derecha en lugar de la "R".
- Quita lo que deje de usarse (`ancho`, `alto`).

### Ping y fragmentos

- **Ping.** Los proyectiles y los fragmentos son un MultiMesh. Propónme cómo animarlos de la forma más fácil de explicar. Por ejemplo, cortar las tiras en 4 texturas al cargar y cambiar la textura de la malla cada 0,06 s (todas a la vez vale).
  - Comprueba antes si un `AtlasTexture` funciona como textura de un MultiMesh.
  - Con el Ping de inundación, el sprite de inundación.
- **Fragmento recogido.** Al recogerlo, `fragmento_recogida.png` donde estaba, teñido de su color. Con un pool pequeño como `muertes_horda.gd`, que se recogen muchos.

### Mira del Mago

- En `dibujo_ultis.gd`, la línea a trazos pasa a ser el tramo repetido a lo largo de la mira, girado con su ángulo (`draw_set_transform`).
- Al final, la diana.
- El texto "CLICK" pasa a ser el icono.

### Probado

`referencia/efectos.diff` es lo que cambié de verdad en la prueba: la partícula, las dos barras, la ulti lista y la mecha. Lo demás lo dibujó `referencia/muestra_lote8.gd` en bucle, solo para la grabación. Úsalos de guía, no hace falta copiarlos así.

Ojo: en la prueba, las texturas cargadas con `load()` dentro de `_draw` salían como rectángulos blancos al grabar. Con `preload` (o cargadas en `_ready`) van bien.

### Código

- Que todo se pueda explicar en la defensa: lo más simple que funcione.
- Si un script crece mucho, saca el dibujo a otro aparte, con `preload` y sin `class_name`.
- Si añades señales al bus, actualiza la lista de `GEMINI.md`.

## Al terminar

- **Validación del CLAUDE.md:** import y `--quit-after`.
- **Capturas con ventana**, con el menú de desarrollador (F1) o una instrumentación temporal, de:
  - la caída y el panel después
  - la derrota final
  - el golpe
  - el escudo
  - las partículas
  - la muerte de un élite, con y sin Explosivo
  - la mecha
  - la evolución
  - la invocación de Kernel Panic
  - las barras (horda fuerte, élite, anclas y jugador, con la ulti llena)
  - el Ping y el de inundación
  - los fragmentos y su recogida
  - la mira del Mago

  Comprueba que todo se para con la pausa y sigue después. Borra la instrumentación al acabar.
- **Simulador:** solo si algo retrasa la pausa (la caída). Si es así, 10 partidas por dificultad antes y después, y dame las victorias.
- **Documentación:**
  - `creditos.md`: los sprites del lote 8 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md`.
  - El manual y el panel de reglas si hablan de algo que cambia (la "R" de la ulti, el "CLICK").
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - las vistas previas (`vista_lote8.png`, `gifs/`, `efectos_en_juego.gif`, `captura_en_juego.png`)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - un `feat` por grupo: personaje (caída, derrota, golpe, escudo y evolución), partículas, élite (muerte y mecha), invocación, barras, Ping y fragmentos, y mira
  - `docs`
- No publiques ninguna release.
