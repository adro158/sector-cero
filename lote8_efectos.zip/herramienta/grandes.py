"""Efectos del lote 8, puntos 5 a 8: la muerte del élite (dorada), la mecha del
afijo Explosivo (gris), la evolución de una herramienta (gris) y el círculo de
invocación de Kernel Panic (morado)."""
import math

import numpy as np
from PIL import Image

from comun import lienzo, poner, poner_si_mas_claro, glifo, ruido_bloques, tira, guardar
from pixel import bayer

ORO = {'blanco': (255, 250, 215), 'claro': (255, 238, 150), 'medio': (250, 206, 80),
       'oscuro': (222, 164, 40), 'fondo': (170, 112, 20), 'negro': (110, 70, 10)}


def mezclar(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


# ------------------------------------------------------------------ muerte del élite
def muerte_elite(ruta_rootkit):
    """8 x 96x96, dorada: el rootkit se agrieta, brilla, se parte en trozos que
    salen despedidos y se deshacen en datos (píxeles y unos y ceros)."""
    lado, c = 96, 47.5
    rk = np.array(Image.open(ruta_rootkit).convert('RGBA')).astype(np.float64)
    cuerpo = np.zeros((lado, lado, 4))
    cuerpo[24:72, 24:72] = rk
    opaco = cuerpo[..., 3] > 200
    yy, xx = np.mgrid[0:lado, 0:lado]
    ang = np.arctan2(yy - c, xx - c)
    r = np.hypot(xx - c, yy - c)
    # siete trozos en abanico (según el ángulo), con los bordes quebrados
    torcido = ang + 0.25 * np.sin(r * 0.55)
    trozo = ((torcido + math.pi) / math.tau * 7).astype(int) % 7
    dir_trozo = [(math.cos((k + 0.5) / 7 * math.tau - math.pi), math.sin((k + 0.5) / 7 * math.tau - math.pi)) for k in range(7)]
    # las grietas: los bordes entre trozos
    grieta = opaco & ((trozo != np.roll(trozo, 1, 1)) | (trozo != np.roll(trozo, 1, 0))) & (r > 3)
    ruido = ruido_bloques(lado, lado, 2, 3)
    b = bayer(lado, lado)
    rng = np.random.default_rng(9)
    datos = [(rng.uniform(0, math.tau), rng.uniform(6, 18), '01'[rng.integers(0, 2)], rng.uniform(0.6, 1.2)) for _ in range(12)]
    fotos = []
    for f in range(8):
        a = lienzo(lado)
        separacion = (0, 0, 2, 5, 9, 14, 20, 27)[f]
        deshecho = (0, 0, 0, 0.15, 0.35, 0.55, 0.78, 1.01)[f]
        calor = (0.0, 0.35, 0.55, 0.45, 0.3, 0.2, 0.1, 0.0)[f]
        # resplandor de dentro al partirse
        if 1 <= f <= 2:
            radio = (0, 10, 16)[f]
            glow = (r < radio) & (b < (0, 0.5, 0.3)[f])
            a[glow] = (*ORO['claro'], 255)
        for k in range(7):
            dx, dy = dir_trozo[k]
            ox, oy = int(round(dx * separacion)), int(round(dy * separacion - (f >= 5) * (f - 4) * 2))
            sel = opaco & (trozo == k) & (ruido > deshecho)
            ys, xs = np.nonzero(sel)
            for y, x in zip(ys, xs):
                col = cuerpo[y, x, :3]
                if grieta[y, x] and f >= 0:
                    col = ORO['blanco'] if f <= 2 else ORO['claro']
                    if f == 0 and r[y, x] > 14:
                        col = cuerpo[y, x, :3]
                elif calor:
                    col = mezclar(col, ORO['claro'], calor)
                poner(a, x + ox, y + oy, col)
            # lo que se ha deshecho de este trozo: píxeles de oro que salen
            if f >= 3:
                sueltos = opaco & (trozo == k) & (ruido <= deshecho) & (ruido > deshecho - 0.3)
                ys, xs = np.nonzero(sueltos)
                for y, x in zip(ys[::3], xs[::3]):
                    edad = deshecho - ruido[y, x]
                    if b[y, x] < 1.0 - edad * 2.5:
                        poner(a, x + ox + dx * edad * 30, y + oy + dy * edad * 30 - edad * 20, ORO['medio'])
        # unos y ceros que salen y suben
        if f >= 3:
            t = (f - 3) / 4
            for angulo, dist, ch, vel in datos:
                d = dist + t * 30 * vel
                x = c + math.cos(angulo) * d - 1
                y = c + math.sin(angulo) * d - 2 - t * 14
                if t < 0.95 and b[int(y) % lado, int(x) % lado] < 1.1 - t:
                    glifo(a, x, y, ch, ORO['claro'] if t < 0.5 else ORO['medio'])
        # destello al romperse
        if f == 2:
            for d in range(1, 30):
                v = mezclar(ORO['blanco'], ORO['medio'], d / 30)
                for s in (-1, 1):
                    if d < 26 or b[int(c), int(c + s * d) % lado] < 0.5:
                        poner(a, c + s * d, c, v)
                        poner(a, c, c + s * d, v)
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ mecha del Explosivo
def mecha_explosivo():
    """4 x 64x64 en bucle, en grises: una mecha en anillo alrededor del rootkit
    (por fuera de sus puntas, a 27 px) con cuatro chispas que la recorren y
    sueltan brasas. Detrás del élite; se tiñe de naranja."""
    lado, c = 64, 31.5
    yy, xx = np.mgrid[0:lado, 0:lado]
    r = np.hypot(xx - c, yy - c)
    ang = (np.arctan2(yy - c, xx - c) + math.tau) % math.tau
    b = bayer(lado, lado)
    radio = 27.0
    fotos = []
    for f in range(4):
        a = lienzo(lado)
        # la mecha: un cordón trenzado (trazos de 2 px y huecos)
        cordon = (np.abs(r - radio) <= 1.1)
        trenza = ((ang * radio).astype(int) % 4) < 3
        a[cordon & trenza] = (120, 120, 120, 255)
        a[cordon & ~trenza] = (70, 70, 70, 255)
        for k in range(4):
            base = k * math.tau / 4 + f * math.tau / 16
            # detrás de la chispa, la mecha ya quemada brilla un poco
            for d in range(1, 10):
                aa = base - d * 0.045
                v = int(230 - 14 * d)
                poner_si_mas_claro(a, c + math.cos(aa) * radio, c + math.sin(aa) * radio, v)
            # la chispa: núcleo blanco y una estrella pequeña
            px, py = c + math.cos(base) * radio, c + math.sin(base) * radio
            for ddx, ddy, v in ((0, 0, 255), (1, 0, 255), (0, 1, 255), (1, 1, 255), (-1, 0, 215), (2, 0, 215), (0, -1, 215), (1, -1, 215),
                                (0, 2, 215), (1, 2, 215), (-2, 0, 150), (3, 0, 150), (0, -2, 150), (0, 3, 150),
                                (-1, -1, 170), (2, -1, 170), (-1, 2, 170), (2, 2, 170)):
                poner_si_mas_claro(a, px + ddx - 0.5, py + ddy - 0.5, v)
            # llamita hacia fuera (hacia arriba en pantalla, un poco)
            nx, ny = math.cos(base), math.sin(base)
            for d in range(2, 6):
                fx, fy = px + nx * d - 0.5, py + ny * d - 0.5 - d * 0.6
                poner_si_mas_claro(a, fx, fy, 235 - d * 18)
                if d < 4:
                    poner_si_mas_claro(a, fx + ny, fy - nx, 190 - d * 15)
            # brasas que saltan hacia fuera (cada fotograma, otras)
            rng = np.random.default_rng(100 + k * 4 + f)
            for _ in range(4):
                sal = rng.uniform(1, 4.5)
                aa = base + rng.uniform(-0.35, 0.05)
                ex, ey = c + math.cos(aa) * (radio + sal), c + math.sin(aa) * (radio + sal) - sal * 0.5
                poner_si_mas_claro(a, ex, ey, int(rng.uniform(170, 240)))
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ evolución
def evolucion():
    """10 x 128x128, en grises y tramado (como el de subir de nivel): un anillo
    de luz que sube desde los pies, una columna de luz, el destello del arma y
    unos y ceros que suben. Centrado en el sprite; se tiñe del color del
    personaje."""
    lado, cx, cy = 128, 63.5, 63.5
    pies = cy + 34
    yy, xx = np.mgrid[0:lado, 0:lado]
    b = bayer(lado, lado)
    rng = np.random.default_rng(31)
    glifos = [(rng.uniform(-30, 30), rng.uniform(0, 1), '01>#'[rng.integers(0, 4)], rng.uniform(0.8, 1.3)) for _ in range(16)]
    fotos = []
    for f in range(10):
        a = lienzo(lado)
        t = f / 9
        # anillo en el suelo que se abre (0-3)
        if f <= 4:
            rx = 12 + f * 9
            e = np.hypot((xx - cx) / rx, (yy - pies) / (rx * 0.28))
            anillo = (np.abs(e - 1) < 0.09) & (b < (1.0, 0.9, 0.7, 0.5, 0.25)[f])
            a[anillo] = (220, 220, 220, 255)
        # anillo de luz que sube (1-8) con su estela de columna tramada
        if 1 <= f <= 8:
            subida = (f - 1) / 7
            ay = pies - subida * 82
            rx = 28 - 6 * subida
            e = np.hypot((xx - cx) / rx, (yy - ay) / 6.5)
            delante = (np.abs(e - 1) < 0.16) & (yy >= ay)
            detras = (np.abs(e - 1) < 0.16) & (yy < ay)
            a[detras & (b < 0.55)] = (200, 200, 200, 255)
            a[delante] = (255, 255, 255, 255)
            columna = (np.abs(xx - cx) < rx - 2) & (yy > ay) & (yy < pies) & (b < 0.10 * (1 - (yy - ay) / 90))
            a[columna & (a[..., 3] == 0)] = (190, 190, 190, 255)
        # columna de luz fina en el centro (2-7)
        if 2 <= f <= 7:
            ancho = (0, 0, 2, 4, 6, 6, 4, 2)[f]
            col = (np.abs(xx - cx) <= ancho / 2) & (yy < pies) & (yy > cy - 60)
            dens = 1 - np.abs(yy - cy) / 70
            a[col & (b < dens * (0.5 if ancho > 4 else 0.8))] = (235, 235, 235, 255)
        # destello del arma (4-6), a la altura del pecho
        if 4 <= f <= 6:
            largo = (0, 0, 0, 0, 16, 24, 12)[f]
            ex, ey = cx, cy - 4
            for d in range(0, largo + 1):
                v = int(255 - 110 * d / max(largo, 1))
                for s in (-1, 1):
                    poner_si_mas_claro(a, ex + s * d, ey, v)
                    poner_si_mas_claro(a, ex, ey + s * d, v)
                    if d < largo * 0.55:
                        poner_si_mas_claro(a, ex + s * d * 0.7, ey + s * d * 0.7, v - 30)
                        poner_si_mas_claro(a, ex + s * d * 0.7, ey - s * d * 0.7, v - 30)
            nucleo = (np.hypot(xx - ex, yy - ey) <= (0, 0, 0, 0, 3, 4.5, 2.5)[f])
            a[nucleo] = (255, 255, 255, 255)
        # unos y ceros que suben alrededor (2-9)
        if f >= 2:
            for dx, fase, ch, vel in glifos:
                avance = (f - 2) / 7 * vel + fase * 0.3
                if avance > 1.05:
                    continue
                x = cx + dx - 1
                y = pies - 6 - avance * 85
                if b[int(y) % lado, int(x) % lado] < 1.0 - avance * 0.6:
                    glifo(a, x, y, ch, (225, 225, 225) if avance < 0.6 else (170, 170, 170))
        # chispas finales arriba (8-9)
        if f >= 8:
            for k in range(6):
                ang = k * math.tau / 6 + f
                px, py = cx + math.cos(ang) * (18 + (f - 8) * 6), cy - 50 + math.sin(ang) * 5
                poner_si_mas_claro(a, px, py, 255 if f == 8 else 170)
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ invocación de Kernel Panic
MORADO = {'oscuro': (92, 30, 140), 'medio': (191, 77, 255), 'claro': (226, 168, 255), 'blanco': (246, 228, 255)}
RUNAS = ['0', '1', '>', '<', '#', '/', '_']


def invocacion():
    """8 x 320x320, morado #BF4DFF, debajo del jefe: un círculo de runas y datos
    que se dibuja solo hasta cerrarse a 140 px de radio, con un anillo de
    puntos de fuera que se cierra hacia él y un destello al final (cuando sale
    la horda)."""
    lado, c = 320, 159.5
    yy, xx = np.mgrid[0:lado, 0:lado]
    r = np.hypot(xx - c, yy - c)
    ang = (np.arctan2(yy - c, xx - c) + math.pi / 2) % math.tau  # empieza arriba
    b = bayer(lado, lado)
    rng = np.random.default_rng(77)
    runas = [(k * math.tau / 24 + 0.13, RUNAS[rng.integers(0, len(RUNAS))]) for k in range(24)]
    # los vértices de la estrella de dentro (heptagrama)
    vert = [(c + math.cos(k * math.tau / 7 - math.pi / 2) * 118, c + math.sin(k * math.tau / 7 - math.pi / 2) * 118) for k in range(7)]
    fotos = []
    for f in range(8):
        a = lienzo(lado)
        hecho = min((f + 1) / 7, 1.0) * math.tau
        # el anillo principal, a 140 px, que se va cerrando
        principal = (np.abs(r - 140) <= 1.6) & (ang <= hecho)
        a[principal] = (*MORADO['medio'], 255)
        a[(np.abs(r - 140) <= 0.6) & (ang <= hecho)] = (*MORADO['claro'], 255)
        # la punta que dibuja el anillo: brilla
        if f < 6:
            punta = (np.abs(r - 140) <= 3) & (np.abs(ang - hecho) < 0.05)
            a[punta] = (*MORADO['blanco'], 255)
        # marcas cada 10 grados por dentro
        marcas = (r > 131) & (r < 136) & ((ang * 36 / math.tau) % 1 < 0.08) & (ang <= hecho)
        a[marcas] = (*MORADO['medio'], 255)
        # segundo anillo, fino y tramado, a 128
        a[(np.abs(r - 128) <= 0.7) & (ang <= hecho) & (b < 0.7)] = (*MORADO['oscuro'], 255)
        # runas entre los dos anillos (las que ya ha pasado la punta)
        for angulo, ch in runas:
            if (angulo + math.pi / 2) % math.tau > hecho - 0.01 and f < 7:
                continue
            x = c + math.cos(angulo) * 146 - 3
            y = c + math.sin(angulo) * 146 - 5
            col = MORADO['claro'] if f >= 6 else MORADO['medio']
            # cada runa a x2 (6x10)
            g = lienzo(3, 5)
            glifo(g, 0, 0, ch, col)
            for gy in range(5):
                for gx in range(3):
                    if g[gy, gx, 3]:
                        for sy in range(2):
                            for sx in range(2):
                                poner(a, x + gx * 2 + sx, y + gy * 2 + sy, col)
        # la estrella de dentro, desde el fotograma 3
        if f >= 3:
            dens = (0, 0, 0, 0.35, 0.6, 0.85, 1.0, 1.0)[f]
            for k in range(7):
                (x0, y0), (x1, y1) = vert[k], vert[(k + 3) % 7]
                n = int(math.hypot(x1 - x0, y1 - y0))
                for i in range(n):
                    if i / n > dens:
                        break
                    x, y = x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n
                    if b[int(y), int(x)] < 0.75:
                        poner(a, x, y, MORADO['medio'])
        # anillo de puntos de fuera que se cierra hacia el principal
        radio_fuera = 158 - f * 2.5
        puntos = (np.abs(r - radio_fuera) <= 0.8) & ((ang * 60 / math.tau + f * 0.5) % 1 < 0.35)
        a[puntos & (a[..., 3] == 0)] = (*MORADO['oscuro'], 255) if f < 6 else (*MORADO['medio'], 255)
        # resplandor tramado por dentro al final
        if f >= 6:
            glow = (r < 140) & (r > 60) & (b < (0, 0, 0, 0, 0, 0, 0.04, 0.07)[f] * (r - 60) / 80)
            a[glow & (a[..., 3] == 0)] = (*MORADO['medio'], 255)
        if f == 7:
            a[principal] = (*MORADO['blanco'], 255)
            borde = (np.abs(r - 140) <= 3.2) & ~principal & (b < 0.5)
            a[borde] = (*MORADO['claro'], 255)
        fotos.append(a)
    return tira(fotos)


def generar(ruta_rootkit, carpeta):
    guardar(muerte_elite(ruta_rootkit), f'{carpeta}/muerte_elite.png')
    guardar(mecha_explosivo(), f'{carpeta}/afijo_explosivo.png')
    guardar(evolucion(), f'{carpeta}/evolucion_herramienta.png')
    guardar(invocacion(), f'{carpeta}/invocacion_kernel_panic.png')
