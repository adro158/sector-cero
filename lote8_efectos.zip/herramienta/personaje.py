"""Efectos del personaje (lote 8, puntos 1 a 4): caída, derrota, golpe recibido,
escudo de protección y la partícula. Todo en grises: el juego los tiñe."""
import math

import numpy as np
from PIL import Image

from comun import lienzo, poner, poner_si_mas_claro, ruido_bloques, tira, guardar
from pixel import bayer

HOJAS = ['antivirus_8_direcciones.png', 'ciberespadachin_8_direcciones.png', 'segador_ciber_8_direcciones.png']


# ------------------------------------------------------------------ silueta
def silueta(carpeta_hojas, lado=96):
    """Lo que tienen en común los tres personajes de frente (la capucha y la
    capa, sin las armas), centrado en el sprite: es genérica y sirve para
    cualquiera, porque el efecto se tiñe con su color."""
    m = np.ones((lado, lado), bool)
    ox, oy = (lado - 64) // 2, (lado - 72) // 2
    for hoja in HOJAS:
        im = np.zeros((lado, lado), bool)
        im[oy:oy + 72, ox:ox + 64] = np.array(Image.open(f'{carpeta_hojas}/{hoja}').convert('RGBA'))[0:72, 0:64, 3] > 0
        m &= im
    # cierra los huecos sueltos de un píxel
    lleno = m | ((np.roll(m, 1, 0) & np.roll(m, -1, 0)) | (np.roll(m, 1, 1) & np.roll(m, -1, 1)))
    return lleno


def cuerpo_gris(m):
    """Relleno de la silueta: claro, con el borde más claro y líneas de barrido."""
    h, w = m.shape
    yy, xx = np.mgrid[0:h, 0:w]
    v = np.where(m, 205.0, 0.0)
    borde = m & ~(np.roll(m, 1, 0) & np.roll(m, -1, 0) & np.roll(m, 1, 1) & np.roll(m, -1, 1))
    v[borde] = 255
    v[m & (yy % 3 == 2) & ~borde] = 165
    return v


def deshacer(m, progreso, semilla, rotura=(), lineas=0, particulas=True, max_edad=0.42):
    """Un fotograma del cuerpo deshaciéndose. Cada bloque de 2x2 de la silueta se
    suelta cuando el progreso pasa su umbral (antes los de arriba); suelto, sube,
    se abre a los lados y se apaga tramado."""
    h, w = m.shape
    a = lienzo(w, h)
    v = cuerpo_gris(m)
    ys, xs = np.nonzero(m)
    arriba, abajo = ys.min(), ys.max()
    yy, xx = np.mgrid[0:h, 0:w]
    umbral = 0.35 * ruido_bloques(h, w, 2, semilla) + 0.65 * (yy - arriba) / (abajo - arriba)
    lado = ruido_bloques(h, w, 2, semilla + 1) - 0.5
    queda = m & (umbral > progreso)
    a[queda] = np.stack([v, v, v, np.full_like(v, 255)], -1)[queda]
    # el frente de lo que se deshace, más claro: se ve que va bajando
    frente = queda & (umbral < progreso + 0.06)
    a[frente] = (255, 255, 255, 255)
    # franjas de glitch del cuerpo que queda: (fila, alto, desplazamiento)
    for y0, alto, dx in rotura:
        a[y0:y0 + alto] = np.roll(a[y0:y0 + alto], dx, axis=1)
    if particulas:
        b = bayer(h, w)
        for by in range(0, h, 2):
            for bx in range(0, w, 2):
                if not m[by, bx] or umbral[by, bx] > progreso:
                    continue
                edad = progreso - umbral[by, bx]
                if edad >= max_edad:
                    continue
                f = edad / max_edad
                x = bx + lado[by, bx] * 70 * edad
                y = by - 95 * edad
                brillo = int(255 - 90 * f)
                tam = 2 if f < 0.5 else 1
                if b[int(by) % h, int(bx) % w] > 1.0 - f * 0.9:
                    continue
                for dy in range(tam):
                    for dx in range(tam):
                        poner_si_mas_claro(a, x + dx, y + dy, brillo)
    # líneas de glitch sueltas alrededor del cuerpo
    rng = np.random.default_rng(semilla + 7)
    for _ in range(lineas):
        y = rng.integers(arriba, abajo)
        x0 = rng.integers(w // 2 - 30, w // 2 + 10)
        largo = rng.integers(6, 20)
        for x in range(x0, x0 + largo):
            if rng.random() < 0.85:
                poner_si_mas_claro(a, x, y, 255)
    return a


def caida(carpeta_hojas):
    """8 x 96x96: la silueta destella, se rompe en franjas y se deshace en
    píxeles que suben, con líneas de glitch."""
    m = silueta(carpeta_hojas)
    fotos = [
        deshacer(m, -0.10, 11, rotura=[(40, 3, 3)], lineas=1),
        deshacer(m, 0.04, 11, rotura=[(24, 4, -5), (44, 2, 6), (62, 3, -3)], lineas=3),
        deshacer(m, 0.20, 11, rotura=[(30, 5, 4), (56, 3, -6)], lineas=4),
        deshacer(m, 0.38, 11, rotura=[(50, 3, -4)], lineas=4),
        deshacer(m, 0.56, 11, rotura=[(66, 2, 5)], lineas=3),
        deshacer(m, 0.74, 11, lineas=2),
        deshacer(m, 0.92, 11, lineas=1),
        deshacer(m, 1.10, 11),
    ]
    return tira(fotos)


def linea_crt(lado, ancho, alto, brillo_halo=True):
    """La imagen que se apaga como una tele vieja: una raya horizontal."""
    a = lienzo(lado)
    cy = lado // 2
    b = bayer(lado, lado)
    for x in range(lado // 2 - ancho // 2, lado // 2 + ancho // 2 + 1):
        for dy in range(-(alto // 2), alto - alto // 2):
            poner(a, x, cy + dy, (255, 255, 255))
        if brillo_halo:
            for dy in (-alto // 2 - 1, alto - alto // 2):
                if b[cy + dy, x] < 0.5:
                    poner_si_mas_claro(a, x, cy + dy, 170)
    return a


def derrota(carpeta_hojas):
    """12 x 96x96, para la derrota final: como la caída pero más lenta, y lo que
    queda se apaga como una pantalla (raya, punto y nada)."""
    m = silueta(carpeta_hojas)
    fotos = [
        deshacer(m, -0.10, 23, rotura=[(36, 4, 4)], lineas=2),
        deshacer(m, -0.02, 23, rotura=[(20, 3, -6), (40, 5, 7), (60, 2, -4)], lineas=4),
        deshacer(m, 0.10, 23, rotura=[(28, 3, 5), (52, 4, -7)], lineas=5),
        deshacer(m, 0.22, 23, rotura=[(44, 3, -5)], lineas=4),
        deshacer(m, 0.34, 23, rotura=[(58, 2, 4)], lineas=4),
        deshacer(m, 0.46, 23, lineas=3),
        deshacer(m, 0.58, 23, lineas=3),
        deshacer(m, 0.70, 23, lineas=2),
    ]
    # lo que queda se aplasta en una raya que se encoge hasta un punto
    for ancho, alto, progreso in ((58, 3, 0.80), (30, 2, 0.90), (0, 0, 1.0), (0, 0, 1.1)):
        # sin el cuerpo: solo las partículas que siguen subiendo
        f = deshacer(m, progreso, 23)
        cuerpo = deshacer(m, progreso, 23, particulas=False)
        f[cuerpo[..., 3] > 0] = 0
        if ancho:
            raya = linea_crt(96, ancho, alto)
        else:
            raya = lienzo(96)
            c = 48
            if progreso <= 1.0:
                for x, y, v in ((c, c, 255), (c - 1, c, 255), (c, c - 1, 255), (c - 1, c - 1, 255),
                                (c - 2, c, 180), (c + 1, c, 180), (c, c - 2, 180), (c, c + 1, 180),
                                (c - 4, c, 120), (c + 3, c, 120)):
                    poner(raya, x, y, (v, v, v))
            else:
                poner(raya, c, c, (200, 200, 200), 160)
        sel = raya[..., 3] > 0
        f[sel] = raya[sel]
        fotos.append(f)
    return tira(fotos)


# ------------------------------------------------------------------ golpe
def quebrada(rng, cx, cy, ang, desde, hasta):
    """Puntos de una grieta en tramos rectos de 4 a 7 px que se tuercen un poco,
    desde el radio desde hasta el radio hasta."""
    vertices = [(cx + math.cos(ang) * desde, cy + math.sin(ang) * desde)]
    r = desde
    while r < hasta:
        paso = rng.uniform(4, 7)
        r = min(r + paso, hasta)
        a = ang + rng.uniform(-0.45, 0.45)
        vertices.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    pts = []
    for (x0, y0), (x1, y1) in zip(vertices, vertices[1:]):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n):
            t = i / n
            pts.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, math.hypot(x0 + (x1 - x0) * t - cx, y0 + (y1 - y0) * t - cy)))
    return pts


def golpe():
    """4 x 64x64: un destello de impacto que se abre en grietas y bloques de
    glitch. Encima del personaje, centrado en el sprite; se tiñe de rojo."""
    lado, c = 64, 31.5
    rng = np.random.default_rng(5)
    angulos = [i * math.tau / 6 + rng.uniform(-0.25, 0.25) + 0.35 for i in range(6)]
    grietas = [quebrada(np.random.default_rng(40 + i), c, c, ang, 5, 30) for i, ang in enumerate(angulos)]
    bloques = [(14, 18, 7, 2, 4), (40, 22, 6, 2, -5), (20, 42, 8, 2, 5), (44, 40, 6, 3, -4), (28, 12, 5, 2, 3)]
    yy, xx = np.mgrid[0:lado, 0:lado]
    r = np.hypot(xx - c, yy - c)
    ang = np.arctan2(yy - c, xx - c)
    b = bayer(lado, lado)
    fotos = []
    for f in range(4):
        a = lienzo(lado)
        # anillo que se abre, roto en seis arcos
        if f >= 1:
            radio, grosor, dens = ((0, 0, 0), (11, 1.2, 1.0), (17, 1.0, 0.55), (21, 0.8, 0.25))[f]
            anillo = (np.abs(r - radio) <= grosor) & (np.sin(ang * 6 + 0.6) > -0.45) & (b < dens)
            a[anillo] = (190, 190, 190, 255)
        # grietas: del centro hacia fuera, cada vez más largas y más apagadas
        if f >= 1:
            desde, hasta, dens, v = ((0, 0, 0, 0), (5, 17, 1.0, 255), (9, 26, 0.85, 225), (19, 30, 0.45, 170))[f]
            for pts in grietas:
                for x, y, rr in pts:
                    if desde <= rr <= hasta and b[int(y) % lado, int(x) % lado] < dens:
                        poner_si_mas_claro(a, x, y, v)
        # núcleo y estrella de cuatro puntas
        if f <= 1:
            nucleo, largo, grueso = ((4.5, 19, 8), (2.6, 23, 0))[f]
            a[r <= nucleo] = (255, 255, 255, 255)
            if f == 0:
                a[(r > nucleo) & (r <= nucleo + 1.2)] = (215, 215, 215, 255)
            for d in range(1, largo + 1):
                v = int(255 - 120 * d / largo)
                anchos = (-1, 0, 1) if d <= grueso else (0,)
                for s in (-1, 1):
                    for k in anchos:
                        vk = v if k == 0 else v - 50
                        if f == 0 or b[int(c + k) % lado, int(c + s * d) % lado] < 0.7:
                            poner_si_mas_claro(a, c + s * d, c + k + 0.5, vk)
                            poner_si_mas_claro(a, c + k + 0.5, c + s * d, vk)
            for d in range(1, (10, 6)[f] + 1):
                for sx in (-1, 1):
                    for sy in (-1, 1):
                        poner_si_mas_claro(a, c + sx * d + 0.5, c + sy * d + 0.5, int(210 - 90 * d / 10))
        # bloques de glitch desplazados
        if f >= 1:
            v = (0, 235, 200, 140)[f]
            for i, (x, y, w, h, dx) in enumerate(bloques[: (0, 4, 5, 3)[f]]):
                dx = dx * (1 if f == 1 else -1)
                for y0 in range(h):
                    for x0 in range(w):
                        if f < 3 or (x0 + y0) % 2 == 0:
                            poner_si_mas_claro(a, x + x0 + dx, y + y0, v)
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ escudo
def escudo():
    """4 x 80x80 en bucle: una burbuja de hexágonos tramada (se ve el personaje
    a través), con el borde claro, un barrido de luz y chispas que giran."""
    lado, cx, cy = 80, 39.5, 39.5
    rx, ry = 31.5, 37.5
    yy, xx = np.mgrid[0:lado, 0:lado].astype(np.float64)
    e = np.hypot((xx - cx) / rx, (yy - cy) / ry)
    dentro = e <= 1.0
    # rejilla de hexágonos (coordenadas cúbicas)
    s = 6.0
    q = (math.sqrt(3) / 3 * (xx - cx) - 1 / 3 * (yy - cy)) / s
    r = (2 / 3 * (yy - cy)) / s
    x3, z3 = q, r
    y3 = -x3 - z3
    rx3, ry3, rz3 = np.round(x3), np.round(y3), np.round(z3)
    dx, dy, dz = np.abs(rx3 - x3), np.abs(ry3 - y3), np.abs(rz3 - z3)
    dist = np.maximum(np.maximum(dx, dy), dz)
    arista = dentro & (dist > 0.43) & (e < 0.93)
    b = bayer(lado, lado)
    # borde de 2 px
    borde_fuera = dentro & (e > 1.0 - 1.0 / ry * 1.6)
    borde_dentro = dentro & ~borde_fuera & (e > 1.0 - 2.6 / ry)
    fotos = []
    for f in range(4):
        a = lienzo(lado)
        # el relleno: muy tramado, más denso hacia el borde (efecto de burbuja)
        relleno = dentro & (e > 0.75) & (b < 0.30 * (e - 0.75) / 0.25)
        a[relleno] = (150, 150, 150, 255)
        # las aristas de los hexágonos, tramadas: se ve el personaje a través
        a[arista & (b < 0.22 + 0.25 * e ** 2)] = (185, 185, 185, 255)
        # barrido de luz en diagonal: bandas que avanzan 12 px por fotograma
        diag = (xx + yy * 0.8 + f * 12) % 48
        banda = dentro & (diag < 5)
        a[banda & arista & (b < 0.8)] = (255, 255, 255, 255)
        a[banda & ~arista & (b < 0.12)] = (220, 220, 220, 255)
        # borde
        a[borde_dentro & (b < 0.7)] = (200, 200, 200, 255)
        a[borde_fuera] = (245, 245, 245, 255)
        # cuatro chispas que giran por el borde
        for k in range(4):
            ang = k * math.tau / 4 + f * math.tau / 16 + 0.4
            px, py = cx + math.cos(ang) * rx, cy + math.sin(ang) * ry
            for ddx, ddy, v in ((0, 0, 255), (1, 0, 220), (-1, 0, 220), (0, 1, 220), (0, -1, 220), (2, 0, 150), (-2, 0, 150), (0, 2, 150), (0, -2, 150)):
                poner(a, px + ddx, py + ddy, (v, v, v))
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ partícula
def particula():
    """8x8: una chispa con el centro blanco; la comparten todas las partículas."""
    filas = [
        "...ab...",
        "...cc...",
        "..dfgd..",
        "acfhhfca",
        "acfhhfca",
        "..dfgd..",
        "...cc...",
        "...ab...",
    ]
    valores = {'a': (140, 200), 'b': (140, 200), 'c': (190, 255), 'd': (150, 200), 'f': (230, 255), 'g': (230, 255), 'h': (255, 255)}
    a = lienzo(8)
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch != '.':
                v, al = valores[ch]
                a[y, x] = (v, v, v, al)
    return a


def generar(carpeta_hojas, carpeta):
    guardar(caida(carpeta_hojas), f'{carpeta}/caida_personaje.png')
    guardar(derrota(carpeta_hojas), f'{carpeta}/derrota_personaje.png')
    guardar(golpe(), f'{carpeta}/golpe_recibido.png')
    guardar(escudo(), f'{carpeta}/escudo_proteccion.png')
    guardar(particula(), f'{carpeta}/particula.png')
