"""Genera todo el lote 8 (efectos de la partida) de SECTOR CERO.

Uso:  python3 generar_efectos_partida.py <carpeta del repo> <carpeta de salida>

Lee del repo las hojas de los personajes (para la silueta de la caída), el
rootkit, el proyectil del Ping y el fragmento de datos de ahora, y deja los PNG
en la carpeta de salida con la misma ruta que en el repo:
  projecte/medios/sprites/efectos/       caída, derrota, golpe, escudo, partícula,
                                         muerte del élite, mecha del Explosivo,
                                         evolución, invocación, barras, ulti lista,
                                         fragmento, recogida y mira del rayo
  projecte/medios/sprites/herramientas/  los dos proyectiles del Ping animados
Necesita numpy y Pillow, y en la misma carpeta pixel.py, comun.py,
personaje.py, grandes.py y pequenos.py.
"""
import os
import sys

import grandes
import pequenos
import personaje


def main(repo, salida):
    efectos = os.path.join(salida, 'projecte/medios/sprites/efectos')
    herramientas = os.path.join(salida, 'projecte/medios/sprites/herramientas')
    os.makedirs(efectos, exist_ok=True)
    os.makedirs(herramientas, exist_ok=True)
    p = os.path.join(repo, 'projecte')
    personaje.generar(os.path.join(p, 'escenas/jugabilidad/jugador'), efectos)
    grandes.generar(os.path.join(p, 'recursos/enemigos/sprites/rootkit.png'), efectos)
    pequenos.generar(efectos, herramientas, os.path.join(p, 'medios/sprites/proyectil_ping.png'),
                     os.path.join(p, 'medios/sprites/fragmento_datos.png'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
