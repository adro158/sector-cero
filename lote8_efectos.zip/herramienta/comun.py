"""Cosas compartidas por los efectos del lote 8: lienzos RGBA de numpy, tiras,
tramado de Bayer, glifos de datos de 3x5 y ruido por bloques con semilla fija
(así el script saca siempre los mismos PNG)."""
import numpy as np
from PIL import Image

from pixel import bayer

# Glifos de 3x5 para los "datos" que se ven en los efectos.
GLIFOS = {
    '0': ["###", "#.#", "#.#", "#.#", "###"],
    '1': [".#.", "##.", ".#.", ".#.", "###"],
    '>': ["#..", ".#.", "..#", ".#.", "#.."],
    '<': ["..#", ".#.", "#..", ".#.", "..#"],
    '#': ["#.#", "###", "#.#", "###", "#.#"],
    '/': ["..#", "..#", ".#.", "#..", "#.."],
    '_': ["...", "...", "...", "...", "###"],
}


def lienzo(w, h=None):
    return np.zeros((h or w, w, 4), np.float64)


def gris(v):
    return (v, v, v)


def poner(a, x, y, color, alfa=255):
    x, y = int(round(x)), int(round(y))
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        a[y, x] = (*color[:3], alfa)


def poner_si_mas_claro(a, x, y, v, alfa=255):
    """Pone un gris solo si es más claro que lo que ya hay (para que los brillos
    se sumen sin oscurecer)."""
    x, y = int(round(x)), int(round(y))
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        if a[y, x, 3] == 0 or a[y, x, 0] < v:
            a[y, x] = (v, v, v, alfa)


def glifo(a, x, y, ch, color, alfa=255):
    for fy, fila in enumerate(GLIFOS[ch]):
        for fx, c in enumerate(fila):
            if c == '#':
                poner(a, x + fx, y + fy, color, alfa)


def tira(fotos):
    return np.concatenate(fotos, axis=1)


def guardar(a, ruta):
    Image.fromarray(np.clip(np.round(a), 0, 255).astype(np.uint8), 'RGBA').save(ruta)


def ruido_bloques(h, w, bloque, semilla):
    """Un valor al azar de 0 a 1 por cada bloque de bloque x bloque píxeles."""
    rng = np.random.default_rng(semilla)
    peq = rng.random((h // bloque + 1, w // bloque + 1))
    return np.kron(peq, np.ones((bloque, bloque)))[:h, :w]


def tramar(mascara, densidad):
    """Deja solo una fracción de los píxeles de la máscara, con tramado de Bayer."""
    h, w = mascara.shape
    return mascara & (bayer(h, w) < densidad)


def contorno_oscuro(a, color=(10, 6, 12), solo_opacos=True):
    """Contorno de 1 px alrededor de lo opaco."""
    op = a[..., 3] > (200 if solo_opacos else 0)
    d = op.copy()
    d[1:, :] |= op[:-1, :]
    d[:-1, :] |= op[1:, :]
    d[:, 1:] |= op[:, :-1]
    d[:, :-1] |= op[:, 1:]
    borde = d & (a[..., 3] == 0)
    a[borde] = (*color, 255)
    return a
