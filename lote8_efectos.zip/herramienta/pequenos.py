"""Efectos pequeños del lote 8, puntos 9 a 12: barras de vida, el icono de ulti
lista, los proyectiles del Ping animados, el fragmento de datos con brillo, el
destello de recogida y la mira de la ulti del Mago."""
import math

import numpy as np
from PIL import Image

from comun import lienzo, poner, poner_si_mas_claro, tira, guardar
from pixel import bayer


def desde_texto(filas, colores):
    h, w = len(filas), len(filas[0])
    a = lienzo(w, h)
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch != '.':
                c = colores[ch]
                a[y, x] = (*c[:3], c[3] if len(c) > 3 else 255)
    return a


# ------------------------------------------------------------------ barras
FUERA = (24, 24, 24, 235)     # contorno oscuro
MARCO = (215, 215, 215, 255)  # el marco, claro
BRILLO = (255, 255, 255, 255)
HUECO = (34, 34, 34, 215)     # el fondo de la barra vacía


def barra_enemigo_marco():
    """48x9 en grises. Se puede estirar en 3 trozos (5 px a cada lado; el centro
    es igual en todas las columnas). El hueco (44x5 en 2,2) lleva el fondo
    oscuro: primero el marco y luego el relleno encima."""
    w, h = 48, 9
    a = lienzo(w, h)
    a[:, :] = FUERA
    a[1:h - 1, 1:w - 1] = MARCO
    a[2:h - 2, 2:w - 2] = HUECO
    # esquinas cortadas
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    # remates de los extremos: un brillo arriba y un pin en medio de cada lado
    for x in (2, 3, 4):
        a[1, x] = BRILLO
    for x in (w - 5, w - 4, w - 3):
        a[h - 2, x] = (150, 150, 150, 255)
    a[4, 1] = BRILLO
    a[4, w - 2] = BRILLO
    return a


def relleno(w, h):
    """Relleno en grises, igual en todas las columnas (se puede recortar o
    estirar a lo ancho): brillo arriba y sombra abajo."""
    filas = {5: (255, 232, 206, 182, 140), 2: (255, 190)}[h]
    a = lienzo(w, h)
    for y, v in enumerate(filas):
        a[y, :] = (v, v, v, 255)
    return a


def barra_personaje_marco():
    """44x12 en grises: hueco de la vida (40x5 en 2,2) y de la ulti (40x2 en
    2,8), con el fondo oscuro. Primero el marco y luego los rellenos."""
    w, h = 44, 12
    a = lienzo(w, h)
    a[:, :] = FUERA
    a[1:h - 1, 1:w - 1] = MARCO
    a[2:7, 2:w - 2] = HUECO
    a[8:10, 2:w - 2] = HUECO
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    for x in (2, 3, 4):
        a[1, x] = BRILLO
    for x in (w - 5, w - 4, w - 3):
        a[h - 2, x] = (150, 150, 150, 255)
    # la línea entre los dos huecos, un poco más oscura en medio
    a[7, 6:w - 6] = (175, 175, 175, 255)
    return a


def ulti_lista():
    """2 x 8x8, dorado (el color de la ulti): un rayo que parpadea. Sustituye a
    la "R" escrita, que no vale para el mando."""
    colores = {'w': (255, 250, 210), 'l': (255, 236, 150), 'm': (255, 204, 51), 'd': (190, 130, 20), 'o': (90, 56, 8)}
    encendido = desde_texto([
        "...wlmo.",
        "..wlmo..",
        ".wlmo...",
        "wllllmd.",
        ".omlmo..",
        "..lmo...",
        ".lmo....",
        ".mo.....",
    ], colores)
    apagado = desde_texto([
        "...mdo..",
        "..mdo...",
        ".mdo....",
        "mmmmdo..",
        ".odmo...",
        "..mdo...",
        ".mdo....",
        ".do.....",
    ], {'m': (210, 150, 30), 'd': (150, 95, 15), 'o': (70, 44, 6)})
    return tira([encendido, apagado])


# ------------------------------------------------------------------ Ping
def ping(ruta_actual):
    """4 x 24x12, morado: el fotograma 0 es proyectil_ping.png tal cual; en los
    demás late el núcleo, el halo respira, un pulso recorre la estela y las
    chispas sueltas cambian de sitio."""
    base = np.array(Image.open(ruta_actual).convert('RGBA')).astype(np.float64)
    halo = (base[..., 3] == 90) & (base[..., 0] == 175)
    blanco = (base[..., :3] == 255).all(-1) & (base[..., 3] == 255)
    claro = (base[..., 0] == 230) & (base[..., 1] == 190) & (base[..., 3] == 255)
    sueltas_0 = [(12, 2), (6, 3), (3, 8), (10, 8)]
    sueltas = [None,
               [(9, 2, 150), (4, 3, 110), (12, 9, 170), (6, 8, 130)],
               [(11, 3, 160), (7, 2, 140), (2, 4, 90), (12, 8, 170)],
               [(10, 1, 120), (5, 3, 150), (11, 9, 160), (4, 8, 110)]]
    fotos = [base.copy()]
    for f in (1, 2, 3):
        a = base.copy()
        # halo que respira
        a[halo, 3] = (0, 125, 60, 105)[f]
        # núcleo: más grande en el 1, más pequeño en el 2
        if f == 1:
            crece = claro & (np.roll(blanco, 1, 1) | np.roll(blanco, -1, 1))
            a[crece] = (255, 255, 255, 255)
        elif f == 2:
            ys, xs = np.nonzero(blanco)
            for y, x in zip(ys, xs):
                vecinos = blanco[y - 1:y + 2, x - 1:x + 2].sum()
                if vecinos <= 6:
                    a[y, x] = (230, 190, 255, 255)
        # chispas sueltas en otro sitio
        for x, y in sueltas_0:
            a[y, x] = 0
        for x, y, al in sueltas[f]:
            a[y, x] = (225, 195, 255, al)
        # un pulso claro que recorre la estela hacia atrás
        x = (0, 12, 9, 6)[f]
        for y in (5, 6):
            if a[y, x, 3] > 0:
                a[y, x] = (245, 230, 255, min(255, a[y, x, 3] + 90))
        fotos.append(a)
    return tira(fotos)


MORADO = {'halo': (175, 100, 255), 'medio': (165, 85, 255), 'claro': (230, 190, 255),
          'blanco': (255, 255, 255), 'estela': (245, 230, 255), 'chispa': (225, 195, 255)}


def ping_inundacion():
    """4 x 32x14, morado más intenso y con estela larga: el de la evolución
    (Ping de inundación)."""
    w, h = 32, 14
    cx, cy = 24.5, 6.5
    yy, xx = np.mgrid[0:h, 0:w]
    r = np.hypot(xx - cx, yy - cy)
    fotos = []
    for f in range(4):
        a = lienzo(w, h)
        # estela: cuatro filas que se apagan hacia atrás, con trazos que corren
        for y in (5, 6, 7, 8):
            for x in range(1, 21):
                t = (x - 1) / 19
                if y in (6, 7):
                    col, al = MORADO['estela'], 60 + 195 * t
                else:
                    col, al = MORADO['medio'], 30 + 170 * t
                if y in (5, 8) and (x + 3 * f) % 6 == 0:
                    col, al = MORADO['claro'], min(255, al + 60)
                if al > 20:
                    a[y, x] = (*col, al)
        # estelas finas de los lados
        for y in (3, 10):
            for x in range(8, 20):
                if (x + 2 * f + y) % 4 != 0:
                    a[y, x] = (*MORADO['medio'], 40 + 9 * (x - 8))
        # halo y bola
        a[(r <= 6.6) & (a[..., 3] < 90)] = (*MORADO['halo'], 95)
        a[r <= 5.2] = (*MORADO['medio'], 255)
        a[r <= 3.7] = (*MORADO['claro'], 255)
        a[r <= (2.3, 2.9, 2.0, 2.6)[f]] = (*MORADO['blanco'], 255)
        # cuatro chispas que giran alrededor
        for k in range(4):
            ang = k * math.tau / 4 + f * math.tau / 16
            x, y = cx + math.cos(ang) * 6.6, cy + math.sin(ang) * 6.6
            poner(a, x, y, MORADO['chispa'], 230)
        # chispas sueltas detrás
        rng = np.random.default_rng(50 + f)
        for _ in range(5):
            poner(a, rng.integers(0, 16), rng.integers(1, 13), MORADO['chispa'], int(rng.uniform(100, 190)))
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ fragmento de datos
def fragmento(ruta_actual):
    """4 x 12x12 en grises: el 0 es fragmento_datos.png tal cual; en el 1, 2 y 3
    un brillo recorre el cristal en diagonal y el halo late."""
    base = np.array(Image.open(ruta_actual).convert('RGBA')).astype(np.float64)
    dentro = (base[..., 3] == 255) & (base[..., 0] > 100)
    halo = base[..., 3] == 70
    yy, xx = np.mgrid[0:12, 0:12]
    fotos = [base.copy()]
    for f, (k, al) in enumerate(((5, 95), (10, 120), (15, 95)), 1):
        a = base.copy()
        a[halo, 3] = al
        banda = dentro & (xx + yy == k)
        junto = dentro & (np.abs(xx + yy - k) == 1)
        a[junto] = np.maximum(a[junto], 240)
        a[junto, 3] = 255
        a[banda] = (255, 255, 255, 255)
        fotos.append(a)
    return tira(fotos)


def recogida():
    """4 x 24x24 en grises: el destello al recoger un fragmento (estrella, anillo
    que se abre y chispitas). Se tiñe como el fragmento."""
    lado, c = 24, 11.5
    yy, xx = np.mgrid[0:lado, 0:lado]
    r = np.hypot(xx - c, yy - c)
    b = bayer(lado, lado)
    fotos = []
    for f in range(4):
        a = lienzo(lado)
        if f <= 1:
            largo = (6, 9)[f]
            for d in range(0, largo + 1):
                v = int(255 - 100 * d / largo)
                for s in (-1, 1):
                    if f == 0 or d % 2 == 0:
                        poner_si_mas_claro(a, c + s * d + 0.5, c + 0.5, v)
                        poner_si_mas_claro(a, c + 0.5, c + s * d + 0.5, v)
            a[r <= (1.6, 0.8)[f]] = (255, 255, 255, 255)
        if f >= 1:
            radio = (0, 5.5, 8.5, 10.5)[f]
            anillo = (np.abs(r - radio) <= 0.6) & (b < (0, 1.0, 0.6, 0.3)[f])
            a[anillo & (a[..., 3] == 0)] = (215, 215, 215, 255)
        if f >= 2:
            for k in range(4):
                ang = k * math.tau / 4 + math.pi / 4
                d = (0, 0, 8, 10)[f]
                x, y = c + math.cos(ang) * d + 0.5, c + math.sin(ang) * d + 0.5
                v = (0, 0, 255, 170)[f]
                for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
                    if (dx, dy) == (0, 0) or f == 2:
                        poner_si_mas_claro(a, x + dx, y + dy, v if (dx, dy) == (0, 0) else v - 70)
        fotos.append(a)
    return tira(fotos)


# ------------------------------------------------------------------ mira del Mago
MIRA = {'oscuro': (96, 58, 128), 'medio': (191, 115, 255), 'claro': (225, 190, 255), 'blanco': (246, 236, 255)}


def mira_tramo():
    """4 x 32x16, morado #BF73FF: un tramo de la línea de apuntar con flechas
    que avanzan hacia la punta (a la derecha). Se repite a lo largo del rayo:
    cada 16 px es igual, y cada fotograma avanza 4 px."""
    w, h = 32, 16
    base = lienzo(w, h)
    # línea de puntos en el centro
    for x in range(w):
        if x % 4 < 2:
            for y in (7, 8):
                base[y, x] = (*MIRA['medio'], 150)
    for x0 in (3, 19):
        # flecha fantasma detrás (tenue) y la flecha, de dos píxeles de grueso;
        # la punta, más clara
        for dx, tenue in ((-4, True), (0, False)):
            for dy in range(-4, 5):
                x = x0 + dx + (4 - abs(dy))
                filas = (7, 8) if dy == 0 else (7 + dy + (1 if dy > 0 else 0),)
                if tenue:
                    col, al = MIRA['oscuro'], 150
                else:
                    col = MIRA['blanco'] if abs(dy) <= 1 else (MIRA['claro'] if abs(dy) <= 2 else MIRA['medio'])
                    al = 255
                for y in filas:
                    poner(base, x, y, col, al)
                    poner(base, x + 1, y, col, al)
    return tira([np.roll(base, 4 * f, axis=1) for f in range(4)])


def mira_diana():
    """4 x 32x32 en bucle, morado: la diana del final del rayo, con cuatro
    corchetes que giran y el anillo que late."""
    lado, c = 32, 15.5
    yy, xx = np.mgrid[0:lado, 0:lado]
    r = np.hypot(xx - c, yy - c)
    ang = np.arctan2(yy - c, xx - c)
    fotos = []
    for f in range(4):
        a = lienzo(lado)
        radio = (9.5, 10.0, 10.5, 10.0)[f]
        a[np.abs(r - radio) <= 0.55] = (*MIRA['claro'], 255)
        a[np.abs(r - radio - 1) <= 0.5] = (*MIRA['oscuro'], 180)
        # marcas en cruz por dentro
        for d in range(4, 8):
            for s in (-1, 1):
                for x, y in ((c + s * d, c), (c, c + s * d)):
                    poner(a, x, y, MIRA['medio'])
        a[r <= 1.0] = (*MIRA['blanco'], 255)
        # corchetes que giran (22,5 grados por fotograma)
        giro = f * math.pi / 8
        for k in range(4):
            centro = k * math.pi / 2 + math.pi / 4 + giro
            arco = (np.abs(r - 14) <= 0.7) & (np.abs(np.angle(np.exp(1j * (ang - centro)))) < 0.32)
            a[arco] = (*MIRA['medio'], 255)
            for s in (-1, 1):
                pa = centro + s * 0.32
                for d in (12.5, 13.3):
                    poner(a, c + math.cos(pa) * d, c + math.sin(pa) * d, MIRA['medio'])
        fotos.append(a)
    return tira(fotos)


def click_izquierdo():
    """16x16: un ratón con el botón izquierdo encendido en morado. Sustituye al
    texto "CLICK"."""
    colores = {'o': (20, 16, 28), 'g': (215, 215, 225), 's': (150, 150, 165), 'l': (191, 115, 255),
               'L': (225, 190, 255), 'r': (191, 115, 255, 200)}
    return desde_texto([
        "r...............",
        ".r.r............",
        "...r............",
        "r.....oooooo....",
        ".....oLlloggo...",
        "....oLllloggso..",
        "....olllloggso..",
        "....olllloggso..",
        "....ooooooooso..",
        "....oggggggsso..",
        "....oggggggsso..",
        "....oggggggsso..",
        "....ogggggssso..",
        ".....ogggssso...",
        "......oooooo....",
        "................",
    ], colores)


def generar(carpeta_efectos, carpeta_herramientas, ruta_ping, ruta_fragmento):
    guardar(barra_enemigo_marco(), f'{carpeta_efectos}/barra_enemigo_marco.png')
    guardar(relleno(44, 5), f'{carpeta_efectos}/barra_enemigo_relleno.png')
    guardar(barra_personaje_marco(), f'{carpeta_efectos}/barra_personaje_marco.png')
    guardar(relleno(40, 5), f'{carpeta_efectos}/barra_personaje_vida.png')
    guardar(relleno(40, 2), f'{carpeta_efectos}/barra_personaje_ulti.png')
    guardar(ulti_lista(), f'{carpeta_efectos}/ulti_lista.png')
    guardar(ping(ruta_ping), f'{carpeta_herramientas}/proyectil_ping_anim.png')
    guardar(ping_inundacion(), f'{carpeta_herramientas}/proyectil_ping_inundacion.png')
    guardar(fragmento(ruta_fragmento), f'{carpeta_efectos}/fragmento_datos_anim.png')
    guardar(recogida(), f'{carpeta_efectos}/fragmento_recogida.png')
    guardar(mira_tramo(), f'{carpeta_efectos}/mira_rayo_tramo.png')
    guardar(mira_diana(), f'{carpeta_efectos}/mira_rayo_diana.png')
    guardar(click_izquierdo(), f'{carpeta_efectos}/click_izquierdo.png')
