extends Node2D

# Prueba temporal del lote 8: dibuja cada efecto en bucle alrededor del
# jugador, con sus tiempos, sobre el suelo de verdad. "suelo" lo pone debajo
# (la invocación); si no, encima.
var suelo := false
var _t := 0.0
var _jugador: Node2D
const MAGO := preload("res://escenas/jugabilidad/jugador/antivirus_8_direcciones.png")
const ESPADA := preload("res://escenas/jugabilidad/jugador/ciberespadachin_8_direcciones.png")
const ROOTKIT := preload("res://recursos/enemigos/sprites/rootkit.png")
const E := "res://medios/sprites/efectos/"
const H := "res://medios/sprites/herramientas/"


var _hojas := {}


func _ready() -> void:
	_jugador = get_tree().get_first_node_in_group("jugador")
	for ruta in ["invocacion_kernel_panic", "caida_personaje", "derrota_personaje", "golpe_recibido", "escudo_proteccion",
			"evolucion_herramienta", "muerte_elite", "fragmento_datos_anim", "fragmento_recogida", "mira_rayo_tramo",
			"mira_rayo_diana", "click_izquierdo"]:
		_hojas[E + ruta + ".png"] = load(E + ruta + ".png")
	for ruta in ["proyectil_ping_anim", "proyectil_ping_inundacion"]:
		_hojas[H + ruta + ".png"] = load(H + ruta + ".png")


func _h(ruta: String) -> Texture2D:
	return _hojas[ruta]
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _tira(hoja: Texture2D, n: int, spf: float, centro: Vector2, color := Color.WHITE, bucle := true, pausa := 0.5) -> bool:
	var dura := n * spf
	var t := fmod(_t, dura) if bucle else fmod(_t, dura + pausa)
	if t >= dura:
		return false
	var lado := Vector2(hoja.get_width() / float(n), hoja.get_height())
	draw_texture_rect_region(hoja, Rect2(centro - lado / 2.0, lado), Rect2(int(t / spf) * lado.x, 0, lado.x, lado.y), color)
	return true


func _personaje(hoja: Texture2D, centro: Vector2) -> void:
	draw_texture_rect_region(hoja, Rect2(centro - Vector2(32, 36), Vector2(64, 72)), Rect2(0, 0, 64, 72))


func _etiqueta(texto: String, en: Vector2) -> void:
	draw_string(ThemeDB.fallback_font, en + Vector2(-50, 0), texto, HORIZONTAL_ALIGNMENT_CENTER, 100, 11, Color(0.85, 0.9, 0.95))


func _draw() -> void:
	var p := _jugador.global_position - global_position
	if suelo:
		_tira(_h(E + "invocacion_kernel_panic.png"), 8, 0.125, p + Vector2(390, 150), Color.WHITE, false)
		return
	var fila := p + Vector2(0, -205)
	# caída y derrota: el sprite y luego el efecto (el sprite se esconde)
	if not _tira(_h(E + "caida_personaje.png"), 8, 0.08, fila + Vector2(-540, 0), Color(0.75, 0.45, 1.0), false):
		_personaje(MAGO, fila + Vector2(-540, 0))
	_etiqueta("caída", fila + Vector2(-540, 58))
	if not _tira(_h(E + "derrota_personaje.png"), 12, 0.08, fila + Vector2(-420, 0), Color(1.0, 0.35, 0.35), false):
		_personaje(MAGO, fila + Vector2(-420, 0))
	_etiqueta("derrota", fila + Vector2(-420, 58))
	_personaje(MAGO, fila + Vector2(-300, 0))
	_tira(_h(E + "golpe_recibido.png"), 4, 0.05, fila + Vector2(-300, 0), Color(1.0, 0.25, 0.3), false, 0.4)
	_etiqueta("golpe", fila + Vector2(-300, 58))
	_personaje(ESPADA, fila + Vector2(-180, 0))
	_tira(_h(E + "escudo_proteccion.png"), 4, 0.1, fila + Vector2(-180, 0), Color(0.4, 1.0, 0.5))
	_etiqueta("escudo", fila + Vector2(-180, 58))
	_personaje(ESPADA, fila + Vector2(-40, 0))
	_tira(_h(E + "evolucion_herramienta.png"), 10, 0.07, fila + Vector2(-40, 0), Color(0.4, 1.0, 0.5), false, 0.3)
	_etiqueta("evolución", fila + Vector2(-40, 58))
	if not _tira(_h(E + "muerte_elite.png"), 8, 0.06, fila + Vector2(110, 0), Color.WHITE, false, 0.6):
		draw_texture(ROOTKIT, fila + Vector2(110 - 24, -24))
	_etiqueta("muerte élite", fila + Vector2(110, 58))
	_tira(_h(H + "proyectil_ping_anim.png"), 4, 0.06, fila + Vector2(230, -10))
	_tira(_h(H + "proyectil_ping_inundacion.png"), 4, 0.06, fila + Vector2(230, 14))
	_etiqueta("Ping", fila + Vector2(230, 58))
	_tira(_h(E + "fragmento_datos_anim.png"), 4, 0.12, fila + Vector2(320, -10), Color(1.0, 0.92, 0.3))
	_tira(_h(E + "fragmento_recogida.png"), 4, 0.06, fila + Vector2(320, 16), Color(1.0, 0.92, 0.3), false, 0.5)
	_etiqueta("fragmento", fila + Vector2(320, 58))
	# mira del rayo del Mago: tramos hasta la diana, y el click
	var desde := p + Vector2(0, -22) + Vector2(1, -0.25).normalized() * 40.0
	var dir := Vector2(1, -0.25).normalized()
	var largo := 300.0
	var tramo: Texture2D = _h(E + "mira_rayo_tramo.png")
	var f := int(_t / 0.08) % 4
	draw_set_transform(desde, dir.angle())
	var x := 0.0
	while x < largo:
		var w := minf(32.0, largo - x)
		draw_texture_rect_region(tramo, Rect2(x, -8, w, 16), Rect2(f * 32, 0, w, 16))
		x += 32.0
	draw_set_transform(Vector2.ZERO)
	_tira(_h(E + "mira_rayo_diana.png"), 4, 0.1, desde + dir * largo)
	draw_texture(_h(E + "click_izquierdo.png"), p + Vector2(-8, 28))
