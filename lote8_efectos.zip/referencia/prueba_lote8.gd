extends SceneTree

# Prueba temporal del lote 8: todos los efectos alrededor del jugador, un
# élite Explosivo de verdad, partículas, la barra del jugador con la ulti
# llena y las barras de los enemigos.
var _raiz: Node
var _frames := 0
var _pool: Node


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		var jugador: Node2D = _raiz.get_node("Jugador")
		jugador.get_node("Salud").invencible = true
		jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		var elite: Node2D = _raiz.get_node("Elite1")
		elite.datos = elite.datos.duplicate()
		elite.datos.velocidad = 0.0
		var lista: Array[DatosAfijoElite] = [load("res://recursos/enemigos/afijos/explosivo.tres")]
		elite.aparecer(jugador.global_position + Vector2(-260, 150), lista)
		var abajo: Node2D = load("res://muestra_lote8.gd").new()
		abajo.suelo = true
		_raiz.add_child(abajo)
		_raiz.move_child(abajo, 0)
		var arriba: Node2D = load("res://muestra_lote8.gd").new()
		arriba.z_index = 4
		_raiz.add_child(arriba)
		_pool = _raiz.get_node("PoolParticulas")
		root.get_node("BusEventos").ulti_cambiada.emit([1.0, 0.4, 0.0], 0)
	if _frames > 2 and _frames % 12 == 3:
		_pool.estallido(_raiz.get_node("Jugador").global_position + Vector2(-60, 160), Color(1.0, 0.4, 0.3), 30, 260.0)
	return _frames > 75
