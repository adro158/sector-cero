extends SceneTree

# Prueba temporal: cada herramienta con su efecto en una partida real con
# horda alrededor. Espadachín (Firewall y su evolución, y el anillo teñido por
# la resistencia), Segador (Escáner y Análisis heurístico) y Mago (Ping).
const TIPOS := ["BitCorrupto", "PaquetePerdido", "ProcesoColgado", "Troyano", "Ransomware"]
var _raiz: Node
var _frames := 0
var _cambio: Node
var _jugador: Node2D


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _horda(cuantos: int, cerca: float, lejos: float) -> void:
	for k in cuantos:
		var gestor: Node = _raiz.get_node(TIPOS[k % 3])
		gestor.aparecer(_jugador.global_position + Vector2.from_angle(randf() * TAU) * randf_range(cerca, lejos))


func _personaje(i: int) -> void:
	_cambio._entrar(i)
	_cambio._aplicar()


func _evolucionar(ruta: String) -> void:
	var mejora: DatosMejora = load(ruta)
	_cambio.evolucionar(mejora.arma_base, mejora.arma)


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		seed(7)
		_jugador = _raiz.get_node("Jugador")
		_jugador.get_node("Salud").invencible = true
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		# sin recoger experiencia, para que no salga el panel de subir de nivel
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("PoolGemas").visible = false
		_cambio = _jugador.get_node("CambioPersonaje")
		_personaje(0)
	match _frames:
		3, 40, 75:
			_horda(14, 60, 150)
		95:
			# resistencia alta contra el Firewall: el anillo se pone rojo
			_raiz.get_node("ResistenciaMalware")._resistencias[_cambio._armas[0]] = 0.5
		120:
			_evolucionar("res://recursos/mejoras/datos/evolucion_firewall.tres")
			_horda(14, 60, 150)
		170:
			_personaje(2)
			_horda(18, 60, 190)
		240:
			_horda(18, 60, 190)
		260:
			_evolucionar("res://recursos/mejoras/datos/evolucion_escaner.tres")
		330:
			_personaje(1)
			_horda(16, 120, 300)
		380:
			_horda(16, 120, 300)
	return _frames > 430
