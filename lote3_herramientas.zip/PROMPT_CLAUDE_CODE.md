Hoy toca que **las herramientas tengan efectos de verdad**: el golpe del Firewall, el pulso de radar del Escáner, el destello del Ping y la chispa del robo de vida, con unos sprites que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y cómo vas a sacar las chispas del robo de vida. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

He descomprimido el zip del lote 3 en la raíz del repo. Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `herramientas_en_juego.gif`: grabado en Godot 4.7.2 en una partida con horda y con los cambios de `referencia/`
- `vista_lote3.png` y `vista_anillos.png`: todos los sprites

Tamaños, tiempos, centro y capa de cada uno: `LEEME.txt`.

## Los sprites

En `projecte/medios/sprites/herramientas/`:

| Herramienta | Efecto (una vez por ataque) | Alcance (en grises) | Radio del dibujo |
|---|---|---|---|
| Firewall | `firewall_golpe.png` 6 x 256, 0,05 s | `firewall_anillo.png` | 110 |
| Firewall perimetral | `firewall_perimetral_golpe.png` 6 x 288, 0,05 s | `firewall_perimetral_anillo.png` | 125 |
| Escáner | `escaner_pulso.png` 8 x 320, 0,06 s | `escaner_anillo.png` | 150 |
| Análisis heurístico | `analisis_heuristico_pulso.png` 8 x 352, 0,06 s | `analisis_heuristico_anillo.png` | 170 |

Y dos más:
- `ping_impacto.png`: 4 x 24x24, 0,05 s, donde impacta o rebota el Ping.
- `robo_vida_chispa.png`: 4 x 8x8, 0,06 s en bucle, del enemigo al Espadachín.

## Cómo lo quiero

- **El alcance:** el anillo en grises sustituye al círculo que dibuja ahora `aura_arma.gd`. Se tiñe igual que ahora (`color.lerp(color_resistido, resistencia)`), más transparente cuando no ataca y entero cuando ataca.
- **El efecto:** el golpe o el pulso suena una vez en cada ataque, encima del anillo y en su color (sin teñir).
- **Escala:** los dibujos están al radio base de su herramienta. Con Ampliar subred se escalan: escala = `arma.radio * multiplicador_alcance / radio del dibujo`.
- **Capas:** el anillo y el efecto van debajo del jugador y de la horda, encima del suelo. En la prueba, `AuraArma` tiene `show_behind_parent = true` y `texture_filter` en nearest.
- **Ping:** el destello en cada impacto y rebote, en `pool_proyectiles.gd`, encima de la horda. En la prueba, `PoolProyectiles` necesita `texture_filter` en nearest para que no salga borroso.
- **Robo de vida:** una chispa por enemigo alcanzado (con un máximo, por ejemplo 5 por golpe), del enemigo al personaje en unos 0,35 s.
  - En la prueba salen de puntos al azar del alcance, porque `danar_en_area` solo devuelve cuántos alcanza.
  - Propónme la forma más sencilla de sacar la posición de los enemigos, o si basta con la aproximación.
- Las evoluciones usan su propio efecto: se elige por el arma activa.

`referencia/efectos_herramientas.diff` es el cambio probado de la grabación:
- `aura_arma.gd` reescrito con un diccionario por herramienta
- los impactos en `pool_proyectiles.gd`
- el `show_behind_parent` y los `texture_filter`

Úsalo de guía, pero:
- elige las herramientas por algo más robusto que el `nombre` si lo ves mejor (por ejemplo, exports en `DatosArma`)
- deja los scripts por debajo de ~200 líneas y fáciles de explicar

## Al terminar

- Validación del CLAUDE.md: import y `--quit-after`.
- Con ventana, haz capturas de cada personaje atacando con su herramienta y con su evolución. Comprueba también que:
  - el anillo se pone rojo con la resistencia (puedes forzarla con una instrumentación temporal)
  - la escala está bien con Ampliar subred ×3
  - al pausar (subida de nivel) los efectos se paran

  Borra la instrumentación al acabar.
- Rendimiento: el Firewall ataca cada 0,5-0,6 s y puede haber muchos impactos del Ping. Mídelo en casa con `herramientas/medir_rendimiento.gd`.
- No cambia el balance: no hace falta el simulador, pero pasa una partida para comprobar que no salen errores.
- **Documentación:**
  - `creditos.md`: los sprites del lote 3 los hizo Claude, con IA, como los demás.
  - `documentacion_tecnica.md` (los efectos y el anillo teñido) y el manual si habla del alcance.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- Solo se commitea lo de `projecte/` y la documentación. No se commitean las vistas previas (`.png` y `.gif` de la raíz), `referencia/`, `herramienta/`, `LEEME.txt` ni este prompt.
- **Commits pequeños** con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat` del alcance y los efectos de área
  - `feat` del Ping y el robo de vida
  - `docs`
- No publiques ninguna release.
