"""Efectos de las herramientas de Sector Cero (lote 3).

Los efectos van en su color. El alcance de las armas de área va aparte, en un
anillo en grises que el juego tiñe según la resistencia del malware (como el
círculo que se dibuja ahora por código).

Cada efecto de área está dibujado al radio base de su herramienta; con la
mejora Ampliar subred el juego lo escala (escala = radio de verdad / radio
del dibujo).

- firewall_golpe.png                6 x 256x256  golpe del Firewall, 110 px
- firewall_anillo.png               1 x 256x256  alcance, en grises, 110 px
- firewall_perimetral_golpe.png     6 x 288x288  golpe del Firewall perimetral, 125 px
- firewall_perimetral_anillo.png    1 x 288x288  alcance, en grises, 125 px
- escaner_pulso.png                 8 x 320x320  pulso de radar del Escáner, 150 px
- escaner_anillo.png                1 x 320x320  alcance, en grises, 150 px
- analisis_heuristico_pulso.png     8 x 352x352  pulso del Análisis heurístico, 170 px
- analisis_heuristico_anillo.png    1 x 352x352  alcance, en grises, 170 px
- ping_impacto.png                  4 x 24x24    destello del Ping al impactar o rebotar
- robo_vida_chispa.png              4 x 8x8      chispa del robo de vida

Uso: python3 generar_herramientas.py  (numpy y Pillow; usa pixel.py)
"""
import math
import os
import random
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pixel import Capa, bayer

OUT = './'
VERDE = [(6, 30, 16), (14, 70, 34), (30, 140, 66), (102, 255, 128), (180, 255, 190), (236, 255, 238)]
ROJO = [(40, 6, 10), (100, 16, 26), (180, 36, 48), (255, 89, 89), (255, 170, 160), (255, 236, 230)]
MORADO = [(34, 14, 58), (80, 34, 130), (140, 70, 220), (191, 115, 255), (222, 180, 255), (248, 236, 255)]
ORO = [(120, 78, 14), (184, 124, 28), (236, 184, 64), (255, 230, 140)]
GRIS = [(70, 70, 70), (130, 130, 130), (190, 190, 190), (255, 255, 255)]
BLANCO = (255, 255, 255)


def rejilla(n):
    c = (n - 1) / 2
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    return xx - c, yy - c, c


def guardar(capas, nombre):
    alto, ancho = capas[0].h, capas[0].w
    hoja = np.zeros((alto, ancho * len(capas), 4), np.uint8)
    for i, c in enumerate(capas):
        hoja[:, i * ancho:(i + 1) * ancho] = c.uint8()
    Image.fromarray(hoja, 'RGBA').save(OUT + nombre)


def bordes_hex(dx, dy, lado):
    """Máscara de las aristas de una rejilla de hexágonos (cortafuegos)."""
    q = (math.sqrt(3) / 3 * dx - dy / 3) / lado
    r = (2 / 3 * dy) / lado
    # redondeo en coordenadas cúbicas
    x, z = q, r
    y = -x - z
    rx, ry, rz = np.round(x), np.round(y), np.round(z)
    ex, ey, ez = np.abs(rx - x), np.abs(ry - y), np.abs(rz - z)
    m1 = (ex > ey) & (ex > ez)
    rx = np.where(m1, -ry - rz, rx)
    m2 = ~m1 & (ey > ez)
    ry = np.where(m2, -rx - rz, ry)
    rz = np.where(~m1 & ~m2, -rx - ry, rz)
    cx = lado * (math.sqrt(3) * rx + math.sqrt(3) / 2 * rz)
    cy = lado * (1.5 * rz)
    lx, ly = dx - cx, dy - cy
    norma = np.maximum.reduce([np.abs(lx), np.abs(lx * 0.5 + ly * math.sqrt(3) / 2), np.abs(-lx * 0.5 + ly * math.sqrt(3) / 2)])
    return norma > lado * math.sqrt(3) / 2 - 1.0, (rx * 7 + rz * 13) % 5


def ruido_angular(semilla, n_th=360):
    rng = np.random.default_rng(semilla)
    th = np.linspace(0, 2 * math.pi, n_th, endpoint=False)
    v = np.zeros(n_th)
    for k, a in ((5, 1.0), (9, 0.6), (17, 0.35), (29, 0.2)):
        v += a * np.sin(k * th + rng.uniform(0, 6.28))
    return (v - v.min()) / (v.max() - v.min())


# ====================================================================== Firewall
def firewall(nombre, n, radio, evolucion=False):
    dx, dy, c = rejilla(n)
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    b = bayer(n, n)
    aristas, tipo_celda = bordes_hex(dx, dy, 9 if not evolucion else 10)
    k = radio / 110
    frentes = [28, 62, 88, 104, 110, 110]
    grosores = [10, 9, 8, 6, 3, 2]
    capas = []
    for f in range(6):
        capa = Capa(n)
        rf = frentes[f] * k
        w = grosores[f]
        # cortafuegos: la rejilla de hexágonos se enciende detrás del frente
        if 1 <= f <= 4:
            banda = (r < rf - w / 2) & (r > rf - 40)
            fuerza = 1 - (rf - r) / 40
            capa.rellenar(banda & ~aristas & (tipo_celda == f % 5) & (b < 0.5 * fuerza), VERDE[1], 170)
            capa.rellenar(banda & aristas & (b < fuerza * (1.1 - f * 0.18)), VERDE[2])
            capa.rellenar(banda & aristas & (r > rf - 14) & (b < 0.8), VERDE[3] if not evolucion else VERDE[4])
            if evolucion:
                # nudos de oro en las esquinas cerca del frente
                nudos = banda & aristas & (r > rf - 16) & (tipo_celda == (f + 2) % 5) & (b < 0.2)
                capa.rellenar(nudos, ORO[2])
        # llamas verdes hacia fuera del frente
        if 1 <= f <= 4:
            ru = ruido_angular(7 + f)
            idx = (th / (2 * math.pi) * 360).astype(int) % 360
            largo = (2 + 11 * ru[idx] ** 1.5) * (1.0 if f < 4 else 0.5)
            dentro = (r > rf + w / 2 - 1) & (r < rf + w / 2 + largo)
            kk = (r - rf - w / 2) / np.maximum(largo, 1e-6)
            capa.rellenar(dentro, VERDE[2])
            capa.rellenar(dentro & (kk < 0.6), VERDE[3])
            capa.rellenar(dentro & (kk < 0.25), VERDE[4])
            capa.a[dentro & (kk > 0.8) & (b < 0.5)] = 0
        # el anillo del golpe
        anillo = np.abs(r - rf) <= w / 2
        if f < 5:
            capa.rellenar(anillo, VERDE[3] if f < 4 else VERDE[2])
            capa.rellenar(np.abs(r - rf) <= max(0.7, w / 4), VERDE[5] if f < 3 else VERDE[4])
            if evolucion:
                # un segundo anillo que sigue al primero
                capa.rellenar(np.abs(r - (rf - 12)) <= max(0.6, w / 5), VERDE[4] if f < 4 else VERDE[3])
                capa.rellenar((np.abs(r - (rf + w / 2 + 1)) <= 0.6) & (b < 0.6), ORO[3])
        else:
            capa.rellenar(anillo & (b < 0.4), VERDE[2], 180)
        # destello del centro
        if f == 0:
            capa.rellenar(r <= 20, VERDE[4])
            capa.rellenar(r <= 13, VERDE[5])
            capa.rellenar(r <= 7, BLANCO)
        # emblemas del perímetro (solo la evolución): 8 hexágonos en el borde
        if evolucion and f in (3, 4):
            for j in range(8):
                ang = j * math.pi / 4 + math.pi / 8
                ex, ey = c + math.cos(ang) * (rf - 6), c + math.sin(ang) * (rf - 6)
                hx, hy = dx - (ex - c), dy - (ey - c)
                hexa = np.maximum.reduce([np.abs(hx), np.abs(hx * 0.5 + hy * 0.866), np.abs(-hx * 0.5 + hy * 0.866)])
                capa.rellenar(hexa <= 4.5, ORO[1])
                capa.rellenar(hexa <= 3.2, ORO[2] if f == 3 else VERDE[3])
                capa.rellenar(hexa <= 1.4, ORO[3] if f == 3 else VERDE[5])
        # chispas que salen al final
        if f >= 3:
            for j in range(24):
                ang = j * 2.399
                d = rf + 4 + (f - 3) * 7 + (j % 4) * 2
                if d < n / 2 - 2:
                    capa.px(c + math.cos(ang) * d, c + math.sin(ang) * d, VERDE[4] if f < 5 else VERDE[2])
        capas.append(capa)
    guardar(capas, nombre)


# ====================================================================== Escáner
def escaner(nombre, n, radio, evolucion=False):
    dx, dy, c = rejilla(n)
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + math.pi / 2 + 4 * math.pi) % (2 * math.pi)   # 0 arriba, en sentido horario
    b = bayer(n, n)
    k = radio / 150
    rng = random.Random(21)
    ecos = [(rng.uniform(0, 2 * math.pi), rng.uniform(30, radio - 10)) for _ in range(14)]
    pulsos = [30, 75, 115, 150, 150, 150, 150, 150]
    grosores = [6, 6, 5, 4, 3, 2, 2, 1]
    apagado = [1.0, 1.0, 1.0, 1.0, 0.9, 0.7, 0.45, 0.25]
    capas = []
    for f in range(8):
        capa = Capa(n)
        rp = pulsos[f] * k
        luz = apagado[f]
        haz = f * math.pi / 4                    # 45 grados por fotograma
        dentro = r <= rp
        # estela del haz de radar: detrás del haz, cada vez más tenue
        atras = (haz - th) % (2 * math.pi)
        estela = dentro & (atras < 1.8)
        fuerza = (1 - atras / 1.8) * luz
        capa.rellenar(estela & (b < fuerza * 0.55), ROJO[1], 200)
        capa.rellenar(estela & (atras < 0.5) & (b < fuerza * 0.8), ROJO[2])
        # el haz
        linea = dentro & (atras < 0.035 + 1.2 / np.maximum(r, 1))
        capa.rellenar(linea & (r > 4), ROJO[4] if luz > 0.6 else ROJO[3])
        if evolucion:
            # un segundo haz dorado que gira al revés
            haz2 = -f * math.pi / 4 + math.pi
            atras2 = (th - haz2) % (2 * math.pi)
            capa.rellenar(dentro & (atras2 < 0.9) & (b < (1 - atras2 / 0.9) * 0.45 * luz), ORO[1], 200)
            capa.rellenar(dentro & (atras2 < 0.03 + 1.2 / np.maximum(r, 1)) & (r > 4), ORO[3] if luz > 0.6 else ORO[2])
        # anillos de distancia y la cruz, a trazos
        if 1 <= f <= 6:
            for rr in (radio / 3, 2 * radio / 3):
                if rr < rp:
                    trazo = ((th * rr / 4).astype(int) % 2 == 0)
                    capa.rellenar((np.abs(r - rr) <= 0.6) & trazo & (b < luz), ROJO[2])
            cruz = ((np.abs(dx) < 0.6) | (np.abs(dy) < 0.6)) & dentro & ((r.astype(int) // 3) % 2 == 0)
            capa.rellenar(cruz & (b < luz * 0.8), ROJO[2])
        # ecos: puntos que se encienden cuando pasa el haz
        for ang, d in ecos:
            if d > rp:
                continue
            desde = (haz - ang) % (2 * math.pi)
            if desde < math.pi / 4 * 2.2:
                col = ROJO[5] if desde < math.pi / 4 else ROJO[3]
                x, y = c + math.sin(ang) * d, c - math.cos(ang) * d
                for ox, oy in ((0, 0), (1, 0), (0, 1), (1, 1)):
                    capa.px(x + ox, y + oy, col)
                if desde < math.pi / 4:
                    for ox, oy in ((-1, 0), (2, 0), (0, -1), (1, -1), (0, 2), (1, 2)):
                        capa.px(x + ox, y + oy, ROJO[2], 160)
        # el pulso
        w = grosores[f]
        anillo = np.abs(r - rp) <= w / 2
        if f <= 3:
            capa.rellenar(anillo, ROJO[3])
            capa.rellenar(np.abs(r - rp) <= max(0.7, w / 4), ROJO[5])
            capa.rellenar((r < rp - w / 2) & (r > rp - w / 2 - 10) & (b < 0.3), ROJO[2], 180)
        else:
            capa.rellenar(anillo & (b < luz), ROJO[3])
            capa.rellenar((np.abs(r - rp) <= 0.6) & (b < luz), ROJO[4])
        if evolucion:
            # marcas del análisis en el borde, como un dial
            marcas = (np.abs(r - (rp + 3)) <= 1.4) & ((th / (2 * math.pi) * 48) % 1.0 < 0.18) & (b < luz)
            capa.rellenar(marcas, ORO[2])
        # centro
        if f <= 1:
            capa.rellenar(r <= 10 - f * 4, ROJO[4])
            capa.rellenar(r <= 5 - f * 2, BLANCO)
        else:
            capa.rellenar((r <= 2.5) & (b < luz), ROJO[4])
        capas.append(capa)
    guardar(capas, nombre)


# ====================================================================== anillos de alcance (en grises)
def anillo(nombre, n, radio):
    dx, dy, c = rejilla(n)
    r = np.hypot(dx, dy)
    th = (np.arctan2(dy, dx) + 2 * math.pi) % (2 * math.pi)
    capa = Capa(n)
    capa.rellenar(np.abs(r - radio) <= 1.5, GRIS[1])
    capa.rellenar(np.abs(r - (radio - 0.5)) <= 0.6, GRIS[3])
    # marcas cada 10 grados hacia dentro, más largas cada 45
    paso = (th / (2 * math.pi) * 36) % 1.0
    marca = (paso < 0.9 / (radio * 2 * math.pi / 36)) | (paso > 1 - 0.9 / (radio * 2 * math.pi / 36))
    capa.rellenar(marca & (r < radio - 1.5) & (r > radio - 5), GRIS[2])
    # cada 45 grados, un triángulo que apunta hacia dentro
    for j in range(8):
        ang = j * math.pi / 4
        ux, uy = math.cos(ang), math.sin(ang)
        punta = (c + ux * (radio - 8), c + uy * (radio - 8))
        base1 = (c + ux * (radio - 1.5) - uy * 3.2, c + uy * (radio - 1.5) + ux * 3.2)
        base2 = (c + ux * (radio - 1.5) + uy * 3.2, c + uy * (radio - 1.5) - ux * 3.2)
        capa.rellenar(capa.mascara_poligono([punta, base1, base2]), GRIS[3])
    guardar([capa], nombre)


# ====================================================================== Ping y robo de vida
def ping_impacto():
    capas = []
    n = 24
    dx, dy, c = rejilla(n)
    r = np.hypot(dx, dy)
    b = bayer(n, n)
    for f in range(4):
        capa = Capa(n)
        if f == 0:
            capa.rellenar((np.abs(dx) <= 0.6) & (np.abs(dy) <= 5) | (np.abs(dy) <= 0.6) & (np.abs(dx) <= 5), MORADO[4])
            capa.rellenar(r <= 2.2, MORADO[5])
            capa.rellenar(r <= 1.0, BLANCO)
        elif f == 1:
            capa.rellenar(np.abs(r - 4.5) <= 0.8, MORADO[3])
            diag = (np.abs(np.abs(dx) - np.abs(dy)) <= 0.6) & (r <= 8) & (r > 5.5)
            capa.rellenar(diag, MORADO[4])
            capa.rellenar((np.abs(dx) <= 0.6) & (np.abs(dy) <= 3) | (np.abs(dy) <= 0.6) & (np.abs(dx) <= 3), MORADO[5])
        elif f == 2:
            capa.rellenar((np.abs(r - 7.5) <= 0.8) & (b < 0.6), MORADO[3])
            for ang in range(4):
                a = ang * math.pi / 2 + math.pi / 4
                capa.px(c + math.cos(a) * 9, c + math.sin(a) * 9, MORADO[4])
            capa.rellenar(r <= 1.0, MORADO[4])
        else:
            capa.rellenar((np.abs(r - 9.5) <= 0.7) & (b < 0.3), MORADO[2])
            for ang in range(4):
                a = ang * math.pi / 2 + math.pi / 4
                capa.px(c + math.cos(a) * 10.5, c + math.sin(a) * 10.5, MORADO[3])
        capas.append(capa)
    guardar(capas, 'ping_impacto.png')


def robo_vida_chispa():
    formas = [
        ["........", "...W....", "...C....", ".WCHCW..", "...C....", "...W....", "........", "........"],
        ["........", ".C...C..", "..L.L...", "...H....", "..L.L...", ".C...C..", "........", "........"],
        ["...C....", "...L....", "...W....", "CLWHWLC.", "...W....", "...L....", "...C....", "........"],
        ["........", "........", "...L....", "..LHL...", "...L....", "........", "........", "........"],
    ]
    col = {'C': VERDE[3], 'L': VERDE[4], 'W': VERDE[5], 'H': BLANCO}
    capas = []
    for forma in formas:
        capa = Capa(8)
        for y, fila in enumerate(forma):
            for x, ch in enumerate(fila):
                if ch != '.':
                    capa.px(x, y, col[ch])
        capas.append(capa)
    guardar(capas, 'robo_vida_chispa.png')


if __name__ == '__main__':
    firewall('firewall_golpe.png', 256, 110)
    anillo('firewall_anillo.png', 256, 110)
    firewall('firewall_perimetral_golpe.png', 288, 125, evolucion=True)
    anillo('firewall_perimetral_anillo.png', 288, 125)
    escaner('escaner_pulso.png', 320, 150)
    anillo('escaner_anillo.png', 320, 150)
    escaner('analisis_heuristico_pulso.png', 352, 170, evolucion=True)
    anillo('analisis_heuristico_anillo.png', 352, 170)
    ping_impacto()
    robo_vida_chispa()
    print('ok')
