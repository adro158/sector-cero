"""El Mago atacando (lote 11): adelanta el bastón hacia donde mira, el cristal (la
calavera) se carga, suelta la bola morada #BF73FF y el bastón vuelve.

El bastón se separa del cuerpo (capas.py) y se vuelve a montar: la cabeza (la
calavera con su brillo y la cinta) se mueve tal cual, sin girarla, y el palo se
dibuja otra vez como una línea con los colores del de siempre. Todo gira
alrededor de la mano. Se hacen las filas 0 a 4 y las 5, 6 y 7 son las 3, 2 y 1
en espejo, como en las hojas de andar.
"""
import math

import numpy as np
from scipy import ndimage as ndi

from capas import FH, FW, fotograma
from seg import frame, segment

CONTORNO = (12, 6, 10)
PALO = [(23, 27, 33), (38, 45, 55), (55, 65, 79), (73, 87, 105)]
CIAN = (37, 234, 252)
BOLA = {'halo': (191, 115, 255), 'medio': (191, 115, 255), 'claro': (225, 190, 255), 'blanco': (250, 245, 255)}
CARGA = (225, 190, 255)

# Por fila: giro del bastón alrededor de la mano (grados, positivo en el sentido
# de las agujas del reloj), escala (menos de 1: apunta hacia la cámara o lejos
# de ella y se ve más corto), si va delante o detrás del cuerpo, y hacia dónde
# sale la bola (la dirección a la que mira).
POSES = {
    0: (-22, 0.55, 'delante', (0.0, 1.0)),
    1: (-46, 0.70, 'delante', (-0.71, 0.71)),
    2: (-56, 0.62, 'delante', (-1.0, 0.0)),
    3: (-24, 1.10, 'detras', (-0.71, -0.71)),
    4: (10, 1.16, 'detras', (0.0, -1.0)),
}
# Cuánto de la pose: fotograma 0 de pie (es el de andar tal cual), 1 a medias,
# 2 del todo (suelta la bola) y 3 volviendo.
AVANCE = [0.0, 0.55, 1.0, 0.5]


def _gira(p, centro, grados, escala):
    a = math.radians(grados)
    x, y = p[0] - centro[0], p[1] - centro[1]
    return (centro[0] + escala * (x * math.cos(a) - y * math.sin(a)),
            centro[1] + escala * (x * math.sin(a) + y * math.cos(a)))


class Baston:
    """El bastón de una fila: la cabeza como sprite, y el palo como dos puntos."""

    def __init__(self, andar0, cuerpo0, mano0, d):
        S = segment(frame(d, 0))
        x0, y0, x1, y1 = S['sk_box']
        dif = (np.abs(andar0.astype(int) - cuerpo0.astype(int)).sum(-1) > 0) & (andar0[..., 3] > 0)
        rgb = andar0[..., :3]
        es_palo = np.zeros(dif.shape, bool)
        for c in PALO + [CONTORNO, CIAN]:
            es_palo |= (rgb == c).all(-1)
        # la energía cian del palo evolucionado (varios tonos)
        r_, g_, b_ = rgb[..., 0].astype(int), rgb[..., 1].astype(int), rgb[..., 2].astype(int)
        es_palo |= (r_ < 190) & (g_ > 160) & (b_ > 170)
        yy = np.mgrid[0:FH, 0:FW][0]
        palo = dif & es_palo & (yy > y1 + 1)
        cabeza = dif & ~palo
        # solo lo de arriba (calavera, brillo y cinta): lo de los pies es la punta del palo
        cabeza &= yy < mano0.nonzero()[0].mean() - 4
        # los contornos pegados a la cinta son de la cinta
        junto = ndi.binary_dilation(cabeza & ~(rgb == CONTORNO).all(-1), structure=np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]]))
        devolver = palo & (rgb == CONTORNO).all(-1) & junto
        palo &= ~devolver
        cabeza |= devolver
        self.cabeza = np.zeros_like(andar0)
        self.cabeza[cabeza] = andar0[cabeza]
        self.calavera = S['skull'].copy()
        ys, xs = np.nonzero(S['skull'])
        self.centro = (xs.mean(), ys.mean())
        self.base = ((x0 + x1) / 2.0, y1 + 1.0)
        ys, xs = np.nonzero(palo)
        abajo = ys.max()
        self.cola = (xs[ys >= abajo - 1].mean(), float(abajo))
        ys, xs = np.nonzero(mano0)
        self.mano = (xs.mean(), ys.mean())
        self.palo_cian = bool(((rgb == CIAN).all(-1) & palo).any())


def _linea(out, p0, p1, cian):
    """El palo: dos píxeles de grueso (medio y claro) con contorno oscuro."""
    largo = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
    n = max(int(largo * 2), 1)
    ux, uy = (p1[0] - p0[0]) / max(largo, 1e-6), (p1[1] - p0[1]) / max(largo, 1e-6)
    px, py = -uy, ux  # perpendicular
    capas = [(-1.0, CONTORNO), (2.0, CONTORNO), (0.0, PALO[2]), (1.0, PALO[3])]
    for capa, col in capas:
        for i in range(n + 1):
            t = i / n
            x = p0[0] + (p1[0] - p0[0]) * t + px * capa
            y = p0[1] + (p1[1] - p0[1]) * t + py * capa
            xi, yi = int(round(x)), int(round(y))
            if 0 <= xi < FW and 0 <= yi < FH:
                if col == CONTORNO and out[yi, xi, 3] == 255 and tuple(out[yi, xi, :3]) != CONTORNO:
                    continue
                c = col
                if cian and col != CONTORNO and i % 6 < 2:
                    c = CIAN
                out[yi, xi] = (*c, 255)


def _pegar(out, capa, dx, dy, encima=True):
    ys, xs = np.nonzero(capa[..., 3] > 0)
    for y, x in zip(ys, xs):
        ty, tx = y + dy, x + dx
        if 0 <= ty < FH and 0 <= tx < FW:
            p = capa[y, x]
            if p[3] == 255:
                if encima or out[ty, tx, 3] < 255:
                    out[ty, tx] = p
            elif out[ty, tx, 3] < p[3]:
                out[ty, tx] = p


def _halo(out, cx, cy, radio, densidad, col):
    from pixel import bayer
    b = bayer(FH, FW)
    yy, xx = np.mgrid[0:FH, 0:FW]
    r = np.hypot(xx - cx, yy - cy)
    anillo = (r <= radio) & (r > radio - 2.2) & (b < densidad)
    sel = anillo & (out[..., 3] < 255)
    out[sel] = (*col, 255)


def _bola(out, cx, cy, grande=False):
    yy, xx = np.mgrid[0:FH, 0:FW]
    r = np.hypot(xx - cx, yy - cy)
    k = 1.3 if grande else 1.0
    halo = (r <= 4.6 * k) & (out[..., 3] < 120)
    out[halo] = (*BOLA['halo'], 110)
    out[r <= 3.3 * k] = (*BOLA['medio'], 255)
    out[r <= 2.3 * k] = (*BOLA['claro'], 255)
    out[r <= 1.2 * k] = (*BOLA['blanco'], 255)


def montar(cuerpo, mano_c, baston, d, avance, carga, bola=False, chispas=False, evolucionado=False):
    """Un fotograma: el cuerpo, el bastón girado según el avance (0 de pie, 1
    del todo) y el cristal con su carga (0 a 1)."""
    grados, escala, capa, mira = POSES[d]
    ys, xs = np.nonzero(mano_c)
    mano = (xs.mean(), ys.mean()) if len(xs) else baston.mano
    # lo que se ha movido la mano en este paso respecto al de pie
    mx, my = mano[0] - baston.mano[0], mano[1] - baston.mano[1]
    g = grados * avance
    s = 1.0 + (escala - 1.0) * avance
    cola = _gira((baston.cola[0] + mx, baston.cola[1] + my), mano, g, s)
    base = _gira((baston.base[0] + mx, baston.base[1] + my), mano, g, s)
    cen = _gira((baston.centro[0] + mx, baston.centro[1] + my), mano, g, s)
    dx, dy = int(round(cen[0] - baston.centro[0])), int(round(cen[1] - baston.centro[1]))
    # la cabeza, con el cristal cargado
    cabeza = baston.cabeza.copy()
    if carga > 0:
        cal = baston.calavera & (cabeza[..., 3] == 255)
        col = np.array(CARGA, float)
        cabeza[cal, :3] = (cabeza[cal, :3] * (1 - 0.6 * carga) + col * 0.6 * carga).astype(np.uint8)
    out = np.zeros_like(cuerpo)
    if capa == 'detras':
        _linea(out, cola, base, evolucionado)
        _pegar(out, cabeza, dx, dy)
        _pegar(out, cuerpo, 0, 0)
    else:
        out = cuerpo.copy()
        _linea(out, cola, base, evolucionado)
        # la mano otra vez encima del palo
        out[mano_c] = cuerpo[mano_c]
        _pegar(out, cabeza, dx, dy)
    if carga > 0:
        _halo(out, cen[0], cen[1], 5.5 + 2.5 * carga, 0.35 + 0.5 * carga, BOLA['medio'])
    if bola:
        bx = min(max(cen[0] + mira[0] * 7, 5.0), FW - 6.0)
        by = min(max(cen[1] + mira[1] * 7, 5.0), FH - 6.0)
        _bola(out, bx, by, evolucionado)
    if chispas:
        for k, (ox, oy) in enumerate(((7, -2), (9, 3), (5, 5), (10, -4))):
            x = int(round(cen[0] + mira[0] * ox - mira[1] * (oy)))
            y = int(round(cen[1] + mira[1] * ox + mira[0] * (oy)))
            if 0 <= x < FW and 0 <= y < FH and out[y, x, 3] < 255:
                out[y, x] = (*BOLA['claro'], 255)
    return out


def _espejar(fr, columnas):
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(columnas):
            fr[(dst, f)] = fr[(src, f)][:, ::-1].copy()
    return fr


def ataque(hoja_andar, cuerpos, manos, evolucionado=False):
    """4 x 8 de 64x72: de pie (igual que andar), a medias cargando, del todo
    soltando la bola y volviendo."""
    fr = {}
    for d in range(5):
        andar0 = fotograma(hoja_andar, d, 0)
        b = Baston(andar0, cuerpos[(d, 0)], manos[(d, 0)], d)
        fr[(d, 0)] = andar0.copy()
        fr[(d, 1)] = montar(cuerpos[(d, 0)], manos[(d, 0)], b, d, AVANCE[1], 0.5, evolucionado=evolucionado)
        fr[(d, 2)] = montar(cuerpos[(d, 0)], manos[(d, 0)], b, d, AVANCE[2], 1.0, bola=True, evolucionado=evolucionado)
        fr[(d, 3)] = montar(cuerpos[(d, 0)], manos[(d, 0)], b, d, AVANCE[3], 0.35, chispas=True, evolucionado=evolucionado)
    fr = _espejar(fr, 4)
    A = np.zeros((8 * FH, 4 * FW, 4), np.uint8)
    for (d, f), a in fr.items():
        A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW] = a
    return A


def correr_ataque(hoja_andar, cuerpos, manos, evolucionado=False):
    """6 x 8 de 64x72: cada paso de andar con el bastón adelantado y el cristal
    encendido."""
    fr = {}
    for d in range(5):
        b = Baston(fotograma(hoja_andar, d, 0), cuerpos[(d, 0)], manos[(d, 0)], d)
        for c in range(6):
            fr[(d, c)] = montar(cuerpos[(d, c)], manos[(d, c)], b, d, 1.0, 0.85, evolucionado=evolucionado)
    fr = _espejar(fr, 6)
    A = np.zeros((8 * FH, 6 * FW, 4), np.uint8)
    for (d, f), a in fr.items():
        A[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW] = a
    return A
