"""Los personajes sin el arma, fotograma a fotograma (lote 11).

Las hojas de andar se hicieron con estos mismos scripts a partir del ejemplo del
profesor (orig/necromante_sprites): seg.py lo trocea, nostaff.py le quita el
bastón y render*.py lo recolorea y le pone el arma. Aquí se repite todo igual
pero sin dibujar el arma, así que el cuerpo (capa, piernas, sombra y la mano)
sale píxel a píxel como en la hoja de andar. También se guarda la mano que
sujetaba el arma.

- Espadachín: render2 sin la espada.
- Segador: render3 sin la guadaña y sin el palo (quitado con nostaff).
- Mago: es el ejemplo recoloreado píxel a píxel; se quita el bastón con nostaff
  y se recolorea con la misma correspondencia de colores que su hoja.
"""
import numpy as np
from PIL import Image

import render
import render2
import render3
from nostaff import remove_staff
from seg import ROBE, cmask, frame, segment, ATLAS

FW, FH = 64, 72


def _espejar(fr):
    for dst, src in [(5, 3), (6, 2), (7, 1)]:
        for f in range(6):
            fr[(dst, f)] = fr[(src, f)][:, ::-1].copy()
    return fr


def manos():
    """La mano que sujeta el arma en cada fotograma (máscara), 8 filas x 6."""
    m = {}
    for d in range(5):
        for f in range(6):
            F = frame(d, f)
            _, mano = remove_staff(F, segment(F))
            m[(d, f)] = mano if mano is not None else np.zeros((FH, FW), bool)
    return _espejar(m)


def espadachin():
    original = render2.draw_sword
    render2.draw_sword = lambda out, hand, d: out
    try:
        fr = render2.build_all2()
    finally:
        render2.draw_sword = original
    return fr


def _convert3_sin_guadana(F, S, tex, shift):
    quita, guadana = render3.remove_head, render3.draw_scythe
    render3.remove_head = lambda F_, S_: remove_staff(F_, S_)[0]
    render3.draw_scythe = lambda *args: None
    try:
        return render3.convert3(F, S, tex, shift)
    finally:
        render3.remove_head, render3.draw_scythe = quita, guadana


def segador():
    """Como render3.build_all3 (mismo desplazamiento de los circuitos), pero
    con el palo quitado y sin la hoja."""
    frames = {}
    for d in range(5):
        segs = [segment(frame(d, f)) for f in range(6)]
        base0 = render3.remove_head(frame(d, 0), segs[0])
        robe0 = cmask(base0, ROBE)
        tex = render.make_circuit_texture(robe0, seed=4242 + 31 * d)
        for f in range(6):
            F = frame(d, f)
            b = render3.remove_head(F, segs[f])
            shift = render.best_shift(robe0, cmask(b, ROBE))
            frames[(d, f)] = _convert3_sin_guadana(F, segs[f], tex, shift)
    return _espejar(frames)


def mago(hoja_mago):
    """El Mago es el ejemplo recoloreado: se aprende la correspondencia de
    colores de toda la hoja y se aplica al ejemplo sin el bastón."""
    V = np.array(Image.open(hoja_mago).convert('RGBA'))
    N = ATLAS.astype(np.uint8)
    tabla = {}
    for n, v in zip(N.reshape(-1, 4), V.reshape(-1, 4)):
        tabla.setdefault(tuple(n), tuple(v))
    frames = {}
    for d in range(5):
        for f in range(6):
            F = frame(d, f)
            sin, _ = remove_staff(F, segment(F))
            sin = sin.astype(np.uint8)
            out = np.zeros_like(sin)
            for y in range(FH):
                for x in range(FW):
                    p = tuple(sin[y, x])
                    if p[3] == 0:
                        continue
                    out[y, x] = tabla[p]
            frames[(d, f)] = out
    return _espejar(frames)


def fotograma(hoja, d, f):
    return hoja[d * FH:(d + 1) * FH, f * FW:(f + 1) * FW]
