"""Genera el lote 11 (atacar corriendo y el ataque del Mago) de SECTOR CERO.

Uso:  python3 generar_lote11.py <carpeta del repo> <carpeta de salida>

Lee del repo las hojas de andar de los tres personajes y las de ataque del
lote 7 del Espadachín y del Segador, y deja en la carpeta de salida, con la
misma ruta que en el repo (projecte/escenas/jugabilidad/jugador/):
  *_8_direcciones_correr_ataque.png              6 x 8 de 64x72 (los tres)
  *_8_direcciones_evolucion_correr_ataque.png    6 x 8 de 64x72 (los tres)
  antivirus_8_direcciones_ataque.png             4 x 8 de 64x72 (el Mago, rehecho)
  antivirus_8_direcciones_evolucion_ataque.png   4 x 8 de 64x72 (el Mago, rehecho)

Necesita numpy, scipy y Pillow. El cuerpo sin arma se saca con los mismos
scripts con los que se hicieron las hojas de andar (seg.py, nostaff.py y
render*.py, con el ejemplo del profesor en orig/), que van en esta carpeta.
"""
import os
import sys

import numpy as np
from PIL import Image

import capas
import correr_ataque
import mago

HOJAS = 'projecte/escenas/jugabilidad/jugador'


def leer(repo, nombre):
    return np.array(Image.open(os.path.join(repo, HOJAS, nombre)).convert('RGBA'))


def main(repo, salida):
    destino = os.path.join(salida, HOJAS)
    os.makedirs(destino, exist_ok=True)

    def guardar(a, nombre):
        Image.fromarray(a, 'RGBA').save(os.path.join(destino, nombre))

    manos = capas.manos()
    for base, cuerpos in (('ciberespadachin', capas.espadachin()), ('segador_ciber', capas.segador())):
        for ev in ('', '_evolucion'):
            ataque = leer(repo, f'{base}_8_direcciones{ev}_ataque.png')
            guardar(correr_ataque.hoja(cuerpos, manos, ataque), f'{base}_8_direcciones{ev}_correr_ataque.png')
    cuerpos = capas.mago(os.path.join(repo, HOJAS, 'antivirus_8_direcciones.png'))
    for ev in ('', '_evolucion'):
        andar = leer(repo, f'antivirus_8_direcciones{ev}.png')
        guardar(mago.ataque(andar, cuerpos, manos, ev != ''), f'antivirus_8_direcciones{ev}_ataque.png')
        guardar(mago.correr_ataque(andar, cuerpos, manos, ev != ''), f'antivirus_8_direcciones{ev}_correr_ataque.png')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
