"""Hojas de atacar corriendo del Espadachín y del Segador (lote 11).

Cada fotograma es el de andar sin el arma (capas.py: mismo cuerpo, piernas,
capa y sombra, píxel a píxel) con el arma del golpe más fuerte de su ataque del
lote 7 (la columna 2) encima. El arma se saca del ataque comparándolo con el
cuerpo sin arma del fotograma 0 y se pega movida lo mismo que se ha movido la
mano en ese paso, para que siga en la mano.
"""
import numpy as np

from capas import FH, FW, fotograma

GOLPE = 2  # la columna más fuerte de las hojas de ataque del lote 7


def centro(mascara):
    ys, xs = np.nonzero(mascara)
    return (xs.mean(), ys.mean()) if len(xs) else (0.0, 0.0)


def capa_arma(ataque, cuerpo0, d, columna=GOLPE):
    """Lo que el ataque tiene distinto del cuerpo sin arma: el arma, su brillo y
    el estelazo. No se borra nada del cuerpo."""
    a = fotograma(ataque, d, columna)
    dif = (np.abs(a.astype(int) - cuerpo0.astype(int)).sum(-1) > 0) & (a[..., 3] > 0)
    capa = np.zeros_like(a)
    capa[dif] = a[dif]
    return capa


def pegar(base, capa, dx, dy):
    out = base.copy()
    ys, xs = np.nonzero(capa[..., 3] > 0)
    for y, x in zip(ys, xs):
        ty, tx = y + dy, x + dx
        if 0 <= ty < FH and 0 <= tx < FW:
            p = capa[y, x]
            if p[3] == 255 or out[ty, tx, 3] < p[3]:
                out[ty, tx] = p
    return out


def hoja(cuerpos, manos, ataque):
    """6 x 8 fotogramas de 64x72: el paso c de andar con el arma del golpe."""
    A = np.zeros((8 * FH, 6 * FW, 4), np.uint8)
    for d in range(8):
        capa = capa_arma(ataque, cuerpos[(d, 0)], d)
        x0, y0 = centro(manos[(d, 0)])
        for c in range(6):
            x1, y1 = centro(manos[(d, c)])
            dx, dy = int(round(x1 - x0)), int(round(y1 - y0))
            A[d * FH:(d + 1) * FH, c * FW:(c + 1) * FW] = pegar(cuerpos[(d, c)], capa, dx, dy)
    return A
