extends SceneTree

# Prueba temporal del lote 11: cada personaje (normal y evolucionado) andando en
# tres direcciones y atacando cada tanto (Espadachín 0,6 s, Mago 0,9 s y
# Segador 2,5 s), y el Mago quieto atacando. Sin armas de verdad: el ataque se
# fuerza poniendo a 0 el tiempo de ataque del controlador.
const DIRECCIONES := {
	"abajo": ["mover_abajo"], "abajo_izq": ["mover_abajo", "mover_izquierda"],
	"izq": ["mover_izquierda"], "arriba_izq": ["mover_arriba", "mover_izquierda"],
	"arriba": ["mover_arriba"], "arriba_der": ["mover_arriba", "mover_derecha"],
	"der": ["mover_derecha"], "abajo_der": ["mover_abajo", "mover_derecha"],
}
# [personaje, evolucionado, cada cuánto ataca, direcciones (o [] quieto), segundos]
const TRAMOS := [
	["Espadachín", false, 0.6, ["abajo", "izq", "arriba_der"], 1.8],
	["Espadachín", true, 0.6, ["abajo_izq", "arriba", "der"], 1.8],
	["Mago", false, 0.9, ["abajo", "izq", "arriba_der"], 1.8],
	["Mago", true, 0.9, ["abajo_der", "arriba", "izq"], 1.8],
	["Segador", false, 2.5, ["abajo", "izq", "arriba_der"], 1.8],
	["Segador", true, 2.5, ["abajo_izq", "arriba", "der"], 1.8],
	["Mago", false, 0.9, [], 1.2],
	["Mago", true, 0.9, [], 1.2],
]
var _raiz: Node
var _jugador: Node
var _cambio: Node
var _t := 0.0
var _tramo := -1
var _inicio := 0.0
var _siguiente_ataque := 0.0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _soltar() -> void:
	for accion in ["mover_abajo", "mover_arriba", "mover_izquierda", "mover_derecha"]:
		Input.action_release(accion)


func _empezar(i: int) -> void:
	_tramo = i
	_inicio = _t
	var tramo: Array = TRAMOS[i]
	for k in _cambio.personajes.size():
		if _cambio.personajes[k].nombre == tramo[0]:
			_cambio._entrar(k)
			var p: DatosPersonaje = _cambio.personajes[k]
			_cambio._armas[k] = p.arma.duplicate() if tramo[1] else p.arma
			_cambio._aplicar()
	_siguiente_ataque = _t + 0.3


func _process(delta: float) -> bool:
	if _jugador == null:
		_jugador = _raiz.get_node("Jugador")
		_cambio = _jugador.get_node("CambioPersonaje")
		_jugador.get_node("Salud").invencible = true
		_jugador.get_node("GestorArmas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("DirectorOleadas").process_mode = Node.PROCESS_MODE_DISABLED
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		_empezar(0)
		return false
	_t += delta
	var tramo: Array = TRAMOS[_tramo]
	if _t - _inicio >= tramo[4]:
		if _tramo + 1 >= TRAMOS.size():
			_soltar()
			return true
		_empezar(_tramo + 1)
		tramo = TRAMOS[_tramo]
	_soltar()
	var dirs: Array = tramo[3]
	if not dirs.is_empty():
		var cual := mini(int((_t - _inicio) / (tramo[4] / dirs.size())), dirs.size() - 1)
		for accion in DIRECCIONES[dirs[cual]]:
			Input.action_press(accion)
	if _t >= _siguiente_ataque:
		_jugador._tiempo_ataque = 0.0
		_jugador._fila_ataque = _jugador._fila
		_siguiente_ataque = _t + tramo[2]
	return false
