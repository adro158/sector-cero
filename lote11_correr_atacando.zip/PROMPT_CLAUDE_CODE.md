Hoy toca el **lote 11: atacar corriendo y el ataque del Mago**, con unas hojas que he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: lee la bitácora y el estado antes de empezar, valida en headless y no hagas push hasta que te diga "ya he acabado". Esto lo pido yo.

El problema: las hojas de ataque del lote 7 están dibujadas de pie. Al correr, el juego cambiaba un momento a ellas y las piernas se paraban; ahora solo salen quieto, y corriendo no se ve que ataca.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y cómo elige la hoja `controlador_jugador.gd`. Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

El zip está en la rama `zips-lotes` del repo, que solo guarda los zips y no se fusiona con `main`. Bájalo y descomprímelo en la raíz del repo, encima de lo que hay, sin cambiar de rama:

```
git fetch origin zips-lotes
git show origin/zips-lotes:lote11_correr_atacando.zip > /tmp/lote11_correr_atacando.zip
unzip -o /tmp/lote11_correr_atacando.zip -d .
```

Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `gifs/`: cada personaje corriendo y atacando.
- `vistas/`: cada hoja al lado de su hoja de andar.
- `en_juego.gif`: grabado en Godot 4.7.2 con los cambios de `referencia/correr_ataque.diff`.

Tamaños y tiempos: `LEEME.txt`.

## Las hojas

En `projecte/escenas/jugabilidad/jugador/`, ya pintadas (no se tiñen), con fotogramas de 64x72 y una fila por dirección, como las de andar:

| Fichero | Tamaño | Para qué |
|---|---|---|
| `{antivirus,ciberespadachin,segador_ciber}_8_direcciones_correr_ataque.png` | 6 x 8 | atacar andando |
| `{antivirus,ciberespadachin,segador_ciber}_8_direcciones_evolucion_correr_ataque.png` | 6 x 8 | lo mismo con el arma evolucionada |
| `antivirus_8_direcciones_ataque.png` y `_evolucion_ataque.png` | 4 x 8 | el ataque quieto del Mago, rehecho (mismos nombres) |

- **Correr atacando.** La columna c es la columna c de andar, píxel a píxel (cuerpo, capa, piernas, posición y sombra). Solo cambian los brazos, el arma y su brillo, en el momento del golpe.
- **Mago quieto.** Los mismos 4 fotogramas a 0,05 s de ahora. El 0 es igual que andar. En el 1 adelanta el bastón y se carga el cristal, en el 2 suelta la bola morada y en el 3 vuelve.

## Cómo lo quiero

- **Datos.** En `DatosPersonaje`, dos campos nuevos: `hoja_correr_ataque` y `hoja_correr_ataque_evolucion`. Rellénalos en los tres `.tres` de `recursos/personajes/datos/`.
- **Cambio de personaje.** `cambio_personaje.gd` se los pasa al controlador junto con las otras hojas: la normal o la evolucionada, igual que hace con las de andar y atacar.
- **Controlador.** En `controlador_jugador.gd`, mientras dura el ataque (4 fotogramas de `segundos_ataque`):
  - **Andando:** la hoja de atacar corriendo, con 6 columnas, en la fila de hacia donde corre y **en la misma columna que las piernas**, la que tocaría andando. Las piernas siguen contando como ahora.
  - **Quieto:** la hoja de ataque de siempre, como ahora.
  - Al acabar, vuelve a la de andar.
- **La dirección del tajo.** El Espadachín ataca al enemigo más cercano (`_fila_ataque`). Corriendo, la fila tiene que ser la de las piernas, o el cuerpo giraría a mitad de paso. Propónme si te parece bien así.
- **El Mago.** Sus hojas de ataque quieto se cambian solas: mismos nombres, mismos fotogramas y mismos tiempos.

`referencia/correr_ataque.diff` es el cambio que probé para la grabación. Úsalo de guía y hazlo como sea más fácil de explicar.

## Al terminar

- **Validación del CLAUDE.md:** import y `--quit-after`.
- **Capturas con ventana**, con el menú de desarrollador (F1) o una instrumentación temporal, de cada personaje, normal y con el arma evolucionada:
  - corriendo en varias direcciones mientras ataca
  - quieto atacando

  Mira que las piernas no se paran ni saltan al empezar y al acabar el ataque. Borra la instrumentación al acabar.
- No cambia el balance: no hace falta el simulador. Pasa una partida para comprobar que no salen errores.
- **Documentación:**
  - `creditos.md`: las hojas del lote 11 las hizo Claude, con IA, como las demás.
  - `documentacion_tecnica.md`: los campos nuevos y cómo elige la hoja el controlador.
  - La bitácora y `requisitos_y_estado.md`.
  - No toques `assets.md` ni `propuesta.md`, que son de Alan.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - las vistas previas (`vistas/`, `gifs/`, `en_juego.gif`)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG (las hojas nuevas y el ataque del Mago rehecho)
  - `feat` de atacar corriendo
  - `docs`
- No publiques ninguna release.
