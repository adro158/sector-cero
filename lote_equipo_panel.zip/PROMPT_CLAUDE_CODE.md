Hoy toca el **panel del equipo (tecla C)**: pasarlo de una caja con texto a fichas con sprites. Las piezas las he hecho fuera (con Claude en el chat). Sigue el CLAUDE.md como siempre: trabaja en una rama tuya (por ejemplo `adam/panel-equipo`), valida en headless y no hagas push ni abras el PR hasta que te diga "ya he acabado". Esto lo pido yo.

**Antes de programar, dame un plan corto** con los ficheros que vas a tocar y cómo lo dibujas (Controls o `_draw`). Espera a que te diga que sí. Si algo choca con una decisión vigente, pregúntame.

El zip está en la rama `zips-lotes` del repo, que solo guarda los zips y no se fusiona con `main`. Bájalo y descomprímelo en la raíz del repo, encima de lo que hay, sin cambiar de rama:

```
git fetch origin zips-lotes
git show origin/zips-lotes:lote_equipo_panel.zip > /tmp/lote_equipo_panel.zip
unzip -o /tmp/lote_equipo_panel.zip -d .
```

Mira con `git status` qué ha llegado. Para ver cómo tiene que quedar:
- `vista_equipo.png`: las piezas y el panel grabado en Godot 4.7.2.
- `panel_equipo.gif` y `captura_equipo.png`: el panel en la partida.

Medidas, márgenes y orden de los iconos: `LEEME.txt`.

## Las piezas

En `projecte/medios/interfaz/`. Van en grises y se tiñen con el color de cada personaje (`personaje.color`; el caído, con `EstiloInterfaz.TEXTO_SUAVE`). Los rellenos y el glitch del caído, del color que toque.

| Fichero | Tamaño | Para qué |
|---|---|---|
| `equipo_ficha.png` | 3 x 40x40, 9 trozos (margen 8) | la ficha: activo, listo y caído (con `region_rect`) |
| `equipo_retrato_marco.png` | 40x40 | el marco del retrato de 32x32 |
| `equipo_activo.png` | 4 x 44x44, 0,1 s en bucle | la luz que da vueltas al retrato del activo |
| `equipo_caido.png` | 3 x 32x32, 0,12 s en bucle | grieta y glitch encima del retrato del caído, en rojo |
| `equipo_iconos.png` | 8 x 12x12 | vida, ulti, herramienta, resistencia, activo, listo, caído y equipo |
| `equipo_cabecera.png` | 64x16, 3 trozos (18 y 6) | la cabecera "EQUIPO [C]" con su emblema |
| `equipo_barra.png` + `_relleno.png` | 64x7 (3 trozos) y 60x3 | barras finas de vida y de ulti |
| `equipo_barra_brillo.png` | 6 x 60x3, 0,06 s en bucle | el destello de la ulti lista |

## Cómo lo quiero

- **Lo de dentro sigue igual.** El panel sigue:
  - en `escenas/interfaz/panel_equipo.gd`, a la derecha y a media altura
  - abriéndose y cerrándose con `ver_equipo` (C o Select)
  - actualizándose en pausa (se ve caer a uno mientras se elige quién sigue)
  - escuchando lo mismo del bus y leyendo la resistencia del nodo del malware
- **Cabecera.** "EQUIPO [C]" con su emblema. Con mando, "[Select]", como ahora con `EstiloInterfaz.segun_mando`.
- **Una ficha por personaje**, con el estado que toque y teñida de su color, con:
  - el retrato pequeño (`retrato_mini_*.png`, los del ranking, como en `fila_partida.gd`) dentro de su marco
  - el icono de su estado, su nombre y la palabra ACTIVO, LISTO o CAÍDO
  - la vida: su barra (de rojo a verde) y los números
  - la ulti: su barra dorada, y "LISTA" con el destello cuando está llena
  - la herramienta y lo que la resiste el malware; desde el 40 %, el escudo y el número en rojo
- **El activo**, con la luz dando vueltas a su retrato.
- **El caído**, con el retrato en gris y la grieta y el glitch encima.
- **Si lo haces con `_draw`.** `referencia/panel_equipo.gd` es el panel que probé para la grabación (unas 180 líneas). Úsalo de guía y hazlo como sea más fácil de explicar.
- **`raiz_juego.tscn`.** No hace falta tocarlo: el panel lo crea `hud.gd`.

## Al terminar

- **Validación del CLAUDE.md** (`/validar`): import y `--quit-after`, y carga también `escenas/juego.tscn` (una partida del simulador vale).
- **Capturas con ventana** del panel abierto:
  - al empezar (los tres listos y uno activo)
  - con un personaje caído y la ventana de elegir quién sigue
  - con la ulti de alguno llena
  - con una resistencia por encima del 40 %
  - con mando (la cabecera con [Select])

  Para que salgan, usa el menú de desarrollador (F1) o una instrumentación temporal. Mi prueba está en `referencia/prueba_equipo.gd`. Borra la instrumentación al acabar.
- No cambia el balance: no hace falta el simulador.
- **Documentación:**
  - `creditos.md`: las piezas del panel del equipo las hizo Claude, con IA, como las demás.
  - `documentacion_tecnica.md` y el manual, si hablan del panel.
  - La entrada de la sesión en `documentacio/bitacora/` y `requisitos_y_estado.md`.
  - No toques lo de Alan.
- **Qué se commitea:** solo lo de `projecte/` y la documentación. No se commitean:
  - las vistas previas (`vista_equipo.png`, `panel_equipo.gif`, `captura_equipo.png`)
  - `referencia/`
  - `herramienta/`
  - `LEEME.txt`
  - este prompt
- **Commits pequeños**, con la convención de `documentacio/flujo_de_trabajo.md`:
  - `assets` con los PNG
  - `feat(interfaz)` del panel del equipo con sprites
  - `docs`
- **Al decirte "ya he acabado":** `/cerrar` (push de la rama y su PR). No publiques ninguna versión.
