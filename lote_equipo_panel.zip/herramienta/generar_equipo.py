"""Assets del panel del equipo (tecla C) de SECTOR CERO, en grises para teñirlos
con el color de cada personaje. Misma paleta que los del lote 9 y el F3:
contorno 20, oscuro 95, medio 170, claro 235, blanco 255 y fondo 22.

Uso:  python3 generar_equipo.py <carpeta de salida>
Deja los PNG en <salida>/projecte/medios/interfaz/.
"""
import math
import os
import sys

import numpy as np
from PIL import Image

CONTORNO, OSCURO, MEDIO, CLARO, BLANCO = 20, 95, 170, 235, 255


def lienzo(w, h):
    return np.zeros((h, w, 4), np.uint8)


def gris(a, x, y, v, alfa=255):
    x, y = int(round(x)), int(round(y))
    if 0 <= y < a.shape[0] and 0 <= x < a.shape[1]:
        a[y, x] = (v, v, v, alfa)


def rect(a, x0, y0, x1, y1, v, alfa=255):
    a[y0:y1 + 1, x0:x1 + 1] = (v, v, v, alfa)


def anillo(a, x0, y0, x1, y1, v, alfa=255):
    rect(a, x0, y0, x1, y0, v, alfa)
    rect(a, x0, y1, x1, y1, v, alfa)
    rect(a, x0, y0, x0, y1, v, alfa)
    rect(a, x1, y0, x1, y1, v, alfa)


def cortar_esquinas(a, n=2):
    """Esquinas cortadas a 45 grados: se borran y el canto queda de contorno."""
    h, w = a.shape[:2]
    for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
        for i in range(n):
            for j in range(n - i):
                a[cy + sy * j, cx + sx * i] = 0
        for i in range(n + 1):
            gris(a, cx + sx * i, cy + sy * (n - i), CONTORNO)


def desde_texto(filas, valores):
    h, w = len(filas), len(filas[0])
    a = lienzo(w, h)
    for y, fila in enumerate(filas):
        for x, ch in enumerate(fila):
            if ch != '.':
                v = valores[ch]
                a[y, x] = (v, v, v, 255)
    return a


def guardar(a, ruta):
    Image.fromarray(a, 'RGBA').save(ruta)


# ------------------------------------------------------------------ ficha
def ficha(estado):
    """40x40 de 9 trozos (margen 8 en los cuatro lados). Los adornos van solo en
    las esquinas; los bordes son iguales a lo largo y el centro es liso, así
    que se estira sin deformarse."""
    w = h = 40
    a = lienzo(w, h)
    fondo = {'activo': 30, 'listo': 22, 'caido': 14}[estado]
    rect(a, 1, 1, w - 2, h - 2, fondo, 238)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    if estado == 'activo':
        # borde claro doble y una franja de brillo arriba
        anillo(a, 1, 1, w - 2, h - 2, MEDIO)
        anillo(a, 2, 2, w - 3, h - 3, OSCURO)
        rect(a, 3, 3, w - 4, 4, 52, 240)
        # la banda del color del personaje a la izquierda
        rect(a, 3, 3, 4, h - 4, BLANCO)
    elif estado == 'listo':
        rect(a, 1, 1, w - 2, 1, CLARO)
        rect(a, 1, 1, 1, h - 2, CLARO)
        rect(a, 1, h - 2, w - 2, h - 2, OSCURO)
        rect(a, w - 2, 1, w - 2, h - 2, OSCURO)
        rect(a, 3, 3, 3, h - 4, MEDIO)
    else:
        # caído: borde apagado y una grieta en dos esquinas
        anillo(a, 1, 1, w - 2, h - 2, OSCURO)
        rect(a, 3, 3, 3, h - 4, 60)
        for x, y in ((w - 2, 4), (w - 3, 5), (w - 4, 5), (w - 5, 6), (w - 5, 7), (w - 6, 2), (w - 7, 3)):
            gris(a, x, y, CONTORNO)
        for x, y in ((1, h - 5), (2, h - 6), (3, h - 6), (4, h - 7), (5, h - 3), (5, h - 4)):
            gris(a, x, y, CONTORNO)
        for x, y in ((w - 4, 6), (w - 6, 3), (2, h - 5), (4, h - 6)):
            gris(a, x, y, MEDIO)
    cortar_esquinas(a, 2)
    if estado == 'activo':
        # corchetes blancos en las cuatro esquinas (por fuera del borde doble)
        for (cx, cy, sx, sy) in ((0, 0, 1, 1), (w - 1, 0, -1, 1), (0, h - 1, 1, -1), (w - 1, h - 1, -1, -1)):
            for k in range(2, 7):
                for g in (0, 1):
                    gris(a, cx + sx * k, cy + sy * g, BLANCO)
                    gris(a, cx + sx * g, cy + sy * k, BLANCO)
            gris(a, cx + sx * 2, cy + sy * 2, BLANCO)
    return a


def fichas():
    """Tira de 120x40: activo, listo y caído (se elige con region_rect)."""
    return np.concatenate([ficha(e) for e in ('activo', 'listo', 'caido')], axis=1)


# ------------------------------------------------------------------ marco del retrato
def marco_retrato():
    """40x40 con un hueco de 32x32 en (4, 4) para el retrato pequeño."""
    w = h = 40
    a = lienzo(w, h)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    anillo(a, 1, 1, w - 2, h - 2, MEDIO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 1, 1, 1, h - 2, CLARO)
    anillo(a, 2, 2, w - 3, h - 3, OSCURO)
    anillo(a, 3, 3, w - 4, h - 4, CONTORNO)
    cortar_esquinas(a, 2)
    # patitas de chip en los cuatro lados
    for k in (12, 19, 26):
        gris(a, k, 0, CLARO)
        gris(a, k, h - 1, MEDIO)
        gris(a, 0, k, CLARO)
        gris(a, w - 1, k, MEDIO)
    return a


# ------------------------------------------------------------------ brillo del activo
def brillo_activo():
    """4 x 44x44, en bucle a 0,1 s: cuatro trazos de luz que dan la vuelta
    alrededor del marco del retrato (el marco va en 2,2) y los corchetes que
    laten."""
    lado = 44
    # el recorrido: el borde del cuadrado, en sentido de las agujas del reloj
    camino = [(x, 0) for x in range(lado)] + [(lado - 1, y) for y in range(1, lado)] + \
             [(x, lado - 1) for x in range(lado - 2, -1, -1)] + [(0, y) for y in range(lado - 2, 0, -1)]
    n = len(camino)
    fotos = []
    for f in range(4):
        a = lienzo(lado, lado)
        for k in range(4):
            cabeza = int(round(k * n / 4 + f * n / 16)) % n
            for t, v in enumerate((BLANCO, 230, 200, 165, 130, 100)):
                x, y = camino[(cabeza - t) % n]
                gris(a, x, y, v)
        # corchetes en las esquinas, más fuertes en el 0 y el 2
        v = BLANCO if f % 2 == 0 else MEDIO
        for (cx, cy, sx, sy) in ((0, 0, 1, 1), (lado - 1, 0, -1, 1), (0, lado - 1, 1, -1), (lado - 1, lado - 1, -1, -1)):
            for k in range(0, 4):
                if a[cy, cx + sx * k, 3] == 0:
                    gris(a, cx + sx * k, cy, v)
                if a[cy + sy * k, cx, 3] == 0:
                    gris(a, cx, cy + sy * k, v)
        fotos.append(a)
    return np.concatenate(fotos, axis=1)


# ------------------------------------------------------------------ caído
def caido():
    """3 x 32x32, en bucle a 0,12 s: encima del retrato (en gris) del que ha
    caído, una grieta, ruido y franjas de glitch. Se tiñe de rojo."""
    lado = 32
    grieta = [(4, 2), (6, 5), (7, 7), (10, 9), (11, 12), (13, 13), (15, 16), (16, 19), (19, 21), (20, 24), (23, 26), (25, 29)]
    rama = [(13, 13), (16, 11), (19, 11), (21, 8)]
    fotos = []
    for f in range(3):
        a = lienzo(lado, lado)
        rng = np.random.default_rng(70 + f)
        # ruido suelto
        for _ in range(26):
            gris(a, rng.integers(0, lado), rng.integers(0, lado), int(rng.choice([120, 170, 220])), 150)
        # franjas de glitch (otras en cada fotograma)
        for _ in range(3):
            y = int(rng.integers(2, lado - 3))
            x0 = int(rng.integers(0, 12))
            largo = int(rng.integers(8, 20))
            rect(a, x0, y, min(x0 + largo, lado - 1), y, 200, 130)
        # la grieta, igual en los tres
        for camino in (grieta, rama):
            for (x0, y0), (x1, y1) in zip(camino, camino[1:]):
                pasos = max(abs(x1 - x0), abs(y1 - y0))
                for i in range(pasos + 1):
                    x = x0 + (x1 - x0) * i / pasos
                    y = y0 + (y1 - y0) * i / pasos
                    gris(a, x, y, BLANCO)
                    gris(a, x + 1, y, 120)
        fotos.append(a)
    return np.concatenate(fotos, axis=1)


# ------------------------------------------------------------------ iconos
V = {'o': CONTORNO, 'd': OSCURO, 'm': MEDIO, 'l': CLARO, 'w': BLANCO}
ICONOS = [
    ('vida', [
        "............",
        ".oo....oo...",
        "owwo..olmo..",
        "owllooolmmo.",
        "olllllllmmo.",
        "ollllllldmo.",
        ".olllllldo..",
        "..olllldo...",
        "...ollmo....",
        "....omo.....",
        ".....o......",
        "............",
    ]),
    ('ulti', [
        "......ooo...",
        ".....owlo...",
        "....owlo....",
        "...owlo.....",
        "..owllooo...",
        ".owllllllo..",
        ".oooollmo...",
        "....olmo....",
        "...olmo.....",
        "..olmo......",
        "..omo.......",
        "..oo........",
    ]),
    ('herramienta', [
        "........ooo.",
        ".......owlo.",
        "......owlo.o",
        "......olloo.",
        ".....ollmo..",
        "....ollmo...",
        "...ollmo....",
        "..ollmo.....",
        ".ollmo......",
        "olwmo.......",
        "owmo........",
        "ooo.........",
    ]),
    ('resistencia', [
        "............",
        ".oooooooooo.",
        ".owllllllmo.",
        ".olwdwdwdmo.",
        ".olwdwdwdmo.",
        ".olmmmmmmmo.",
        "..olmmmmmo..",
        "..olmmmmmo..",
        "...olmmmo...",
        "....olmo....",
        ".....oo.....",
        "............",
    ]),
    ('activo', [
        "............",
        "..oo........",
        "..owoo......",
        "..owlloo....",
        "..owllllo...",
        "..owlllllo..",
        "..owllllmo..",
        "..owllmmo...",
        "..owlmoo....",
        "..owoo......",
        "..oo........",
        "............",
    ]),
    ('listo', [
        "............",
        "..........oo",
        ".........owo",
        "........owlo",
        ".oo....owlo.",
        "owwo..owlo..",
        "olwlooowlo..",
        ".olwlowlo...",
        "..olwwlo....",
        "...ollo.....",
        "....oo......",
        "............",
    ]),
    ('caido', [
        "............",
        "...oooooo...",
        "..olllllmo..",
        ".ollllllllo.",
        ".olooloolmo.",
        ".olooloolmo.",
        ".olllolllmo.",
        "..olllllmo..",
        "..olmlmlmo..",
        "..oomomomo..",
        "...ooooooo..",
        "............",
    ]),
    ('equipo', None),  # equipo_icono(): una capucha, como los personajes
]


def equipo_icono():
    """Una capucha con los ojos encendidos, como los tres personajes."""
    return desde_texto([
        "....oooo....",
        "...ollllo...",
        "..ollllllo..",
        ".olloooolmo.",
        ".olowoowomo.",
        ".oloooooomo.",
        "olllooooolmo",
        "ollllooollmo",
        "olllllllllmo",
        "olllllllllmo",
        "ommmmmmmmmdo",
        "oooooooooooo",
    ], V)


def iconos():
    """8 de 12x12 en una tira, en el orden de ICONOS."""
    return np.concatenate([equipo_icono() if f is None else desde_texto(f, V) for _, f in ICONOS], axis=1)


# ------------------------------------------------------------------ cabecera
def cabecera():
    """64x16 de 3 trozos en horizontal: izquierda 18 (el emblema, 12x12 en
    2,2) y derecha 6 (la punta). El texto, desde x = 22."""
    w, h = 64, 16
    a = lienzo(w, h)
    # banda
    rect(a, 15, 1, w - 7, 14, 36, 228)
    rect(a, 15, 0, w - 7, 0, CONTORNO)
    rect(a, 15, h - 1, w - 7, h - 1, CONTORNO)
    rect(a, 15, 1, w - 7, 1, MEDIO)
    rect(a, 15, h - 2, w - 7, h - 2, OSCURO)
    # punta inclinada a la derecha
    for y in range(h):
        x_fin = w - 7 + int(round((h - 1 - y) * 5 / (h - 1)))
        for x in range(w - 6, x_fin + 1):
            if y in (0, h - 1):
                gris(a, x, y, CONTORNO)
            else:
                gris(a, x, y, 36, 228)
        gris(a, x_fin + 1, y, CONTORNO)
        if 0 < y < h - 1:
            gris(a, x_fin, y, MEDIO if y < h // 2 else OSCURO)
    # el hueco del emblema: un chip de 16x16
    rect(a, 0, 0, 15, 15, CONTORNO)
    rect(a, 1, 1, 14, 14, 22, 242)
    rect(a, 1, 1, 14, 1, CLARO)
    rect(a, 1, 1, 1, 14, CLARO)
    rect(a, 14, 2, 14, 14, OSCURO)
    rect(a, 2, 14, 14, 14, OSCURO)
    for x, y in ((0, 0), (15, 0), (0, 15), (15, 15)):
        a[y, x] = 0
    return a


# ------------------------------------------------------------------ barras
def barra():
    """64x7 de 3 trozos (3 px a cada lado). El hueco, de 60x3 en (2, 2), lleva
    el fondo apagado: primero el marco y luego el relleno."""
    w, h = 64, 7
    a = lienzo(w, h)
    anillo(a, 0, 0, w - 1, h - 1, CONTORNO)
    rect(a, 1, 1, w - 2, 1, CLARO)
    rect(a, 1, h - 2, w - 2, h - 2, OSCURO)
    rect(a, 1, 1, 1, h - 2, CLARO)
    rect(a, w - 2, 1, w - 2, h - 2, OSCURO)
    rect(a, 2, 2, w - 3, 4, 40, 220)
    for x, y in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        a[y, x] = 0
    return a


def barra_relleno():
    """60x3, igual en todas las columnas: se recorta a lo que haya (o se estira)."""
    a = lienzo(60, 3)
    for y, v in enumerate((BLANCO, 215, 160)):
        rect(a, 0, y, 59, y, v)
    return a


def barra_brillo():
    """6 x 60x3, en bucle a 0,06 s: un destello que recorre la barra de la ulti
    cuando está lista (va encima del relleno, blanco con transparencia)."""
    fotos = []
    for f in range(6):
        a = lienzo(60, 3)
        x0 = f * 12 - 2
        for y in range(3):
            for k, alfa in ((0, 110), (1, 200), (2, 255), (3, 200), (4, 110)):
                x = x0 + k - y
                if 0 <= x < 60:
                    a[y, x] = (255, 255, 255, alfa)
        fotos.append(a)
    return np.concatenate(fotos, axis=1)


def generar(salida):
    carpeta = os.path.join(salida, 'projecte/medios/interfaz')
    os.makedirs(carpeta, exist_ok=True)
    for nombre, a in (('equipo_ficha', fichas()), ('equipo_retrato_marco', marco_retrato()),
                      ('equipo_activo', brillo_activo()), ('equipo_caido', caido()),
                      ('equipo_iconos', iconos()), ('equipo_cabecera', cabecera()),
                      ('equipo_barra', barra()), ('equipo_barra_relleno', barra_relleno()),
                      ('equipo_barra_brillo', barra_brillo())):
        guardar(a, os.path.join(carpeta, nombre + '.png'))


if __name__ == '__main__':
    generar(sys.argv[1])
