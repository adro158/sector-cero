extends SceneTree

# Prueba temporal del panel del equipo (C) con los sprites nuevos: partida, el
# panel abierto, el segundo personaje caído, la ulti del activo llena y una
# resistencia contra su herramienta.
var _raiz: Node
var _frames := 0


func _initialize() -> void:
	var guardado := root.get_node("GestorGuardado")
	root.get_node("BusEventos").partida_terminada.disconnect.call_deferred(guardado._al_terminar_partida)
	var juego: Node = load("res://escenas/juego.tscn").instantiate()
	root.add_child(juego)
	_raiz = juego.get_node("RaizJuego")


func _buscar(nodo: Node, ruta: String) -> Node:
	if nodo.get_script() != null and nodo.get_script().resource_path == ruta:
		return nodo
	for hijo in nodo.get_children():
		var hallado := _buscar(hijo, ruta)
		if hallado != null:
			return hallado
	return null


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 3:
		_raiz.get_node("Jugador/Salud").invencible = true
		_raiz.get_node("PoolGemas").process_mode = Node.PROCESS_MODE_DISABLED
		var panel: Control = _buscar(root, "res://escenas/interfaz/panel_equipo.gd")
		panel.visible = true
		var estado: Array = panel._estado.duplicate(true)
		estado[0].vida = estado[0].maxima * 0.72
		estado[2].caido = true
		estado[2].vida = 0.0
		root.get_node("BusEventos").equipo_cambiado.emit(estado, 0)
		root.get_node("BusEventos").ulti_cambiada.emit([1.0, 0.45, 0.2], 0)
		var resistencia: Node = _raiz.get_tree().get_first_node_in_group("resistencia_malware")
		resistencia._resistencias[estado[0].arma] = 0.4
		resistencia._resistencias[estado[1].arma] = 0.1
	return _frames > 60
